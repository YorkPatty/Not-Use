function PlotFits(Fits, Validations, BestFit, numIter,rpm, ThrB, ThrW, WgB, WgW)
% Description:
    % The purpose of this function is to plot the Fits and Validations data
    % returned from the GenerateMPCDesigns function. 

% Inputs: 
    % Fits (from GenerateMPCDesigns)
    % Validations(from GenerateMPCDesigns)

% Outputs: 
    % Plot 1: Fits
        % The plotted values are MAP/boost
            % Measured MAP value from identification data
            % Fitted MAP value from IDmodel (given ID data inputs)
    % Plot 2: Validations
        % The plotted values are MAP/boost
            % Measured MAP value from validation data
            % Fitted MAP value from IDmodel (given VD data outputs)
            
 for i = 1:numIter
% Plot 1: Fits
figure;
hold on;
plot(Fits{i}(:,1) , Fits{i}(:,2), 'b');
plot(Fits{i}(:,1), Fits{i}(:,3),'r'); % 'g', Validations(:,3), 'k');
title("Fits: MAP Output: Engine Speed " +rpm(i)+" Thr = " + ThrB(i) + " Wiggle = " + ThrW(i) +" Wg = " +WgB(i)+ " Wiggle = " +WgW(i)+" ")
xlabel('Time (s)')
ylabel('Boost (Pa)')
legend('Measured', 'Fitted');
hold off;

% Plot 2: Validations
figure;
hold on;
plot(Validations{i}(:,1), Validations{i}(:,2),'b'); % data output
plot(Validations{i}(:,1), Validations{i}(:,3),'r'); % model output
title("Validations: MAP Output: Engine Speed " +rpm(i)+" Thr = " + ThrB(i) + " Wiggle = " + ThrW(i) +" Wg = " +WgB(i)+ " Wiggle = " +WgW(i)+" ")
xlabel('Time (s)')
ylabel('Boost (Pa)')
legend('Measured', 'Fitted');
annotation('textbox', [0.69, 0.12, 0.2, 0.045], 'String', "Fit: " +BestFit(i)+"%")
hold off;

end
       
             
end





