% This script uses the following functions:
    % GenerateMPCDesigns: 
        % creates MPCobjs from the acquired data
    % diffMAPParam:
        % gets midpoint values of inputs and outputs into the MPC (for
        % differential MPC)
    % Plots:
        % plots the fits of the IDmodel/state-space models to see their
        % accuracy
%% Initialize Parameters
% set the run time for the Dynamometer Simulation
runTime = 300;

% set PRBS signal parameters (uses Bernoulli Binary block in Simulink)
BBT = 2;    % Bernoulli Binary block sampling time
PofZ = 0.5; % Bernoulli Binary block probability of zero

% initialize values of interest for modeling (ThrPos%, WgPos%, EngSpd)
ThrB = [100 100 100 100];     % Throttle Base value
ThrW = [0 0 0 0];      % Throttle wiggle value
WgB = [62 56 57 57];   % Wastegate Base value (held constant at 100% open)
WgW = [10 9 9 8];       % Wastegate wiggle value
rpm = [2000 3000 4000 5000]; % engine speed values (operating points)

%% Collecting Data

% specify number of iterations based on number of values being tested for
numIter = length(ThrB);

% initialize cell storage for identification and validation data
iddataCollection = cell(1,numIter);
vddataCollection = cell(1,numIter);

% enter the path for SIDynamometer.prj to run SI Dynamometer
proj = openProject('/Users/jonathanwozny/MATLAB/projects/examples/SIDynamometer/main/SIDynamometer.prj');

% need variables to go into Dyno to be defined outside of the function
for i = 1:numIter
    % send in individual variable values to the DynoRefApp
    RPM = [0 rpm(i)];    % Engine speed in rpm
    ThrBase = ThrB(i);   % Throttle Base Position (%)
    ThrWiggle = ThrW(i); % Throttle Position Wiggle (%)
    WgBase = WgB(i);     % Wastegate Base Position (%)
    WgWiggle = WgW(i);   % Wastegate Position Wiggle (%)

% run Dyno application to acquire identification (ID) Data and validation (VD) data
    % run simulation twice: for ID data and for VD data
    sim('SiDynoReferenceApplication',runTime)
    iddataCollection{i} = Data;   % identification data (ID Data) for creating model
                                  % 'Data' is a 'To Workspace' block manually inserted in the Dyno Application
    sim('SiDynoReferenceApplication',runTime);
    vddataCollection{i} = Data;   % validation data (VD Data) for testing model

    % print run number to update user of run progress
    fprintf("Run %i\n", i);
end 

close all; % close the reference application

% The data retrieved from the dynamometer are sent from a 'To Workspace'
% located in the Engine Plant block in the SI Dyno Application. Here are
% the signals returned from the block.
    % 1: Measured Throttle position
    % 2: Measured Wastegate Position
    % 3: Measured Engine Speed
    % 4: Measured MAP/boost output
    
%% Creating MPCs
% create model and MPCs
[MPCobjs,Fits,Validations,BestFit] = GenerateMPCDesigns(iddataCollection,vddataCollection);

%% Non-Differential MAP Values for MPC
% b/c it is differential actuator inputs --> find the average value of MAP
% and the actuator (throttle or wastegate)
[MidMAP, MidActuator] = diffMAPParam(iddataCollection,numIter);

%% Plotting
% plot fits and validations for visual inspection
PlotFits(Fits, Validations,BestFit, numIter,rpm, ThrB, ThrW, WgB, WgW);
