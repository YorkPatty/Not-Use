function [MidMAP, MidActuator] = diffMAPParam(iddataCollection,numIter)
% Description: 
    % the purpose of this function is to return data that will be used for
    % running the model predictive controllers for differential MAP

% Inputs: ID Data from Dyno simulation

% Outputs: 
    % MidMAP: 
        % This is the midpoint of the intake manifold pressure. This value
        % will be subtracted from intake manifold pressure command going
        % into reference (ref) of the Multiple MPC block in Simulink.
                
    % MidActuator: 
        % This is the midpoint of the actuator value (Throttle or
        % Wastegate) that will be added back to the differential actuator
        % commands being returned as manipulated variabes (mv) from the MPC
        % controller. 

% initialize variables to return
MidMAP = zeros(numIter,1);
MidActuator = zeros(numIter,1);
        
        
for i=1:numIter
    
ind = find(iddataCollection{i}.time>10); % get rid of data for transient start up

% calculate the midpoint of the MAP values
MinMAP(i) = min(iddataCollection{i}.signals.values(ind,4));
MaxMAP(i) = max(iddataCollection{i}.signals.values(ind,4));
MidMAP(i) = (MaxMAP(i) + MinMAP(i))/2; 

% calculate the midpoint of the actuator values 
% NOTE: 
        % 1 is for throttle
        % 2 is for wastegate
MinActuator(i) = min(iddataCollection{i}.signals.values(ind,1)); 
MaxActuator(i) = max(iddataCollection{i}.signals.values(ind,1)); 
MidActuator(i) = (MaxActuator(i) + MinActuator(i))/2; 

end

end