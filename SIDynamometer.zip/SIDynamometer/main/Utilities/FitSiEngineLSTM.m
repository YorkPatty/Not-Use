function [net,TestX,TestY,Ts,muX,muY,sigX,sigY,TestTime,layer2InputWeights,layer2RecurrentWeights,layer2Bias,layer3Weights,layer3Bias]=FitSiEngineLSTM(varargin)

   % Function fits LSTM to measured data or data from SiDynamometer
   %
   %
   % Copyright 2016-2019 The MathWorks, Inc.
   
   %Check available licenses
   if ~(license('test', 'neural_network_toolbox')&&license('test', 'statistics_toolbox'))
       errordlg('Statistics and Machine Learning Toolbox and Deep Learning Toolbox are required for Deep Learning Engine Model Generation','Toolbox Support')
   end
   
   %LSTM training default settings
   numHiddenUnits=200;
   
   options=trainingOptions('adam', ...
            'MaxEpochs',250, ...
            'GradientThreshold',1, ...
            'InitialLearnRate',0.005, ...
            'LearnRateSchedule','piecewise', ...
            'LearnRateDropPeriod',125, ...
            'LearnRateDropFactor',0.2, ...
            'Shuffle','never',...
            'Verbose',0, ...
            'Plots','training-progress');
           
   ModelName=[]; %Default to external data reference
    
   if nargin==1 %User provides model from which to gather data
       
      ModelName=varargin{1};
      [EngInputs,EngOutputs,Ts]=ExecuteDoE(ModelName);
      
      numFeatures=size(EngInputs,2);
      numResponses=size(EngOutputs,2);
      
      layers = [ ...
            sequenceInputLayer(numFeatures)
            lstmLayer(numHiddenUnits,'OutputMode','sequence')
            fullyConnectedLayer(numResponses)
            regressionLayer];
        
   elseif nargin==2 %User provides model from which to gather data and max training Epochs
       
      ModelName=varargin{1};
      
      MaxEpochs=varargin{2};
      
      options=trainingOptions('adam', ...
            'MaxEpochs',MaxEpochs, ...
            'GradientThreshold',1, ...
            'InitialLearnRate',0.005, ...
            'LearnRateSchedule','piecewise', ...
            'LearnRateDropPeriod',125, ...
            'LearnRateDropFactor',0.2, ...
            'Shuffle','never',...
            'Verbose',0, ...
            'Plots','training-progress');
      
      [EngInputs,EngOutputs,Ts]=ExecuteDoE(ModelName);
      
      numFeatures=size(EngInputs,2);
      numResponses=size(EngOutputs,2);
      
      
      layers = [ ...
            sequenceInputLayer(numFeatures)
            lstmLayer(numHiddenUnits,'OutputMode','sequence')
            fullyConnectedLayer(numResponses)
            regressionLayer];     
        
   elseif nargin==3 %User provides data directly using default options
       
      EngInputs=varargin{1};
      EngOutputs=varargin{2};
      Ts=varargin{3};
      
      numFeatures=size(EngInputs,2);
      numResponses=size(EngOutputs,2);
      
      layers = [ ...
            sequenceInputLayer(numFeatures)
            lstmLayer(numHiddenUnits,'OutputMode','sequence')
            fullyConnectedLayer(numResponses)
            regressionLayer];
      
   elseif nargin==4 %User model from which to gather data, fit model with provided settings
       
      ModelName=varargin{1};
      [EngInputs,EngOutputs,Ts]=ExecuteDoE(ModelName);
      layers=varargin{2};
      numHiddenUnits=varargin{3};
      options=varargin{4};
      
   elseif nargin==6 %User provides data directly, fit model with provided settings
       
      EngInputs=varargin{1};
      EngOutputs=varargin{2};
      Ts=varargin{3};
      layers=varargin{4};
      numHiddenUnits=varargin{5};
      options=varargin{6};
      
   else
      error('Invalid number of input arguments');
   end
      
   %Fit LSTM using speed/torque inputs, columns 1 and 8 of input data
   [net,TestX,TestY,Ts,muX,muY,sigX,sigY,TestTime,layer2InputWeights,layer2RecurrentWeights,layer2Bias,layer3Weights,layer3Bias]=autoblkssilstmfit(EngInputs,EngOutputs,Ts,layers,numHiddenUnits,options);
   
   %Show test set validation results
   PlotLSTMFitResults(net,TestX,TestY,muX,muY,sigX,sigY,TestTime);
   
   %Export model calibration parameters to DL model
   DLModelParmNames={'Ts','muX','muY','sigX','sigY','layer2InputWeights','layer2RecurrentWeights','layer2Bias','layer3Weights','layer3Bias'};
   DLModelName='SiDLEngine';
   open_system(DLModelName);
   hws=get_param(DLModelName,'modelworkspace');
    
   for i=1:length(DLModelParmNames)
      assignin(hws,DLModelParmNames{i},eval(DLModelParmNames{i}));
   end
   
   %Save DL model with new parameters
   [FILEPATH,~,~]=fileparts(which(DLModelName));
   save_system(DLModelName,[FILEPATH '/' DLModelName],'OverwriteIfChangedOnDisk',true);
   
   %Execute engine mapping experiment on Deep Learning Engine Model
   if ~isempty(ModelName)&&~(nargin==2)
      set_param([ModelName '/Engine System/Engine Plant/Engine'],'LabelModeActiveChoice','SiDLEngine'); 
      DynamometerStart([ModelName '/Subsystem1'],'SteadyState');    
   end
   
end

function [EngInputs,EngOutputs,Ts]=ExecuteDoE(ModelName)
    %% Generate engine test data via DoE for training and test set
    Ts=0.01;
    NumPoints=500.;

    p=sobolset(2);
    DOE.Type='sobol';

    %scramble points (randomize it)
    p=scramble(p,'MatousekAffineOwen');

    m=net(p,NumPoints); %Extract quasi-random point set

    %set ranges in speed and torque
    lb=[200.,0.];
    ub=[5000.,200.];

    r=ub-lb;
    meanval=(ub+lb)/2.;

    % scale sobolset values to physical values
    v = zeros(size(m));
    for k = 1:size(m,2)
       v(:,k)=(m(:,k)-0.5)*r(k)+meanval(k);
    end
    
    % construct the speed and torque vectors adding in friction curves
    
    SteadyEngSpdCmdPts=v(:,1)';
    SteadyTrqCmdPts=v(:,2)'; 
    
    %Add idle points randomly by overwrite
    IdleReplacementInd=randperm(NumPoints,0.05*NumPoints);
    SteadyEngSpdCmdPts(IdleReplacementInd)=750.;
    SteadyTrqCmdPts(IdleReplacementInd)=6.5;
    
    %Add stop points randomly by overwrite
    StopReplacementInd=randperm(NumPoints,0.05*NumPoints);
    SteadyEngSpdCmdPts(StopReplacementInd)=0.;
    SteadyTrqCmdPts(StopReplacementInd)=0.;
    
    hmws=get_param(ModelName,'modelworkspace');
    
    %Store original test points
    SteadyEngSpdCmdPtsBase=evalin(hmws,'SteadyEngSpdCmdPts');
    SteadyTrqCmdPtsBase=evalin(hmws,'SteadyTrqCmdPts');
    
    %Store new test points in model
    assignin(hmws,'SteadyEngSpdCmdPts',SteadyEngSpdCmdPts);
    assignin(hmws,'SteadyTrqCmdPts',SteadyTrqCmdPts);
    
    DynoCtrlBlk=[ModelName,'/Dynamometer Control'];
    set_param(DynoCtrlBlk,'OverrideUsingVariant', 'SteadyState');
    set_param(DynoCtrlBlk,'BackgroundColor','green');
    
    set_param(ModelName,'StopTime','30000');
    
    StopFcn=get_param([ModelName '/Performance Monitor'],'StopFcn');
    set_param([ModelName '/Performance Monitor'],'StopFcn','');
    
    %Set up logging
    Block=[ModelName '/Performance Monitor/Dynamic Logging/LogData'];
    ph=get_param(Block,'porthandles');
    lh=get_param(ph.Outport,'Line');
    set_param(lh,'Name','DynMeasurements');
    set_param(ph.Outport,'DataLogging','on');
    set_param(ph.Outport,'DataLoggingSampleTime',num2str(Ts));
    out=sim(ModelName,'SignalLogging','on','SignalLoggingName','logsout');
    
    %clean up figures
    h = findall(0, 'Type', 'figure', 'Tag', 'DynamometerWaitbarFig');
    if ~isempty(h)
       delete(h(1))
    end
    
    h = findall(0, 'Type', 'figure', 'Tag', 'RebuildModelWaitbarFig');
    if ~isempty(h)
        delete(h(1))
    end

    %Restore Performance Monitor StopFcn
    set_param([ModelName '/Performance Monitor'],'StopFcn',StopFcn);
    
    %Form input and output arrays
    EngInputNames={'Engine speed (rpm)','Throttle position percent','Wastegate area percent','Injection pulse width (ms)','Spark advance (degCrkAdv)','Intake cam phase command (degCrkAdv)','Exhaust cam phase command (degCrkRet)','Torque command (N*m)'};
    EngInputNames=strrep(strrep(strrep(strrep(strrep(EngInputNames,' ','_'),')','_'),'(','_'),'*','_'),'/','_');
    
    EngOutputNames={'Measured engine torque (N*m)','Intake manifold pressure (kPa)','Fuel mass flow rate (g/s)','Exhaust manifold temperature (C)','Turbocharger shaft speed (rpm)','Intake port mass flow rate (g/s)','Intake manifold temperature (C)','Tailpipe HC emissions (g/s)','Tailpipe CO emissions (g/s)','Tailpipe NOx emissions (g/s)','Tailpipe CO2 emissions (g/s)'};
    EngOutputNames=strrep(strrep(strrep(strrep(strrep(EngOutputNames,' ','_'),')','_'),'(','_'),'*','_'),'/','_');
    
    EngOutputConversionSlopes=[1 1000 0.001 1 1 0.001 1 0.001 0.001 0.001 0.001];
    EngOutputConversionOffsets=[0 0 0 273.15 0 0 273.15 0 0 0 0];
    
    Measurement=out.logsout.find('DynMeasurements');
    
    for i=1:length(EngInputNames)
        EngInputs(:,i)=eval(['Measurement.Values.' EngInputNames{i} '.Data']);
    end
    
    for i=1:length(EngOutputNames)
        EngOutputs(:,i)=eval(['Measurement.Values.' EngOutputNames{i} '.Data'])*EngOutputConversionSlopes(i)+EngOutputConversionOffsets(i);
    end
        
    %Split dataset into train and test
    shutdownind=floor(0.5*size(EngInputs,1));
    shutdowninputs=zeros(1,size(EngInputs,2));
    EngInputs=[EngInputs(1:shutdownind,:);repmat(shutdowninputs,1000,1);EngInputs(shutdownind+1:end,:)];
        
    shutdownoutputs=[0 101325 0 293.15 0 0 293.15 0 0 0 0];
    EngOutputs=[EngOutputs(1:shutdownind,:);repmat(shutdownoutputs,1000,1);EngOutputs(shutdownind+1:end,:)];
    
    %Return only 2 of the engine inputs (torque command and speed)
    EngInputs=EngInputs(:,[1 8]);
    
    %Restore original test breakpoints
    assignin(hmws,'SteadyEngSpdCmdPts',SteadyEngSpdCmdPtsBase);
    assignin(hmws,'SteadyTrqCmdPts',SteadyTrqCmdPtsBase);
        
end


function PlotLSTMFitResults(net,TestX,TestY,muX,muY,sigX,sigY,TestTime)

    TestXStandardized=(TestX-muX)./sigX;
    TestYStandardized=(TestY-muY)./sigY;

    XTest={TestXStandardized'};

    tic;[~,YPred]=predictAndUpdateState(net,XTest);toc

    PredY=repmat(sigY,size(YPred{1}',1),1).*YPred{1}'+repmat(muY,size(YPred{1}',1),1);

    %Torque Prediction
    figure
    subplot(2,1,1)
    plot(TestTime,[TestY(:,1) PredY(:,1)]);
    xlabel('Time (sec)')
    ylabel('Torque (Nm)')
    title('Dynamic Torque Prediction vs Test')
    legend('Test','Pred')
    grid on
    subplot(2,1,2)
    plotResponse(TestY(:,1)',PredY(:,1)','Torque');
    
    
    %MAP Prediction
    figure
    subplot(2,1,1)
    plot(TestTime,[TestY(:,2) PredY(:,2)]);
    xlabel('Time (sec)')
    ylabel('MAP (Pa)')
    title('Dynamic MAP Prediction vs Test')
    legend('Test','Pred')
    grid on
    subplot(2,1,2)
    plotResponse(TestY(:,2)',PredY(:,2)','MAP');

    %Fuel Flow Prediction
    figure
    subplot(2,1,1)
    plot(TestTime,[TestY(:,3) PredY(:,3)]);
    xlabel('Time (sec)')
    ylabel('Fuel Flow (kg/s)')
    title('Dynamic Fuel Flow Prediction vs Test')
    legend('Test','Pred')
    grid on
    subplot(2,1,2)
    plotResponse(TestY(:,3)',PredY(:,3)','Fuel Flow');

    %Air Flow Prediction
    figure
    subplot(2,1,1)
    plot(TestTime,[TestY(:,6) PredY(:,6)]);
    xlabel('Time (sec)')
    ylabel('Air Flow (kg/s)')
    title('Dynamic Air Flow Prediction vs Test')
    legend('Test','Pred')
    grid on
    subplot(2,1,2)
    plotResponse(TestY(:,6)',PredY(:,6)','Air Flow');

    %Exhaust Temperature Prediction
    figure
    subplot(2,1,1)
    plot(TestTime,[TestY(:,4) PredY(:,4)]);
    xlabel('Time (sec)')
    ylabel('Exhaust Temp (K)')
    title('Dynamic Exhaust Temperature Prediction vs Test')
    legend('Test','Pred')
    grid on
    subplot(2,1,2)
    plotResponse(TestY(:,4)',PredY(:,4)','Exhaust Temp');
    
    %Turbo Speed Prediction
    figure
    subplot(2,1,1)
    plot(TestTime,[TestY(:,5) PredY(:,5)]);
    xlabel('Time (sec)')
    ylabel('Turbo Speed (RPM)')
    title('Dynamic Turbo Speed Prediction vs Test')
    legend('Test','Pred')
    grid on
    subplot(2,1,2)
    plotResponse(TestY(:,5)',PredY(:,5)','Turbo Speed');
    
    %Intake manifold gas temperature
    figure
    subplot(2,1,1)
    plot(TestTime,[TestY(:,7) PredY(:,7)]);
    xlabel('Time (sec)')
    ylabel('Intake Manifold Gas Temperature (K)')
    title('Intake Manifold Gas Temperature Prediction vs Test')
    legend('Test','Pred')
    grid on
    subplot(2,1,2)
    plotResponse(TestY(:,7)',PredY(:,7)','Intake Temp');
    
    %HC Flow Prediction
    figure
    subplot(2,1,1)
    plot(TestTime,[TestY(:,8) PredY(:,8)]);
    xlabel('Time (sec)')
    ylabel('HC Flow (kg/s)')
    title('Dynamic HC Flow Prediction vs Test')
    legend('Test','Pred')
    grid on
    subplot(2,1,2)
    plotResponse(TestY(:,8)',PredY(:,8)','HC Flow');
    
    %CO Flow Prediction
    figure
    subplot(2,1,1)
    plot(TestTime,[TestY(:,9) PredY(:,9)]);
    xlabel('Time (sec)')
    ylabel('CO Flow (kg/s)')
    title('Dynamic CO Flow Prediction vs Test')
    legend('Test','Pred')
    grid on
    subplot(2,1,2)
    plotResponse(TestY(:,9)',PredY(:,9)','CO Flow');
    
    %NOx Flow Prediction
    figure
    subplot(2,1,1)
    plot(TestTime,[TestY(:,10) PredY(:,10)]);
    xlabel('Time (sec)')
    ylabel('NOx Flow (kg/s)')
    title('Dynamic NOx Flow Prediction vs Test')
    legend('Test','Pred')
    grid on
    subplot(2,1,2)
    plotResponse(TestY(:,10)',PredY(:,10)','NOx Flow');
    
    %CO2 Flow Prediction
    figure
    subplot(2,1,1)
    plot(TestTime,[TestY(:,11) PredY(:,11)]);
    xlabel('Time (sec)')
    ylabel('CO2 Flow (kg/s)')
    title('Dynamic CO2 Flow Prediction vs Test')
    legend('Test','Pred')
    grid on
    subplot(2,1,2)
    plotResponse(TestY(:,11)',PredY(:,11)','CO2 Flow');
    
end


% This function produces a correlation plot with fit statistics
function plotResponse(ym,yp,respname)

    % R^2 coeff and RMSE
    [r2,RMSE] = iCalculateErrors(ym,yp);

    % plot
    scatter(ym,yp,5,'filled', 'r')
    xlabel('Measurement');
    ylabel('Model');
    hold on
    % display 95% confidence intervals
    areaColor = [0.7922    0.8353    0.9020];
    lineColor = 'b';
    shadedplot(yp, yp - 1.96*RMSE, yp + 1.96*RMSE, areaColor,lineColor);

    xlim([min(ym) max(ym)])
    ylim([min(ym) max(ym)])
    title([respname,', R^2 = ', num2str(r2),', RMSE = ', num2str(RMSE)])
    grid on

end

function [ha, hb, hc] = shadedplot(x, y1, y2, varargin)

    % plot the shaded area
    y = [y1; (y2-y1)]'; 
    ha = area(x, y);
    set(ha(1), 'FaceColor', 'none') % this makes the bottom area invisible
    set(ha, 'LineStyle', 'none', 'FaceAlpha', 0.3)
    % plot the line edges
    hold on 
    hb = plot(x, y1, ':', 'LineWidth', 1);
    hc = plot(x, y2, ':','LineWidth', 1);
    hold off
    % set the line and area colors if they are specified
    switch length(varargin)
        case 0
        case 1
            set(ha(2), 'FaceColor', varargin{1})
        case 2
            set(ha(2), 'FaceColor', varargin{1})
            set(hb, 'Color', varargin{2})
            set(hc, 'Color', varargin{2})
        otherwise
    end
    % put the grid on top of the colored area
    set(gca, 'Layer', 'top')
    grid on

end

function [r2,rmse,r2adj] = iCalculateErrors(ydata, yestimation, nparam)

    % ICALCULATEERRORS calculates the coefficient of determination R^2 (r2) and
    %   Root Mean-Squared Error (RMSE) from the original
    %   data (ydata) and fited data (yestimation). It also calculates the
    %   adjusted coefficient (r2adj) considering the number of parameters of
    %   the model (nparam).
    %
    % Syntax:  
    %    [r2, rmse] = rsquared(ydata,yestimation)
    %    [r2, rmse, r2adj] = rsquared(ydata,yestimation,nparam)
    %
    % Example:  
    %    xdata = [1    5  14  23  25  48   49   59   73   77   99  ];
    %    ydata = [-100 70 100 450 550 2200 2300 3400 5300 5906 9600];
    %    plot(xdata,ydata,'ok'), hold on
    %    param_1 = polyfit(xdata,ydata,1);
    %    yestimation_1 = polyval(param_1,xdata);
    %    [r2_1,r2adj_1]=rsquared(ydata,yestimation_1,length(param_1))
    %    plot(xdata,yestimation_1,'-r')
    %    param_2 = polyfit(xdata,ydata,2);
    %    yestimation_2 = polyval(param_2,xdata);
    %    plot(xdata,yestimation_2,'-b')
    %    [r2_2,r2adj_2]=rsquared(ydata,yestimation_2,length(param_2))
    %    legend({'data',['r2=' num2str(r2_1) ', r2adj=' ...
    %        num2str(r2adj_1)],['r2=' num2str(r2_2) ', r2adj=' num2str(r2adj_2)]}, ...
    %        'Location','best')
    %
    % Equations
    %    SSres=sum( (ydata-yestimation).^2 );                                 % residual sum of squares
    %    SStot=sum( (ydata-mean(ydata)).^2 );                                 % total sum of squares
    %    r2=1-SSres/SStot;                                                    % standard rsquared
    %    rmse = sqrt(mean((ydata - yestimation).^2));                         % RMSE  
    %    r2adj = 1 - SSres/SStot * (length(ydata)-1)/(length(ydata)-nparam);  % adjust for the number of parameters
    %
    % Check https://en.wikipedia.org/wiki/Coefficient_of_determination

    if nargin<2
        help rsquared
    else
        SSres=sum( (ydata-yestimation).^2 );
        SStot=sum( (ydata-mean(ydata)).^2 );
        %SStot = (length(ydata)-1) * var(ydata);

        r2=1-SSres/SStot;
        % Root Mean Squared Error
        rmse = sqrt(mean((ydata - yestimation).^2));

        if nargout>2
            if nargin<3
                warning('using nparam=2 for caclulating r2adj (ex. 1st-degree polynomial fit)')
                nparam=2;
            end
            r2adj = 1 - SSres/SStot * (length(ydata)-1)/(length(ydata)-nparam);        
        end
    end

end

