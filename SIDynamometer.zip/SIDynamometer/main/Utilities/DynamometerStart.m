function DynamometerStart(Block, Mode)
%
% Copyright 2016-2018 The MathWorks, Inc.

%% Setup
ModelName = bdroot(Block);
DynoCtrlBlk = [ModelName,'/Dynamometer Control'];

%% Set variant
switch Mode
    case 'CalThrWg'
        set_param(DynoCtrlBlk, 'OverrideUsingVariant', 'CalThrWg');
        set_param(DynoCtrlBlk, 'BackgroundColor', 'magenta');
    case 'Dynamic'
        set_param(DynoCtrlBlk, 'OverrideUsingVariant', 'Dynamic');
        set_param(DynoCtrlBlk, 'BackgroundColor', 'cyan');
    case 'SteadyState'
        set_param(DynoCtrlBlk, 'OverrideUsingVariant', 'SteadyState');
        set_param(DynoCtrlBlk, 'BackgroundColor', 'green');
end
    
%% Run simulation
pause(0.01)
h = waitbar(0.5, 'Rebuilding models, please wait...');
h.Tag = 'RebuildModelWaitbarFig';
set_param(ModelName, 'SimulationCommand', 'start');

% Close waitbar
h = findall(0, 'Type', 'figure', 'Tag', 'RebuildModelWaitbarFig');
if ~isempty(h)
    delete(h(1))
end