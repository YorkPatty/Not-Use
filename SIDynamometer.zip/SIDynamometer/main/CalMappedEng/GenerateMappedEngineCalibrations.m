function varargout = GenerateMappedEngineCalibrations(varargin)
% Copyright 2018 The MathWorks, Inc.
%% Setup
Block = varargin{1};
isMBCInstalled = CheckMBCLicense(Block);
varargout{1} = [];
if isMBCInstalled || strcmp('SpreadsheetFileNameSelect', varargin{2})
    switch varargin{2}
        case 'SpreadsheetFileNameSelect'
            SpreadsheetFileNameSelect(Block);
        case 'GenMappedEngCalButton'
            GenMappedEngCalButton(Block);
        case 'ApplyCalMappedEngButton'
            ApplyCalMappedEngButton(Block);
        case 'CheckMBCLicense'
            CheckMBCLicense(Block);
        case 'OpenMBCFile'
            OpenMBCFile(Block);
        case 'OpenCageFile'
            OpenCageFile(Block);
        case 'Init'
            CheckMBCLicense(Block);
        case 'UpdateParentIcon'
            UpdateParentIcon(Block)
    end
end


end

%% ExcelFileNameSelect
function SpreadsheetFileNameSelect(Block)
[FileName, PathName] = uigetfile('*.xlsx');
if ~ischar(FileName)
    return;
end
FilesFound = which(FileName, '-ALL');
if length(FilesFound) ~= 1
    FileName = [PathName, FileName];
else
    if ~strcmp([PathName, FileName], FilesFound{1})
        FileName = [PathName, FileName];
    end
end
set_param(Block, 'SpreadsheetFileName', FileName);

end

%% CreateResSurfMdlButton
function GenMappedEngCalButton(Block)
%% Open MBC if user info requested
P = mbcprefs('mbc');
if ~getpref(P, 'UserInfoRequested')
    mbcmodel;
end

%% Get File names
% Spreadsheet file name
[PathName, FileName, Ext] = fileparts(get_param(Block,'SpreadsheetFileName'));
if isempty(PathName)
    SelectedFile = which([FileName, Ext]);
    PathName = fileparts(SelectedFile);
end
XlsFileName = [PathName, '\', FileName, Ext];

% MBC project name
MBCFileName = GetMBCPrjName(Block);

% Cage file name
CageFileName = GetCageFileName(Block);

% Model reference name
MappedEngMdlRefName = get_param(Block, 'MappedEngMdlRefName');

%% Determine breakpoint type and template file names
if bdIsLoaded(MappedEngMdlRefName)
    isSysLoaded = true;
else
    load_system(MappedEngMdlRefName)
    isSysLoaded = false;
end
[isSiMappedEng, UseFuelMassBpt] = DetectBptType(MappedEngMdlRefName);
if ~isSysLoaded
    load_system(MappedEngMdlRefName)
end

if UseFuelMassBpt
    FiringTestPlanName = 'MappedEngine-Fuel.mbt';
    CageTemplate = fullfile(mbcpath,'mbctraining','CIMappedEngine-Fuel.cag');
    Bpt1Name = 'f_tbrake_f_bpt';
else
    FiringTestPlanName = 'MappedEngine-Torque.mbt';
    if isSiMappedEng
        CageTemplate = fullfile(mbcpath,'mbctraining','SIMappedEngine-Torque.cag');
    else
        CageTemplate = fullfile(mbcpath,'mbctraining','CIMappedEngine-Torque.cag');
    end
    Bpt1Name = 'f_tbrake_t_bpt';
end

%% Waitbar setup
wh = waitbar(0, 'Generating mapped engine calibration');

%% Fit models in MBC
MBCProject = mbcmodel.CreateProject(MBCFileName);
WaitbarFrac(wh, 0.1);

% Define column names
AllFiringSignals = {'Torque', 'EngSpd', 'AirMassFlwRate', 'FuelMassFlwRate', ...
    'ExhTemp', 'BSFC', 'HCMassFlwRate', 'COMassFlwRate', 'NOxMassFlwRate', ...
    'CO2MassFlwRate', 'PMMassFlwRate'};
AllFiringUnits = {'N*m', 'rpm',	'kg/s', 'kg/s', 'K', 'g/(kW*h)', 'kg/s', 'kg/s', 'kg/s', 'kg/s', 'kg/s'};
RequiredFiringSignals = {'Torque', 'EngSpd'};
if UseFuelMassBpt
    AllFiringSignals = ['FuelMassCmd', AllFiringSignals];
    AllFiringUnits = ['mg', AllFiringUnits];
    RequiredFiringSignals = ['FuelMassCmd', RequiredFiringSignals];
end
AllMotoringSignals = {'Torque', 'EngSpd', 'AirMassFlwRate'};
AllMotoringUnits = {'N*m', 'rpm', 'kg/s'};
RequiredMotoringSignals = {'Torque', 'EngSpd'};

% Firing data
Dfiring = CreateData(MBCProject,XlsFileName,'auto','Firing Data');
Dfiring = SetupMBCData(Dfiring, AllFiringSignals, AllFiringUnits, RequiredFiringSignals, true, wh);
Tfiring = CreateTestplan(MBCProject, FiringTestPlanName);
WaitbarFrac(wh, 0.2);
AttachData(Tfiring,Dfiring,'UseDataRange',true,'Boundary',true);
WaitbarFrac(wh, 0.6);

% Non firing data
Dmotor = CreateData(MBCProject, XlsFileName, 'auto','Nonfiring Data');
Dmotor = SetupMBCData(Dmotor, AllMotoringSignals, AllMotoringUnits, RequiredMotoringSignals, false, wh);
WaitbarFrac(wh, 0.7);
Tmotor = CreateTestplan(MBCProject, 'MappedEngine-Nonfiring.mbt');
AttachData(Tmotor,Dmotor,'UseDataRange',true,'Boundary',false);
WaitbarFrac(wh, 0.8);

%% Fill tables using Cage

% Get all models
mdls = children(MBCProject.Object,@getBestExportModel);
mdls = [mdls{:}];

% Load templates and import model
cgp=load(CageTemplate,'-mat');
cgp = cgp.PROJ;

% Update breakpoints
Bpt1 = findItem(cgp,'Name', Bpt1Name);
dataRanges = getranges(mdls{1});
BptVals1 = get(info(Bpt1),'breakpoints');
BptVals1(:) = [0; linspace(dataRanges(1,2), dataRanges(2,2), numel(BptVals1)-1)'];

Bpt2Name = 'f_tbrake_n_bpt';
Bpt2 = findItem(cgp,'Name', Bpt2Name);
dataRanges = getranges(mdls{1});
BptVals2 = get(info(Bpt2),'breakpoints');
BptVals2(:) = [0; linspace(dataRanges(1,1), dataRanges(2,1), numel(BptVals2)-1)'];

% Update breakpoint values
updateBptVals(cgp, Bpt1Name, BptVals1);
updateBptVals(cgp, Bpt2Name, BptVals2);
updateOptimVals(cgp)
updateFeatureBpts(cgp)

WaitbarFrac(wh, 0.9);

% Refill tables
importModels(cgp,mdls,[],[],true);
WaitbarFrac(wh, 1);

%% Save and open files
% MBC
SaveAs(MBCProject, MBCFileName);
mbcmodel(MBCFileName)
rMBCMODEL = get(MBrowser,'RootNode');
if ~isempty(rMBCMODEL)
    file = rMBCMODEL.projectfile;
    
    % select BSFC model
    tp = rMBCMODEL.children(1);
    bsfc = tp.children(2);
   SelectNode(MBrowser, bsfc);
end


% Cage
projectfile(info(cgp), CageFileName);
save(info(cgp));
cage(CageFileName);
pCAGE = get(cgbrowser,'RootNode');
if ~isempty(pCAGE) 
    file = pCAGE.projectfile;
    
    % select 
    pTable = pCAGE.findItem('Name','f_eff','node');
    gotonode(cgbrowser,pTable,xregpointer);
end

%% Close waitbar
if ishandle(wh)
    close(wh)
end
end

%% GenMappedEngButton
function ApplyCalMappedEngButton(Block)
%% Load cage file
CageFileName = GetCageFileName(Block);
try
    cgp = info(get(cgbrowser,'RootNode'));
catch
   cgp = []; 
end
if isempty(cgp) || ~strcmp(CageFileName,projectfile(cgp))
    % get 
    CageFileName = GetCageFileName(Block);
    cgp = load(CageFileName,'-mat');
    cgp = cgp.PROJ;
    isCageLoaded = true;
else
    isCageLoaded = false;
end

%% Add tables to model workspace
% Get file name
MappedEngMdlRefName = get_param(Block, 'MappedEngMdlRefName');
MappedEngMdlRefFullName = which(MappedEngMdlRefName);

% Export tables to Simulink Model Workspace
cal=calibrationdata.matvariableinterface('filename',MappedEngMdlRefFullName);
calout = cgcaloutput(address(cgp),cal);
SL_WKSP_file(calout);
if isCageLoaded
    % close temporary CAGE project
    delete(info(cgp));
end

% Get speed and torque
hws = get_param(MappedEngMdlRefName,'modelworkspace');
f_tbrake_n_bpt = hws.evalin('f_tbrake_n_bpt');
f_tbrake = hws.evalin('f_tbrake');

% Close model
pause(1)
clear cal calout
[~, UseFuelMassBpt] = DetectBptType(MappedEngMdlRefName);

%% Update fuel mass table if CI with fuel mass input
if UseFuelMassBpt
    [~, ControllerMdlRefName] = fileparts(get_param([bdroot(Block), '/Engine System/Engine Controller/Engine Controller'], 'ModelFile'));
    open_system(ControllerMdlRefName);
    
    % Create table
    f_tbrake_f_bpt = hws.evalin('f_tbrake_f_bpt');
    [MappedEngFuelMassCmd, MappedEngSpd] = ndgrid(f_tbrake_f_bpt, f_tbrake_n_bpt);
    warning('off','MATLAB:scatteredInterpolant:DupPtsAvValuesWarnId');
    f = scatteredInterpolant(MappedEngSpd(:), f_tbrake(:), MappedEngFuelMassCmd(:), 'linear', 'nearest');   
    warning('on','MATLAB:scatteredInterpolant:DupPtsAvValuesWarnId');
    FuelSpd_bp = f_tbrake_n_bpt;
    FuelTrqCmd_bp = linspace(0, max(f_tbrake(:)), size(f_tbrake, 1));
    [X,Y] = meshgrid(FuelSpd_bp, FuelTrqCmd_bp);
    f_fcmd_tot = f(X,Y);
    f_fcmd_tot(1,:) = 0;
 
    % Apply to controller
    hwsc = get_param(ControllerMdlRefName,'modelworkspace');
    hwsc.assignin('f_fcmd_tot', f_fcmd_tot);
    hwsc.assignin('f_f_tot_tq_bpt', FuelTrqCmd_bp);
    hwsc.assignin('f_f_tot_n_bpt', FuelSpd_bp);
    
    % Close model
    pause(1)
    close_system(ControllerMdlRefName, 1);
end

close_system(MappedEngMdlRefName, 1);
%% Update dynamometer test points
hws = get_param(bdroot(Block),'modelworkspace');
SteadyEngSpdCmdPts = hws.evalin('SteadyEngSpdCmdPts');
EngSpdBpts = linspace(750, max(f_tbrake_n_bpt), size(SteadyEngSpdCmdPts, 2));
TrqBpts = linspace(0, max(f_tbrake(:)), size(SteadyEngSpdCmdPts, 1)+1);
TrqBpts = TrqBpts(2:end);
[SteadyTrqCmdPts, SteadyEngSpdCmdPts] = ndgrid(TrqBpts, EngSpdBpts);
hws.assignin('SteadyEngSpdCmdPts', SteadyEngSpdCmdPts);
hws.assignin('SteadyTrqCmdPts', SteadyTrqCmdPts);

%% Select mapped engine variant
EngVariantBlk = [bdroot(Block), '/Engine System/Engine Plant/Engine'];
EngMdlRefNames = find_system(bdroot(Block), 'LookUnderMasks', 'All', 'Variants', 'AllVariants', 'Parent', EngVariantBlk, 'BlockType', 'ModelReference');
for i = 1:length(EngMdlRefNames)
    if strcmp(which(get_param(EngMdlRefNames{i}, 'ModelFile')), which(MappedEngMdlRefName))
        set_param(EngVariantBlk,'OverrideUsingVariant', get_param(EngMdlRefNames{i}, 'VariantControl'))
        % Set Tag
        set_param(EngMdlRefNames{i}, 'Tag', 'MappedEngCalByMBC')
        
        % Update mask icon
        UpdateParentIcon(EngVariantBlk)
        break; 
    end
end

%% Run simulation
close_system(Block)
pause(0.01);
open_system(Block)
DynamometerStart(gcb, 'SteadyState')

end

%% OpenMBCFile
function OpenMBCFile(Block)
MBCFileName = GetMBCPrjName(Block);
mbcmodel(MBCFileName)
end

%% OpenCageFile
function OpenCageFile(Block)
CageFileName = GetCageFileName(Block);
cage(CageFileName);
end

%% WaitbarFrac
function WaitbarFrac(wh, Frac)
    if ishandle(wh)
       waitbar(Frac, wh); 
    end
end

%% CheckMBCLicense
function isMBCInstalled = CheckMBCLicense(Block)
MaskObj = Simulink.Mask.get(Block);  
GenMappedEngCalButton = MaskObj.getDialogControl('GenMappedEngCalButton');
ApplyCalMappedEngButton = MaskObj.getDialogControl('ApplyCalMappedEngButton');
MBCIconImg = MaskObj.getDialogControl('MBCIconImg');

if license('test', 'MBC_Toolbox')
    GenMappedEngCalButton.Enabled = 'on';
    ApplyCalMappedEngButton.Enabled = 'on';
    MBCIconImg.Enabled = 'on';
    MBCIconImg.Visible = 'on';
    isMBCInstalled = true;   
else
    GenMappedEngCalButton.Enabled = 'off';
    ApplyCalMappedEngButton.Enabled = 'off';
    MBCIconImg.Enabled = 'off';
    MBCIconImg.Visible = 'off';
    isMBCInstalled = false;
end

end

%% UpdateParentIcon
function UpdateParentIcon(Block)
while ~isempty(get_param(Block,'Parent'))
    set_param(Block, 'Position', get_param(Block,'Position'))
    Block = get_param(Block,'Parent');
end
end

%% GetMBCPrjName
function MBCFileName = GetMBCPrjName(Block)
[~, FileName] = fileparts(get_param(Block,'MBCProjectName'));
FullMfileName = mfilename('fullpath');
PathName = fileparts(FullMfileName);
Ext = '.mat';
if ~isempty(PathName)
    PathName = [PathName, '\'];
end
MBCFileName = [PathName, FileName, Ext];
end

%% GetCageFileName
function CageFileName = GetCageFileName(Block)
[~, FileName] = fileparts(get_param(Block,'CageFileName'));
FullMfileName = mfilename('fullpath');
PathName = fileparts(FullMfileName);
Ext = '.cag';
if ~isempty(PathName)
    PathName = [PathName, '\'];
end
CageFileName = [PathName, FileName, Ext];
end

%% SetupMBCData
function Data = SetupMBCData(Data, AllNames, AllUnits, RequiredNames, isFiringData, wh)
% Check required data
for i = 1:length(RequiredNames)
    if ~any(strcmp(RequiredNames{i}, Data.SignalNames))
        if isFiringData
            WorksheetName = 'Firing Data';
        else
            WorksheetName = 'Nonfiring Data';
        end
        if ishandle(wh)
            close(wh)
        end
        error('''%s'' worksheet must have a column labeled ''%s''', WorksheetName, RequiredNames{i})
    end
end

% Add variables for missing columns
Data.BeginEdit;
for i = 1:length(AllNames)
    if ~any(strcmp(AllNames{i}, Data.SignalNames))
        Data.AddVariable([AllNames{i}, ' = 0'], AllUnits{i});
    end
end
Data.CommitEdit;
end

%% DetectBptType
function [isSiMappedEng, UseFuelMassBpt] = DetectBptType(MappedEngMdlRefName)
CiMappedEngBlks = find_system(MappedEngMdlRefName, 'ReferenceBlock', 'autolibsharedmappedengines/Mapped CI Engine');
UseFuelMassBpt = false;
isSiMappedEng = true;
if ~isempty(CiMappedEngBlks)
    if strcmp(get_param(CiMappedEngBlks{1}, 'InputCmdPopup'), 'Fuel mass')
        UseFuelMassBpt = true;
    end
    isSiMappedEng = false;
end
end

%% updateBptVals
function updateBptVals(cgp, BptName, BptVals)
    BptPtr = findItem(cgp,'Name', BptName);
    BptPtr.info = set(info(BptPtr),'breakpoints',BptVals);
end

%% updateOptimVals
function updateOptimVals(cgp)
pTables = findItem(cgp,'type','Table','data');
pOptim = findItem(cgp,'type','Optimization','data');
pInps = cell(size(pTables));

for j = 1:length(pTables)
    pInps{j} = getinports(pTables(j).info);
end
for i=1:length(pOptim)
    optim = pOptim(i).info;
    [pVal, ~] = getfixedvaluedata(optim);
    for j = 1:length(pTables) 
        [OK,~]=ismember(pInps{j},pVal);
        if all(OK)
            pOptim(i).info = setinitialvaluedatafromtablegrid(optim,pTables(j));
            break;
        end
    end
end
    
end

%% updateFeatureBpts
function updateFeatureBpts(cgp)
    pFeature = findItem(cgp,'type','Feature','data');
    for i = 1:length(pFeature)
        FeatureFill = get(info(pFeature(i)),'cgsimfill');
        for j = 1:length(FeatureFill)
            ValCell = FeatureFill(j).Values;
            ValNames = ValCell(1:round(length(ValCell)/2));
            FillVals = ValCell((round(length(ValCell)/2)+1):end);
            
            Normalizers = info(get(FeatureFill(j).Tables.Object, 'normalizers'));
            NumNorm = length(Normalizers);
            
            
            for k = 1:NumNorm
                NormName = get(Normalizers{k},'xname');
                NormSelect = strcmp(NormName, ValNames);
                if any(NormSelect)
                    if length(FillVals{NormSelect}) > 1
                        FillVals{NormSelect} = get(Normalizers{k},'allbreakpoints');
                    end
                end
            end
            NewValCell = cell(size(ValCell));
            for k = 1:length(ValNames)
                NewValCell{2*(k-1)+1} = ValNames{k};
                NewValCell{2*(k-1)+2} = FillVals{k};
            end
            FeatureFill(j).Values = NewValCell;
        end
    end
end
