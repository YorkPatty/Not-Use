#include <stddef.h>
#include "rtw_capi.h"
#ifdef HOST_CAPI_BUILD
#include "SiEngineCore_capi_host.h"
#define sizeof(s) ((size_t)(0xFFFF))
#undef rt_offsetof
#define rt_offsetof(s,el) ((uint16_T)(0xFFFF))
#define TARGET_CONST
#define TARGET_STRING(s) (s)    
#else
#include "builtin_typeid_types.h"
#include "SiEngineCore.h"
#include "SiEngineCore_capi.h"
#include "SiEngineCore_private.h"
#ifdef LIGHT_WEIGHT_CAPI
#define TARGET_CONST                  
#define TARGET_STRING(s)               (NULL)                    
#else
#define TARGET_CONST                   const
#define TARGET_STRING(s)               (s)
#endif
#endif
static rtwCAPI_Signals rtBlockSignals [ ] = { { 0 , 0 , ( NULL ) , ( NULL ) ,
0 , 0 , 0 , 0 , 0 } } ; static rtwCAPI_States rtBlockStates [ ] = { { 0 , 35
, TARGET_STRING ( "SiEngineCore/Engine Coolant Temperature/Integrator" ) ,
TARGET_STRING ( "" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 , 1 , - 1 , 0
} , { 1 , 16 , TARGET_STRING (
"SiEngineCore/Boost Drive Shaft/Shaft Dynamics/Integrator" ) , TARGET_STRING
( "" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 , 1 , - 1 , 0 } , { 2 , 42
, TARGET_STRING (
 "SiEngineCore/Intake Manifold/HeatTrnsfr External Wall Convection/Thermal Effects/Integrator1"
) , TARGET_STRING ( "" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 , 1 , - 1
, 0 } , { 3 , 43 , TARGET_STRING (
 "SiEngineCore/SI Core Engine/Core Engine Model/Engine Crank Angle Calculation/Integrator"
) , TARGET_STRING ( "" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 , 1 , - 1
, 0 } , { 4 , 0 , TARGET_STRING (
 "SiEngineCore/Air Intake System/Control Volume Reformatted/Control Volume/Pressure and Temperature/Integrator1"
) , TARGET_STRING ( "" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 , 1 , - 1
, 0 } , { 5 , 1 , TARGET_STRING (
 "SiEngineCore/Air Intake System/Control Volume Reformatted/Control Volume/Pressure and Temperature/Integrator2"
) , TARGET_STRING ( "" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 , 1 , - 1
, 0 } , { 6 , 20 , TARGET_STRING (
 "SiEngineCore/Compressor Output Volume/Control Volume Reformatted/Control Volume/Pressure and Temperature/Integrator1"
) , TARGET_STRING ( "" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 , 1 , - 1
, 0 } , { 7 , 17 , TARGET_STRING (
 "SiEngineCore/Compressor Output Volume/Control Volume Reformatted/Control Volume/Pressure and Temperature/Integrator2"
) , TARGET_STRING ( "" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 , 1 , - 1
, 0 } , { 8 , 18 , TARGET_STRING (
 "SiEngineCore/Exhaust Manifold/Control Volume Reformatted/Control Volume/Pressure and Temperature/Integrator1"
) , TARGET_STRING ( "" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 , 1 , - 1
, 0 } , { 9 , 19 , TARGET_STRING (
 "SiEngineCore/Exhaust Manifold/Control Volume Reformatted/Control Volume/Pressure and Temperature/Integrator2"
) , TARGET_STRING ( "" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 , 1 , - 1
, 0 } , { 10 , 15 , TARGET_STRING (
 "SiEngineCore/Exhaust System Volume/Control Volume Reformatted/Control Volume/Pressure and Temperature/Integrator1"
) , TARGET_STRING ( "" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 , 1 , - 1
, 0 } , { 11 , 14 , TARGET_STRING (
 "SiEngineCore/Exhaust System Volume/Control Volume Reformatted/Control Volume/Pressure and Temperature/Integrator2"
) , TARGET_STRING ( "" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 , 1 , - 1
, 0 } , { 12 , 34 , TARGET_STRING (
 "SiEngineCore/Intake Manifold/Control Volume Reformatted/Control Volume/Pressure and Temperature/Integrator1"
) , TARGET_STRING ( "" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 , 1 , - 1
, 0 } , { 13 , 27 , TARGET_STRING (
 "SiEngineCore/Intake Manifold/Control Volume Reformatted/Control Volume/Pressure and Temperature/Integrator2"
) , TARGET_STRING ( "" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 , 1 , - 1
, 0 } , { 14 , 2 , TARGET_STRING (
 "SiEngineCore/Air Intake System/Control Volume Reformatted/Control Volume/Mass Fractions/Mass Fraction Integration/Integrator"
) , TARGET_STRING ( "" ) , TARGET_STRING ( "" ) , 0 , 0 , 1 , 0 , 0 , 1 , - 1
, 0 } , { 15 , 21 , TARGET_STRING (
 "SiEngineCore/Compressor Output Volume/Control Volume Reformatted/Control Volume/Mass Fractions/Mass Fraction Integration/Integrator"
) , TARGET_STRING ( "" ) , TARGET_STRING ( "" ) , 0 , 0 , 1 , 0 , 0 , 1 , - 1
, 0 } , { 16 , 36 , TARGET_STRING (
 "SiEngineCore/Exhaust Manifold/Control Volume Reformatted/Control Volume/Mass Fractions/Mass Fraction Integration/Integrator"
) , TARGET_STRING ( "" ) , TARGET_STRING ( "" ) , 0 , 0 , 1 , 0 , 0 , 1 , - 1
, 0 } , { 17 , 8 , TARGET_STRING (
 "SiEngineCore/Exhaust System Volume/Control Volume Reformatted/Control Volume/Mass Fractions/Mass Fraction Integration/Integrator"
) , TARGET_STRING ( "" ) , TARGET_STRING ( "" ) , 0 , 0 , 1 , 0 , 0 , 1 , - 1
, 0 } , { 18 , 28 , TARGET_STRING (
 "SiEngineCore/Intake Manifold/Control Volume Reformatted/Control Volume/Mass Fractions/Mass Fraction Integration/Integrator"
) , TARGET_STRING ( "" ) , TARGET_STRING ( "" ) , 0 , 0 , 1 , 0 , 0 , 1 , - 1
, 0 } , { 0 , - 1 , ( NULL ) , ( NULL ) , ( NULL ) , 0 , 0 , 0 , 0 , 0 , 0 ,
- 1 , 0 } } ;
#ifndef HOST_CAPI_BUILD
static void SiEngineCore_InitializeDataAddr ( void * dataAddr [ ] ,
a44w4cdtf2 * localDW , fvgaykwdlx * localX ) { dataAddr [ 0 ] = ( void * ) (
& localX -> pp3sbmt411 ) ; dataAddr [ 1 ] = ( void * ) ( & localX ->
m0ygypyt4l ) ; dataAddr [ 2 ] = ( void * ) ( & localX -> pavjyll3pw ) ;
dataAddr [ 3 ] = ( void * ) ( & localX -> paegvaid45 ) ; dataAddr [ 4 ] = (
void * ) ( & localX -> l5l4j3zpbv ) ; dataAddr [ 5 ] = ( void * ) ( & localX
-> avdzeav3af ) ; dataAddr [ 6 ] = ( void * ) ( & localX -> c2lcgqv0iu ) ;
dataAddr [ 7 ] = ( void * ) ( & localX -> egqothsxuk ) ; dataAddr [ 8 ] = (
void * ) ( & localX -> e1vm4eatwr ) ; dataAddr [ 9 ] = ( void * ) ( & localX
-> ip1u1basin ) ; dataAddr [ 10 ] = ( void * ) ( & localX -> mo2nwvmesw ) ;
dataAddr [ 11 ] = ( void * ) ( & localX -> eamjnr0z3s ) ; dataAddr [ 12 ] = (
void * ) ( & localX -> kikzskuefz ) ; dataAddr [ 13 ] = ( void * ) ( & localX
-> cva0fgs4rq ) ; dataAddr [ 14 ] = ( void * ) ( & localX -> hx4sgebyr2 [ 0 ]
) ; dataAddr [ 15 ] = ( void * ) ( & localX -> eqsccsj2uk [ 0 ] ) ; dataAddr
[ 16 ] = ( void * ) ( & localX -> lgqkezkrvb [ 0 ] ) ; dataAddr [ 17 ] = (
void * ) ( & localX -> bdd3ra5zox [ 0 ] ) ; dataAddr [ 18 ] = ( void * ) ( &
localX -> hgi0nf3zhn [ 0 ] ) ; }
#endif
#ifndef HOST_CAPI_BUILD
static void SiEngineCore_InitializeVarDimsAddr ( int32_T * vardimsAddr [ ] )
{ vardimsAddr [ 0 ] = ( NULL ) ; }
#endif
#ifndef HOST_CAPI_BUILD
static void SiEngineCore_InitializeLoggingFunctions ( RTWLoggingFcnPtr
loggingPtrs [ ] ) { loggingPtrs [ 0 ] = ( NULL ) ; loggingPtrs [ 1 ] = ( NULL
) ; loggingPtrs [ 2 ] = ( NULL ) ; loggingPtrs [ 3 ] = ( NULL ) ; loggingPtrs
[ 4 ] = ( NULL ) ; loggingPtrs [ 5 ] = ( NULL ) ; loggingPtrs [ 6 ] = ( NULL
) ; loggingPtrs [ 7 ] = ( NULL ) ; loggingPtrs [ 8 ] = ( NULL ) ; loggingPtrs
[ 9 ] = ( NULL ) ; loggingPtrs [ 10 ] = ( NULL ) ; loggingPtrs [ 11 ] = (
NULL ) ; loggingPtrs [ 12 ] = ( NULL ) ; loggingPtrs [ 13 ] = ( NULL ) ;
loggingPtrs [ 14 ] = ( NULL ) ; loggingPtrs [ 15 ] = ( NULL ) ; loggingPtrs [
16 ] = ( NULL ) ; loggingPtrs [ 17 ] = ( NULL ) ; loggingPtrs [ 18 ] = ( NULL
) ; }
#endif
static TARGET_CONST rtwCAPI_DataTypeMap rtDataTypeMap [ ] = { { "double" ,
"real_T" , 0 , 0 , sizeof ( real_T ) , SS_DOUBLE , 0 , 0 , 0 } } ;
#ifdef HOST_CAPI_BUILD
#undef sizeof
#endif
static TARGET_CONST rtwCAPI_ElementMap rtElementMap [ ] = { { ( NULL ) , 0 ,
0 , 0 , 0 } , } ; static rtwCAPI_DimensionMap rtDimensionMap [ ] = { {
rtwCAPI_SCALAR , 0 , 2 , 0 } , { rtwCAPI_VECTOR , 2 , 2 , 0 } } ; static
uint_T rtDimensionArray [ ] = { 1 , 1 , 6 , 1 } ; static const real_T
rtcapiStoredFloats [ ] = { 0.0 } ; static rtwCAPI_FixPtMap rtFixPtMap [ ] = {
{ ( NULL ) , ( NULL ) , rtwCAPI_FIX_RESERVED , 0 , 0 , 0 } , } ; static
rtwCAPI_SampleTimeMap rtSampleTimeMap [ ] = { { ( const void * ) &
rtcapiStoredFloats [ 0 ] , ( const void * ) & rtcapiStoredFloats [ 0 ] , 0 ,
0 } } ; static int_T rtContextSystems [ 35 ] ; static rtwCAPI_LoggingMetaInfo
loggingMetaInfo [ ] = { { 0 , 0 , "" , 0 } } ; static
rtwCAPI_ModelMapLoggingStaticInfo mmiStaticInfoLogging = { 35 ,
rtContextSystems , loggingMetaInfo , 0 , NULL , { 0 , NULL , NULL } , 0 , (
NULL ) } ; static rtwCAPI_ModelMappingStaticInfo mmiStatic = { {
rtBlockSignals , 0 , ( NULL ) , 0 , ( NULL ) , 0 } , { ( NULL ) , 0 , ( NULL
) , 0 } , { rtBlockStates , 19 } , { rtDataTypeMap , rtDimensionMap ,
rtFixPtMap , rtElementMap , rtSampleTimeMap , rtDimensionArray } , "float" ,
{ 1904755286U , 815884486U , 762470081U , 1368937605U } , &
mmiStaticInfoLogging , 0 , 0 } ; const rtwCAPI_ModelMappingStaticInfo *
SiEngineCore_GetCAPIStaticMap ( void ) { return & mmiStatic ; }
#ifndef HOST_CAPI_BUILD
static void SiEngineCore_InitializeSystemRan ( cfm545pqpj * const nkgnf0b0jx
, sysRanDType * systemRan [ ] , a44w4cdtf2 * localDW , int_T systemTid [ ] ,
void * rootSysRanPtr , int rootTid ) { UNUSED_PARAMETER ( nkgnf0b0jx ) ;
UNUSED_PARAMETER ( localDW ) ; systemRan [ 0 ] = ( sysRanDType * )
rootSysRanPtr ; systemRan [ 1 ] = ( NULL ) ; systemRan [ 2 ] = ( NULL ) ;
systemRan [ 3 ] = ( NULL ) ; systemRan [ 4 ] = ( NULL ) ; systemRan [ 5 ] = (
NULL ) ; systemRan [ 6 ] = ( NULL ) ; systemRan [ 7 ] = ( NULL ) ; systemRan
[ 8 ] = ( NULL ) ; systemRan [ 9 ] = ( NULL ) ; systemRan [ 10 ] = ( NULL ) ;
systemRan [ 11 ] = ( NULL ) ; systemRan [ 12 ] = ( NULL ) ; systemRan [ 13 ]
= ( NULL ) ; systemRan [ 14 ] = ( NULL ) ; systemRan [ 15 ] = ( NULL ) ;
systemRan [ 16 ] = ( NULL ) ; systemRan [ 17 ] = ( NULL ) ; systemRan [ 18 ]
= ( NULL ) ; systemRan [ 19 ] = ( NULL ) ; systemRan [ 20 ] = ( NULL ) ;
systemRan [ 21 ] = ( NULL ) ; systemRan [ 22 ] = ( NULL ) ; systemRan [ 23 ]
= ( NULL ) ; systemRan [ 24 ] = ( NULL ) ; systemRan [ 25 ] = ( NULL ) ;
systemRan [ 26 ] = ( NULL ) ; systemRan [ 27 ] = ( NULL ) ; systemRan [ 28 ]
= ( NULL ) ; systemRan [ 29 ] = ( NULL ) ; systemRan [ 30 ] = ( sysRanDType *
) & localDW -> nr00hdz5ht ; systemRan [ 31 ] = ( NULL ) ; systemRan [ 32 ] =
( sysRanDType * ) & localDW -> gwlzbf4hjm ; systemRan [ 33 ] = ( NULL ) ;
systemRan [ 34 ] = ( NULL ) ; systemTid [ 1 ] = nkgnf0b0jx -> Timing .
mdlref_GlobalTID [ 0 ] ; systemTid [ 3 ] = nkgnf0b0jx -> Timing .
mdlref_GlobalTID [ 0 ] ; systemTid [ 5 ] = nkgnf0b0jx -> Timing .
mdlref_GlobalTID [ 0 ] ; systemTid [ 7 ] = nkgnf0b0jx -> Timing .
mdlref_GlobalTID [ 0 ] ; systemTid [ 9 ] = nkgnf0b0jx -> Timing .
mdlref_GlobalTID [ 0 ] ; systemTid [ 11 ] = nkgnf0b0jx -> Timing .
mdlref_GlobalTID [ 0 ] ; systemTid [ 13 ] = nkgnf0b0jx -> Timing .
mdlref_GlobalTID [ 0 ] ; systemTid [ 15 ] = nkgnf0b0jx -> Timing .
mdlref_GlobalTID [ 0 ] ; systemTid [ 17 ] = nkgnf0b0jx -> Timing .
mdlref_GlobalTID [ 0 ] ; systemTid [ 19 ] = nkgnf0b0jx -> Timing .
mdlref_GlobalTID [ 0 ] ; systemTid [ 2 ] = nkgnf0b0jx -> Timing .
mdlref_GlobalTID [ 0 ] ; systemTid [ 4 ] = nkgnf0b0jx -> Timing .
mdlref_GlobalTID [ 0 ] ; systemTid [ 6 ] = nkgnf0b0jx -> Timing .
mdlref_GlobalTID [ 0 ] ; systemTid [ 8 ] = nkgnf0b0jx -> Timing .
mdlref_GlobalTID [ 0 ] ; systemTid [ 10 ] = nkgnf0b0jx -> Timing .
mdlref_GlobalTID [ 0 ] ; systemTid [ 12 ] = nkgnf0b0jx -> Timing .
mdlref_GlobalTID [ 0 ] ; systemTid [ 14 ] = nkgnf0b0jx -> Timing .
mdlref_GlobalTID [ 0 ] ; systemTid [ 16 ] = nkgnf0b0jx -> Timing .
mdlref_GlobalTID [ 0 ] ; systemTid [ 18 ] = nkgnf0b0jx -> Timing .
mdlref_GlobalTID [ 0 ] ; systemTid [ 20 ] = nkgnf0b0jx -> Timing .
mdlref_GlobalTID [ 0 ] ; systemTid [ 21 ] = nkgnf0b0jx -> Timing .
mdlref_GlobalTID [ 0 ] ; systemTid [ 22 ] = nkgnf0b0jx -> Timing .
mdlref_GlobalTID [ 0 ] ; systemTid [ 23 ] = nkgnf0b0jx -> Timing .
mdlref_GlobalTID [ 0 ] ; systemTid [ 24 ] = nkgnf0b0jx -> Timing .
mdlref_GlobalTID [ 0 ] ; systemTid [ 25 ] = nkgnf0b0jx -> Timing .
mdlref_GlobalTID [ 0 ] ; systemTid [ 26 ] = nkgnf0b0jx -> Timing .
mdlref_GlobalTID [ 0 ] ; systemTid [ 27 ] = nkgnf0b0jx -> Timing .
mdlref_GlobalTID [ 0 ] ; systemTid [ 28 ] = nkgnf0b0jx -> Timing .
mdlref_GlobalTID [ 0 ] ; systemTid [ 29 ] = nkgnf0b0jx -> Timing .
mdlref_GlobalTID [ 0 ] ; systemTid [ 30 ] = nkgnf0b0jx -> Timing .
mdlref_GlobalTID [ 0 ] ; systemTid [ 31 ] = nkgnf0b0jx -> Timing .
mdlref_GlobalTID [ 0 ] ; systemTid [ 32 ] = nkgnf0b0jx -> Timing .
mdlref_GlobalTID [ 0 ] ; systemTid [ 33 ] = nkgnf0b0jx -> Timing .
mdlref_GlobalTID [ 0 ] ; systemTid [ 34 ] = nkgnf0b0jx -> Timing .
mdlref_GlobalTID [ 0 ] ; systemTid [ 0 ] = rootTid ; rtContextSystems [ 0 ] =
0 ; rtContextSystems [ 1 ] = 0 ; rtContextSystems [ 2 ] = 0 ;
rtContextSystems [ 3 ] = 0 ; rtContextSystems [ 4 ] = 0 ; rtContextSystems [
5 ] = 0 ; rtContextSystems [ 6 ] = 0 ; rtContextSystems [ 7 ] = 0 ;
rtContextSystems [ 8 ] = 0 ; rtContextSystems [ 9 ] = 0 ; rtContextSystems [
10 ] = 0 ; rtContextSystems [ 11 ] = 0 ; rtContextSystems [ 12 ] = 0 ;
rtContextSystems [ 13 ] = 0 ; rtContextSystems [ 14 ] = 0 ; rtContextSystems
[ 15 ] = 0 ; rtContextSystems [ 16 ] = 0 ; rtContextSystems [ 17 ] = 0 ;
rtContextSystems [ 18 ] = 0 ; rtContextSystems [ 19 ] = 0 ; rtContextSystems
[ 20 ] = 0 ; rtContextSystems [ 21 ] = 0 ; rtContextSystems [ 22 ] = 0 ;
rtContextSystems [ 23 ] = 0 ; rtContextSystems [ 24 ] = 0 ; rtContextSystems
[ 25 ] = 0 ; rtContextSystems [ 26 ] = 0 ; rtContextSystems [ 27 ] = 0 ;
rtContextSystems [ 28 ] = 0 ; rtContextSystems [ 29 ] = 0 ; rtContextSystems
[ 30 ] = 30 ; rtContextSystems [ 31 ] = 32 ; rtContextSystems [ 32 ] = 32 ;
rtContextSystems [ 33 ] = 0 ; rtContextSystems [ 34 ] = 0 ; }
#endif
#ifndef HOST_CAPI_BUILD
void SiEngineCore_InitializeDataMapInfo ( cfm545pqpj * const nkgnf0b0jx ,
a44w4cdtf2 * localDW , fvgaykwdlx * localX , void * sysRanPtr , int
contextTid ) { rtwCAPI_SetVersion ( nkgnf0b0jx -> DataMapInfo . mmi , 1 ) ;
rtwCAPI_SetStaticMap ( nkgnf0b0jx -> DataMapInfo . mmi , & mmiStatic ) ;
rtwCAPI_SetLoggingStaticMap ( nkgnf0b0jx -> DataMapInfo . mmi , &
mmiStaticInfoLogging ) ; SiEngineCore_InitializeDataAddr ( nkgnf0b0jx ->
DataMapInfo . dataAddress , localDW , localX ) ; rtwCAPI_SetDataAddressMap (
nkgnf0b0jx -> DataMapInfo . mmi , nkgnf0b0jx -> DataMapInfo . dataAddress ) ;
SiEngineCore_InitializeVarDimsAddr ( nkgnf0b0jx -> DataMapInfo .
vardimsAddress ) ; rtwCAPI_SetVarDimsAddressMap ( nkgnf0b0jx -> DataMapInfo .
mmi , nkgnf0b0jx -> DataMapInfo . vardimsAddress ) ; rtwCAPI_SetPath (
nkgnf0b0jx -> DataMapInfo . mmi , ( NULL ) ) ; rtwCAPI_SetFullPath (
nkgnf0b0jx -> DataMapInfo . mmi , ( NULL ) ) ;
SiEngineCore_InitializeLoggingFunctions ( nkgnf0b0jx -> DataMapInfo .
loggingPtrs ) ; rtwCAPI_SetLoggingPtrs ( nkgnf0b0jx -> DataMapInfo . mmi ,
nkgnf0b0jx -> DataMapInfo . loggingPtrs ) ; rtwCAPI_SetInstanceLoggingInfo (
nkgnf0b0jx -> DataMapInfo . mmi , & nkgnf0b0jx -> DataMapInfo .
mmiLogInstanceInfo ) ; rtwCAPI_SetChildMMIArray ( nkgnf0b0jx -> DataMapInfo .
mmi , ( NULL ) ) ; rtwCAPI_SetChildMMIArrayLen ( nkgnf0b0jx -> DataMapInfo .
mmi , 0 ) ; SiEngineCore_InitializeSystemRan ( nkgnf0b0jx , nkgnf0b0jx ->
DataMapInfo . systemRan , localDW , nkgnf0b0jx -> DataMapInfo . systemTid ,
sysRanPtr , contextTid ) ; rtwCAPI_SetSystemRan ( nkgnf0b0jx -> DataMapInfo .
mmi , nkgnf0b0jx -> DataMapInfo . systemRan ) ; rtwCAPI_SetSystemTid (
nkgnf0b0jx -> DataMapInfo . mmi , nkgnf0b0jx -> DataMapInfo . systemTid ) ;
rtwCAPI_SetGlobalTIDMap ( nkgnf0b0jx -> DataMapInfo . mmi , & nkgnf0b0jx ->
Timing . mdlref_GlobalTID [ 0 ] ) ; }
#else
#ifdef __cplusplus
extern "C" {
#endif
void SiEngineCore_host_InitializeDataMapInfo (
SiEngineCore_host_DataMapInfo_T * dataMap , const char * path ) {
rtwCAPI_SetVersion ( dataMap -> mmi , 1 ) ; rtwCAPI_SetStaticMap ( dataMap ->
mmi , & mmiStatic ) ; rtwCAPI_SetDataAddressMap ( dataMap -> mmi , NULL ) ;
rtwCAPI_SetVarDimsAddressMap ( dataMap -> mmi , NULL ) ; rtwCAPI_SetPath (
dataMap -> mmi , path ) ; rtwCAPI_SetFullPath ( dataMap -> mmi , NULL ) ;
rtwCAPI_SetChildMMIArray ( dataMap -> mmi , ( NULL ) ) ;
rtwCAPI_SetChildMMIArrayLen ( dataMap -> mmi , 0 ) ; }
#ifdef __cplusplus
}
#endif
#endif
