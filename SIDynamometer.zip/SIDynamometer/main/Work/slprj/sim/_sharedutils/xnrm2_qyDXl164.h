#ifndef SHARE_xnrm2_qyDXl164
#define SHARE_xnrm2_qyDXl164
#include "rtwtypes.h"
#include "multiword_types.h"

extern real_T xnrm2_qyDXl164(int32_T n, const real_T x[9], int32_T ix0);

#endif
