#ifndef SHARE_abs_hkr6DNuf
#define SHARE_abs_hkr6DNuf
#include "rtwtypes.h"
#include "multiword_types.h"

extern void abs_hkr6DNuf(const real_T x[3], real_T y[3]);

#endif
