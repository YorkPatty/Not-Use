#include "rtwtypes.h"
#include "multiword_types.h"
#include "mwmathutil.h"
#include "abs_hkr6DNuf.h"

void abs_hkr6DNuf(const real_T x[3], real_T y[3])
{
  y[0] = muDoubleScalarAbs(x[0]);
  y[1] = muDoubleScalarAbs(x[1]);
  y[2] = muDoubleScalarAbs(x[2]);
}
