#include "rtwtypes.h"
#include "multiword_types.h"
#include "Unconstrained_JyMVUyCN.h"

void Unconstrained_JyMVUyCN(const real_T b_Hinv[9], const real_T f[3], real_T x
  [3], int16_T n)
{
  int32_T i;
  int32_T i_p;
  for (i = 1; i - 1 < n; i++) {
    i_p = (int16_T)i;
    x[(int16_T)i - 1] = (-b_Hinv[i_p - 1] * f[0] + -b_Hinv[i_p + 2] * f[1]) +
      -b_Hinv[i_p + 5] * f[2];
  }
}
