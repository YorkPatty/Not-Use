#ifndef SHARE_qr_9QZWIWY8
#define SHARE_qr_9QZWIWY8
#include "rtwtypes.h"
#include "multiword_types.h"

extern void qr_9QZWIWY8(const real_T b_A[9], real_T Q[9], real_T R[9]);

#endif
