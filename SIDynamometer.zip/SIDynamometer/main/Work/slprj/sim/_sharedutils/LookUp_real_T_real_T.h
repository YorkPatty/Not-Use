#ifndef RTW_HEADER_LookUp_real_T_real_T_h_
#define RTW_HEADER_LookUp_real_T_real_T_h_
#include "rtwtypes.h"
#include "multiword_types.h"

void LookUp_real_T_real_T(real_T *pY, const real_T *pYData, real_T u, const
  real_T *pUData, uint32_T iHi);

#endif
