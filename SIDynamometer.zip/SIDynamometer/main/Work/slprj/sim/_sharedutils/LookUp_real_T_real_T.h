#ifndef SHARE_LookUp_real_T_real_T
#define SHARE_LookUp_real_T_real_T
#include "rtwtypes.h"
#include "multiword_types.h"

void LookUp_real_T_real_T(real_T *pY, const real_T *pYData, real_T u, const
  real_T *pUData, uint32_T iHi);

#endif
