#ifndef RTW_HEADER_BINARYSEARCH_real_T_h_
#define RTW_HEADER_BINARYSEARCH_real_T_h_
#include "rtwtypes.h"
#include "multiword_types.h"

void BINARYSEARCH_real_T(uint32_T *piLeft, uint32_T *piRght, real_T u, const
  real_T *pData, uint32_T iHi);

#endif
