#ifndef SHARE_BINARYSEARCH_real_T
#define SHARE_BINARYSEARCH_real_T
#include "rtwtypes.h"
#include "multiword_types.h"

void BINARYSEARCH_real_T(uint32_T *piLeft, uint32_T *piRght, real_T u, const
  real_T *pData, uint32_T iHi);

#endif
