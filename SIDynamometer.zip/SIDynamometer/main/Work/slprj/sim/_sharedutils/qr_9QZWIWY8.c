#include "rtwtypes.h"
#include "multiword_types.h"
#include <string.h>
#include "mwmathutil.h"
#include "xgemv_hH1PWjtp.h"
#include "xgerc_WGdrj717.h"
#include "xnrm2_qyDXl164.h"
#include "qr_9QZWIWY8.h"

void qr_9QZWIWY8(const real_T b_A[9], real_T Q[9], real_T R[9])
{
  real_T c_A[9];
  real_T work[3];
  real_T b_atmp;
  real_T beta1;
  int32_T knt;
  int32_T lastc;
  int32_T coltop;
  int32_T b_coltop;
  real_T tau_idx_0;
  real_T tau_idx_1;
  int32_T exitg1;
  boolean_T exitg2;
  tau_idx_0 = 0.0;
  tau_idx_1 = 0.0;
  memcpy(&c_A[0], &b_A[0], 9U * sizeof(real_T));
  work[0] = 0.0;
  work[1] = 0.0;
  work[2] = 0.0;
  b_atmp = c_A[0];
  beta1 = xnrm2_qyDXl164(2, c_A, 2);
  if (beta1 != 0.0) {
    beta1 = muDoubleScalarHypot(c_A[0], beta1);
    if (c_A[0] >= 0.0) {
      beta1 = -beta1;
    }

    if (muDoubleScalarAbs(beta1) < 1.0020841800044864E-292) {
      knt = -1;
      lastc = 0;
      do {
        knt++;
        for (coltop = 1; coltop < 3; coltop++) {
          c_A[coltop] *= 9.9792015476736E+291;
        }

        beta1 *= 9.9792015476736E+291;
        b_atmp *= 9.9792015476736E+291;
      } while (!(muDoubleScalarAbs(beta1) >= 1.0020841800044864E-292));

      beta1 = muDoubleScalarHypot(b_atmp, xnrm2_qyDXl164(2, c_A, 2));
      if (b_atmp >= 0.0) {
        beta1 = -beta1;
      }

      tau_idx_0 = (beta1 - b_atmp) / beta1;
      b_atmp = 1.0 / (b_atmp - beta1);
      for (coltop = 1; coltop < 3; coltop++) {
        c_A[coltop] *= b_atmp;
      }

      while (lastc <= knt) {
        beta1 *= 1.0020841800044864E-292;
        lastc++;
      }

      b_atmp = beta1;
    } else {
      tau_idx_0 = (beta1 - c_A[0]) / beta1;
      b_atmp = 1.0 / (c_A[0] - beta1);
      for (lastc = 1; lastc < 3; lastc++) {
        c_A[lastc] *= b_atmp;
      }

      b_atmp = beta1;
    }
  }

  c_A[0] = 1.0;
  if (tau_idx_0 != 0.0) {
    knt = 3;
    lastc = 0;
    while ((knt > 0) && (c_A[lastc + 2] == 0.0)) {
      knt--;
      lastc--;
    }

    lastc = 2;
    exitg2 = false;
    while ((!exitg2) && (lastc > 0)) {
      coltop = (lastc - 1) * 3 + 3;
      b_coltop = coltop;
      do {
        exitg1 = 0;
        if (b_coltop + 1 <= coltop + knt) {
          if (c_A[b_coltop] != 0.0) {
            exitg1 = 1;
          } else {
            b_coltop++;
          }
        } else {
          lastc--;
          exitg1 = 2;
        }
      } while (exitg1 == 0);

      if (exitg1 == 1) {
        exitg2 = true;
      }
    }
  } else {
    knt = 0;
    lastc = 0;
  }

  if (knt > 0) {
    xgemv_hH1PWjtp(knt, lastc, c_A, 4, c_A, 1, work);
    xgerc_WGdrj717(knt, lastc, -tau_idx_0, 1, work, c_A, 4);
  }

  c_A[0] = b_atmp;
  b_atmp = c_A[4];
  beta1 = xnrm2_qyDXl164(1, c_A, 6);
  if (beta1 != 0.0) {
    beta1 = muDoubleScalarHypot(c_A[4], beta1);
    if (c_A[4] >= 0.0) {
      beta1 = -beta1;
    }

    if (muDoubleScalarAbs(beta1) < 1.0020841800044864E-292) {
      knt = -1;
      do {
        knt++;
        for (coltop = 5; coltop < 6; coltop++) {
          c_A[coltop] *= 9.9792015476736E+291;
        }

        beta1 *= 9.9792015476736E+291;
        b_atmp *= 9.9792015476736E+291;
      } while (!(muDoubleScalarAbs(beta1) >= 1.0020841800044864E-292));

      beta1 = muDoubleScalarHypot(b_atmp, xnrm2_qyDXl164(1, c_A, 6));
      if (b_atmp >= 0.0) {
        beta1 = -beta1;
      }

      tau_idx_1 = (beta1 - b_atmp) / beta1;
      b_atmp = 1.0 / (b_atmp - beta1);
      for (coltop = 5; coltop < 6; coltop++) {
        c_A[coltop] *= b_atmp;
      }

      for (lastc = 0; lastc <= knt; lastc++) {
        beta1 *= 1.0020841800044864E-292;
      }

      b_atmp = beta1;
    } else {
      tau_idx_1 = (beta1 - c_A[4]) / beta1;
      b_atmp = 1.0 / (c_A[4] - beta1);
      for (lastc = 5; lastc < 6; lastc++) {
        c_A[lastc] *= b_atmp;
      }

      b_atmp = beta1;
    }
  }

  c_A[4] = 1.0;
  if (tau_idx_1 != 0.0) {
    knt = 2;
    lastc = 3;
    while ((knt > 0) && (c_A[lastc + 2] == 0.0)) {
      knt--;
      lastc--;
    }

    lastc = 1;
    b_coltop = 7;
    do {
      exitg1 = 0;
      if (b_coltop + 1 <= 7 + knt) {
        if (c_A[b_coltop] != 0.0) {
          exitg1 = 1;
        } else {
          b_coltop++;
        }
      } else {
        lastc = 0;
        exitg1 = 1;
      }
    } while (exitg1 == 0);
  } else {
    knt = 0;
    lastc = 0;
  }

  if (knt > 0) {
    xgemv_hH1PWjtp(knt, lastc, c_A, 8, c_A, 5, work);
    xgerc_WGdrj717(knt, lastc, -tau_idx_1, 5, work, c_A, 8);
  }

  c_A[4] = b_atmp;
  R[0] = c_A[0];
  for (lastc = 1; lastc + 1 < 4; lastc++) {
    R[lastc] = 0.0;
  }

  work[0] = 0.0;
  for (lastc = 0; lastc < 2; lastc++) {
    R[lastc + 3] = c_A[lastc + 3];
  }

  while (lastc + 1 < 4) {
    R[lastc + 3] = 0.0;
    lastc++;
  }

  work[1] = 0.0;
  for (lastc = 0; lastc < 3; lastc++) {
    R[lastc + 6] = c_A[lastc + 6];
  }

  work[2] = 0.0;
  c_A[8] = 1.0;
  for (lastc = 0; lastc < 2; lastc++) {
    c_A[7 - lastc] = 0.0;
  }

  c_A[4] = 1.0;
  if (tau_idx_1 != 0.0) {
    coltop = 7;
    while ((lastc > 0) && (c_A[coltop - 2] == 0.0)) {
      lastc--;
      coltop--;
    }

    coltop = 1;
    knt = 8;
    do {
      exitg1 = 0;
      if (knt <= lastc + 7) {
        if (c_A[knt - 1] != 0.0) {
          exitg1 = 1;
        } else {
          knt++;
        }
      } else {
        coltop = 0;
        exitg1 = 1;
      }
    } while (exitg1 == 0);
  } else {
    lastc = 0;
    coltop = 0;
  }

  if (lastc > 0) {
    xgemv_hH1PWjtp(lastc, coltop, c_A, 8, c_A, 5, work);
    xgerc_WGdrj717(lastc, coltop, -tau_idx_1, 5, work, c_A, 8);
  }

  for (coltop = 5; coltop < 6; coltop++) {
    c_A[coltop] *= -tau_idx_1;
  }

  c_A[4] = 1.0 - tau_idx_1;
  c_A[3] = 0.0;
  c_A[0] = 1.0;
  if (tau_idx_0 != 0.0) {
    lastc = 3;
    coltop = 4;
    while ((lastc > 0) && (c_A[coltop - 2] == 0.0)) {
      lastc--;
      coltop--;
    }

    coltop = 2;
    exitg2 = false;
    while ((!exitg2) && (coltop > 0)) {
      b_coltop = (coltop - 1) * 3 + 4;
      knt = b_coltop;
      do {
        exitg1 = 0;
        if (knt <= (b_coltop + lastc) - 1) {
          if (c_A[knt - 1] != 0.0) {
            exitg1 = 1;
          } else {
            knt++;
          }
        } else {
          coltop--;
          exitg1 = 2;
        }
      } while (exitg1 == 0);

      if (exitg1 == 1) {
        exitg2 = true;
      }
    }
  } else {
    lastc = 0;
    coltop = 0;
  }

  if (lastc > 0) {
    xgemv_hH1PWjtp(lastc, coltop, c_A, 4, c_A, 1, work);
    xgerc_WGdrj717(lastc, coltop, -tau_idx_0, 1, work, c_A, 4);
  }

  for (coltop = 1; coltop < 3; coltop++) {
    c_A[coltop] *= -tau_idx_0;
  }

  c_A[0] = 1.0 - tau_idx_0;
  for (lastc = 0; lastc < 3; lastc++) {
    Q[3 * lastc] = c_A[3 * lastc];
    coltop = 3 * lastc + 1;
    Q[coltop] = c_A[coltop];
    coltop = 3 * lastc + 2;
    Q[coltop] = c_A[coltop];
  }
}
