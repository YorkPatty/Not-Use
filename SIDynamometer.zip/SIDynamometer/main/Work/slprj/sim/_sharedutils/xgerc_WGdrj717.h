#ifndef SHARE_xgerc_WGdrj717
#define SHARE_xgerc_WGdrj717
#include "rtwtypes.h"
#include "multiword_types.h"

extern void xgerc_WGdrj717(int32_T m, int32_T n, real_T alpha1, int32_T ix0,
  const real_T y[3], real_T b_A[9], int32_T ia0);

#endif
