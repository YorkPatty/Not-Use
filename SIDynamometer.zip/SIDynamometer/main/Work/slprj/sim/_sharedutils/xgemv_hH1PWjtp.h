#ifndef SHARE_xgemv_hH1PWjtp
#define SHARE_xgemv_hH1PWjtp
#include "rtwtypes.h"
#include "multiword_types.h"

extern void xgemv_hH1PWjtp(int32_T m, int32_T n, const real_T b_A[9], int32_T
  ia0, const real_T x[9], int32_T ix0, real_T y[3]);

#endif
