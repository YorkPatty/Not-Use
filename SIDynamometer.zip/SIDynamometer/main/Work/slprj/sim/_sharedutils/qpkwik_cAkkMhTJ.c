#include "rtwtypes.h"
#include "multiword_types.h"
#include "DropConstraint_tGe3MFFU.h"
#include "KWIKfactor_K1eBpzjs.h"
#include "Unconstrained_JyMVUyCN.h"
#include "abs_hkr6DNuf.h"
#include "abs_lf2wV9oj.h"
#include "mwmathutil.h"
#include "norm_fEVfzPfQ.h"
#include "qpkwik_cAkkMhTJ.h"

void qpkwik_cAkkMhTJ(const real_T b_Linv[9], const real_T b_Hinv[9], const
                     real_T f[3], const real_T b_Ac[12], const real_T b[4],
                     int16_T iA[4], int16_T maxiter, real_T FeasTol, real_T x[3],
                     real_T lambda[4], real_T *status)
{
  real_T r[3];
  real_T rMin;
  real_T RLinv[9];
  real_T D[9];
  real_T b_H[9];
  real_T U[9];
  real_T cTol[4];
  boolean_T cTolComputed;
  int16_T iC[4];
  int16_T nA;
  real_T Opt[6];
  real_T Rhs[6];
  boolean_T DualFeasible;
  boolean_T ColdReset;
  int16_T kDrop;
  real_T Xnorm0;
  real_T cMin;
  int16_T kNext;
  real_T cVal;
  real_T AcRow[3];
  real_T t;
  real_T varargin_1[4];
  int32_T idx;
  int32_T f_k;
  int32_T i;
  real_T b_Ac_p[3];
  int32_T tmp;
  int32_T Rhs_tmp;
  int32_T r_tmp;
  int32_T U_tmp;
  int32_T exitg1;
  int32_T exitg2;
  int32_T exitg3;
  boolean_T exitg4;
  int32_T exitg5;
  boolean_T guard1 = false;
  boolean_T guard2 = false;
  *status = 1.0;
  lambda[0] = 0.0;
  lambda[1] = 0.0;
  lambda[2] = 0.0;
  lambda[3] = 0.0;
  x[0] = 0.0;
  r[0] = 0.0;
  x[1] = 0.0;
  r[1] = 0.0;
  x[2] = 0.0;
  r[2] = 0.0;
  rMin = 0.0;
  cTolComputed = false;
  cTol[0] = 1.0;
  iC[0] = 0;
  cTol[1] = 1.0;
  iC[1] = 0;
  cTol[2] = 1.0;
  iC[2] = 0;
  cTol[3] = 1.0;
  iC[3] = 0;
  nA = 0;
  if (iA[0] == 1) {
    nA = 1;
    iC[0] = 1;
  }

  if (iA[1] == 1) {
    r_tmp = nA + 1;
    nA = (int16_T)r_tmp;
    iC[(int16_T)r_tmp - 1] = 2;
  }

  if (iA[2] == 1) {
    r_tmp = nA + 1;
    nA = (int16_T)r_tmp;
    iC[(int16_T)r_tmp - 1] = 3;
  }

  if (iA[3] == 1) {
    r_tmp = nA + 1;
    nA = (int16_T)r_tmp;
    iC[(int16_T)r_tmp - 1] = 4;
  }

  guard1 = false;
  if (nA > 0) {
    for (i = 0; i < 6; i++) {
      Opt[i] = 0.0;
    }

    Rhs[0] = f[0];
    Rhs[3] = 0.0;
    Rhs[1] = f[1];
    Rhs[4] = 0.0;
    Rhs[2] = f[2];
    Rhs[5] = 0.0;
    DualFeasible = false;
    ColdReset = false;
    do {
      exitg3 = 0;
      if ((!DualFeasible) && (nA > 0) && ((int32_T)*status <= maxiter)) {
        Xnorm0 = KWIKfactor_K1eBpzjs(b_Ac, iC, nA, b_Linv, RLinv, D, b_H, 3);
        if (Xnorm0 < 0.0) {
          if (ColdReset) {
            *status = -2.0;
            exitg3 = 2;
          } else {
            nA = 0;
            iA[0] = 0;
            iC[0] = 0;
            iA[1] = 0;
            iC[1] = 0;
            iA[2] = 0;
            iC[2] = 0;
            iA[3] = 0;
            iC[3] = 0;
            ColdReset = true;
          }
        } else {
          i = 1;
          do {
            exitg5 = 0;
            r_tmp = nA - 1;
            if (i - 1 <= r_tmp) {
              f_k = (int16_T)i + 3;
              if (f_k > 32767) {
                f_k = 32767;
              }

              Rhs_tmp = (int16_T)i - 1;
              Rhs[f_k - 1] = b[iC[Rhs_tmp] - 1];
              for (kNext = (int16_T)i; kNext <= nA; kNext++) {
                f_k = (kNext + 3 * Rhs_tmp) - 1;
                U[f_k] = 0.0;
                for (idx = 1; idx - 1 <= r_tmp; idx++) {
                  U_tmp = ((int16_T)idx - 1) * 3;
                  U[f_k] += RLinv[(U_tmp + kNext) - 1] * RLinv[(U_tmp + (int16_T)
                    i) - 1];
                }

                U[((int16_T)i + 3 * (kNext - 1)) - 1] = U[f_k];
              }

              i++;
            } else {
              exitg5 = 1;
            }
          } while (exitg5 == 0);

          for (i = 0; i < 3; i++) {
            idx = i + 1;
            Opt[i] = (b_H[idx - 1] * Rhs[0] + b_H[idx + 2] * Rhs[1]) + b_H[idx +
              5] * Rhs[2];
            for (idx = 1; idx - 1 <= r_tmp; idx++) {
              f_k = (int16_T)idx + 3;
              if (f_k > 32767) {
                f_k = 32767;
              }

              Opt[i] += D[((int16_T)idx - 1) * 3 + i] * Rhs[f_k - 1];
            }
          }

          for (i = 1; i - 1 <= r_tmp; i++) {
            f_k = (int16_T)i + 3;
            Rhs_tmp = f_k;
            if (f_k > 32767) {
              Rhs_tmp = 32767;
            }

            idx = ((int16_T)i - 1) * 3;
            Opt[Rhs_tmp - 1] = (D[idx + 1] * Rhs[1] + D[idx] * Rhs[0]) + D[idx +
              2] * Rhs[2];
            for (idx = 1; idx - 1 <= r_tmp; idx++) {
              Rhs_tmp = f_k;
              if (f_k > 32767) {
                Rhs_tmp = 32767;
              }

              U_tmp = f_k;
              if (f_k > 32767) {
                U_tmp = 32767;
              }

              tmp = (int16_T)idx + 3;
              if (tmp > 32767) {
                tmp = 32767;
              }

              Opt[Rhs_tmp - 1] = U[(((int16_T)idx - 1) * 3 + (int16_T)i) - 1] *
                Rhs[tmp - 1] + Opt[U_tmp - 1];
            }
          }

          Xnorm0 = -1.0E-12;
          kDrop = 0;
          for (i = 1; i - 1 <= r_tmp; i++) {
            f_k = (int16_T)i + 3;
            Rhs_tmp = f_k;
            if (f_k > 32767) {
              Rhs_tmp = 32767;
            }

            lambda[iC[(int16_T)i - 1] - 1] = Opt[Rhs_tmp - 1];
            Rhs_tmp = f_k;
            if (f_k > 32767) {
              Rhs_tmp = 32767;
            }

            if ((Opt[Rhs_tmp - 1] < Xnorm0) && ((int16_T)i <= nA)) {
              kDrop = (int16_T)i;
              if (f_k > 32767) {
                f_k = 32767;
              }

              Xnorm0 = Opt[f_k - 1];
            }
          }

          if (kDrop <= 0) {
            DualFeasible = true;
            x[0] = Opt[0];
            x[1] = Opt[1];
            x[2] = Opt[2];
          } else {
            (*status)++;
            if ((int32_T)*status > 5) {
              nA = 0;
              iA[0] = 0;
              iC[0] = 0;
              iA[1] = 0;
              iC[1] = 0;
              iA[2] = 0;
              iC[2] = 0;
              iA[3] = 0;
              iC[3] = 0;
              ColdReset = true;
            } else {
              lambda[iC[kDrop - 1] - 1] = 0.0;
              DropConstraint_tGe3MFFU(kDrop, iA, &nA, iC);
            }
          }
        }
      } else {
        if (nA <= 0) {
          lambda[0] = 0.0;
          lambda[1] = 0.0;
          lambda[2] = 0.0;
          lambda[3] = 0.0;
          Unconstrained_JyMVUyCN(b_Hinv, f, x, 3);
        }

        exitg3 = 1;
      }
    } while (exitg3 == 0);

    if (exitg3 == 1) {
      guard1 = true;
    }
  } else {
    Unconstrained_JyMVUyCN(b_Hinv, f, x, 3);
    guard1 = true;
  }

  if (guard1) {
    Xnorm0 = norm_fEVfzPfQ(x);
    do {
      exitg2 = 0;
      r_tmp = (int32_T)*status;
      if (r_tmp <= maxiter) {
        cMin = -FeasTol;
        kNext = 0;
        for (i = 0; i < 4; i++) {
          if (!cTolComputed) {
            idx = i + 1;
            b_Ac_p[0] = b_Ac[idx - 1] * x[0];
            b_Ac_p[1] = b_Ac[idx + 3] * x[1];
            b_Ac_p[2] = b_Ac[idx + 7] * x[2];
            abs_hkr6DNuf(b_Ac_p, AcRow);
            if (!muDoubleScalarIsNaN(AcRow[0])) {
              idx = 1;
            } else {
              idx = 0;
              f_k = 2;
              exitg4 = false;
              while ((!exitg4) && (f_k < 4)) {
                if (!muDoubleScalarIsNaN(AcRow[f_k - 1])) {
                  idx = f_k;
                  exitg4 = true;
                } else {
                  f_k++;
                }
              }
            }

            if (idx == 0) {
              cVal = AcRow[0];
            } else {
              cVal = AcRow[idx - 1];
              while (idx + 1 <= 3) {
                if (cVal < AcRow[idx]) {
                  cVal = AcRow[idx];
                }

                idx++;
              }
            }

            cTol[i] = muDoubleScalarMax(cTol[i], cVal);
          }

          if (iA[i] == 0) {
            idx = i + 1;
            cVal = (((b_Ac[idx - 1] * x[0] + b_Ac[idx + 3] * x[1]) + b_Ac[idx +
                     7] * x[2]) - b[i]) / cTol[i];
            if (cVal < cMin) {
              cMin = cVal;
              kNext = (int16_T)(i + 1);
            }
          }
        }

        cTolComputed = true;
        if (kNext <= 0) {
          exitg2 = 1;
        } else if (r_tmp == maxiter) {
          *status = 0.0;
          exitg2 = 1;
        } else {
          do {
            exitg1 = 0;
            if ((kNext > 0) && ((int32_T)*status <= maxiter)) {
              guard2 = false;
              if (nA == 0) {
                for (r_tmp = 0; r_tmp < 3; r_tmp++) {
                  AcRow[r_tmp] = b_Hinv[r_tmp + 6] * b_Ac[kNext + 7] +
                    (b_Hinv[r_tmp + 3] * b_Ac[kNext + 3] + b_Ac[kNext - 1] *
                     b_Hinv[r_tmp]);
                }

                guard2 = true;
              } else {
                cMin = KWIKfactor_K1eBpzjs(b_Ac, iC, nA, b_Linv, RLinv, D, b_H,
                  3);
                if (cMin <= 0.0) {
                  *status = -2.0;
                  exitg1 = 1;
                } else {
                  for (r_tmp = 0; r_tmp < 9; r_tmp++) {
                    U[r_tmp] = -b_H[r_tmp];
                  }

                  for (r_tmp = 0; r_tmp < 3; r_tmp++) {
                    AcRow[r_tmp] = U[r_tmp + 6] * b_Ac[kNext + 7] + (U[r_tmp + 3]
                      * b_Ac[kNext + 3] + b_Ac[kNext - 1] * U[r_tmp]);
                  }

                  for (i = 1; i - 1 < nA; i++) {
                    r_tmp = ((int16_T)i - 1) * 3;
                    r[(int16_T)i - 1] = (D[r_tmp + 1] * b_Ac[kNext + 3] +
                                         D[r_tmp] * b_Ac[kNext - 1]) + D[r_tmp +
                      2] * b_Ac[kNext + 7];
                  }

                  guard2 = true;
                }
              }

              if (guard2) {
                kDrop = 0;
                cMin = 0.0;
                DualFeasible = true;
                ColdReset = true;
                if (nA > 0) {
                  i = 0;
                  exitg4 = false;
                  while ((!exitg4) && (i <= nA - 1)) {
                    if (r[i] >= 1.0E-12) {
                      ColdReset = false;
                      exitg4 = true;
                    } else {
                      i++;
                    }
                  }
                }

                if ((nA != 0) && (!ColdReset)) {
                  for (i = 1; i - 1 < nA; i++) {
                    r_tmp = (int16_T)i - 1;
                    if (r[r_tmp] > 1.0E-12) {
                      cVal = lambda[iC[r_tmp] - 1] / r[r_tmp];
                      if ((kDrop == 0) || (cVal < rMin)) {
                        rMin = cVal;
                        kDrop = (int16_T)i;
                      }
                    }
                  }

                  if (kDrop > 0) {
                    cMin = rMin;
                    DualFeasible = false;
                  }
                }

                idx = kNext - 1;
                i = kNext + 3;
                r_tmp = kNext + 7;
                cVal = (b_Ac[idx] * AcRow[0] + b_Ac[i] * AcRow[1]) + b_Ac[r_tmp]
                  * AcRow[2];
                if (cVal <= 0.0) {
                  cVal = 0.0;
                  ColdReset = true;
                } else {
                  cVal = (b[idx] - ((b_Ac[idx] * x[0] + b_Ac[i] * x[1]) +
                                    b_Ac[r_tmp] * x[2])) / cVal;
                  ColdReset = false;
                }

                if (DualFeasible && ColdReset) {
                  *status = -1.0;
                  exitg1 = 1;
                } else {
                  if (ColdReset) {
                    t = cMin;
                  } else if (DualFeasible) {
                    t = cVal;
                  } else {
                    t = muDoubleScalarMin(cMin, cVal);
                  }

                  for (i = 1; i - 1 < nA; i++) {
                    r_tmp = (int16_T)i - 1;
                    f_k = iC[r_tmp] - 1;
                    lambda[f_k] -= r[r_tmp] * t;
                    if ((iC[r_tmp] <= 4) && (lambda[f_k] < 0.0)) {
                      lambda[f_k] = 0.0;
                    }
                  }

                  lambda[idx] += t;
                  if (t == cMin) {
                    DropConstraint_tGe3MFFU(kDrop, iA, &nA, iC);
                  }

                  if (!ColdReset) {
                    x[0] += t * AcRow[0];
                    x[1] += t * AcRow[1];
                    x[2] += t * AcRow[2];
                    if (t == cVal) {
                      if (nA == 3) {
                        *status = -1.0;
                        exitg1 = 1;
                      } else {
                        r_tmp = nA + 1;
                        if (r_tmp > 32767) {
                          r_tmp = 32767;
                        }

                        nA = (int16_T)r_tmp;
                        iC[(int16_T)r_tmp - 1] = kNext;
                        kDrop = (int16_T)r_tmp;
                        exitg4 = false;
                        while ((!exitg4) && (kDrop > 1)) {
                          r_tmp = kDrop - 1;
                          f_k = kDrop - 2;
                          if (iC[r_tmp] > iC[f_k]) {
                            exitg4 = true;
                          } else {
                            kNext = iC[r_tmp];
                            iC[r_tmp] = iC[f_k];
                            iC[f_k] = kNext;
                            kDrop = (int16_T)r_tmp;
                          }
                        }

                        iA[idx] = 1;
                        kNext = 0;
                        (*status)++;
                      }
                    } else {
                      (*status)++;
                    }
                  } else {
                    (*status)++;
                  }
                }
              }
            } else {
              cMin = norm_fEVfzPfQ(x);
              if (muDoubleScalarAbs(cMin - Xnorm0) > 0.001) {
                Xnorm0 = cMin;
                abs_lf2wV9oj(b, varargin_1);
                cTol[0] = muDoubleScalarMax(varargin_1[0], 1.0);
                cTol[1] = muDoubleScalarMax(varargin_1[1], 1.0);
                cTol[2] = muDoubleScalarMax(varargin_1[2], 1.0);
                cTol[3] = muDoubleScalarMax(varargin_1[3], 1.0);
                cTolComputed = false;
              }

              exitg1 = 2;
            }
          } while (exitg1 == 0);

          if (exitg1 == 1) {
            exitg2 = 1;
          }
        }
      } else {
        exitg2 = 1;
      }
    } while (exitg2 == 0);
  }
}
