#ifndef SHARE_qpkwik_cAkkMhTJ
#define SHARE_qpkwik_cAkkMhTJ
#include "rtwtypes.h"
#include "multiword_types.h"

extern void qpkwik_cAkkMhTJ(const real_T b_Linv[9], const real_T b_Hinv[9],
  const real_T f[3], const real_T b_Ac[12], const real_T b[4], int16_T iA[4],
  int16_T maxiter, real_T FeasTol, real_T x[3], real_T lambda[4], real_T *status);

#endif
