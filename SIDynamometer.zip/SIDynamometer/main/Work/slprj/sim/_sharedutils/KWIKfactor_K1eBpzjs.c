#include "rtwtypes.h"
#include "multiword_types.h"
#include "mwmathutil.h"
#include "qr_9QZWIWY8.h"
#include "KWIKfactor_K1eBpzjs.h"

real_T KWIKfactor_K1eBpzjs(const real_T b_Ac[12], const int16_T iC[4], int16_T
  nA, const real_T b_Linv[9], real_T RLinv[9], real_T D[9], real_T b_H[9],
  int16_T n)
{
  real_T Status;
  real_T TL[9];
  real_T QQ[9];
  real_T RR[9];
  int32_T i;
  int16_T b_j;
  int16_T c_k;
  int32_T f_i;
  int32_T i_p;
  int32_T tmp;
  int32_T TL_tmp;
  int32_T TL_tmp_p;
  int32_T tmp_p;
  int32_T exitg1;
  int32_T exitg2;
  Status = 1.0;
  for (i_p = 0; i_p < 9; i_p++) {
    RLinv[i_p] = 0.0;
  }

  i = 1;
  do {
    exitg1 = 0;
    i_p = nA - 1;
    if (i - 1 <= i_p) {
      TL_tmp = (int16_T)i - 1;
      f_i = iC[TL_tmp];
      for (i_p = 0; i_p < 3; i_p++) {
        tmp = i_p + 3 * TL_tmp;
        RLinv[tmp] = 0.0;
        RLinv[tmp] += b_Ac[f_i - 1] * b_Linv[i_p];
        RLinv[tmp] += b_Linv[i_p + 3] * b_Ac[f_i + 3];
        RLinv[tmp] += b_Linv[i_p + 6] * b_Ac[f_i + 7];
      }

      i++;
    } else {
      exitg1 = 1;
    }
  } while (exitg1 == 0);

  qr_9QZWIWY8(RLinv, QQ, RR);
  i = 1;
  do {
    exitg1 = 0;
    if (i - 1 <= i_p) {
      if (muDoubleScalarAbs(RR[(((int16_T)i - 1) * 3 + (int16_T)i) - 1]) <
          1.0E-12) {
        Status = -2.0;
        exitg1 = 1;
      } else {
        i++;
      }
    } else {
      i = 1;
      do {
        exitg2 = 0;
        tmp = n - 1;
        if (i - 1 <= tmp) {
          for (f_i = 1; f_i - 1 <= tmp; f_i++) {
            TL_tmp = ((int16_T)i - 1) * 3;
            TL_tmp_p = ((int16_T)f_i - 1) * 3;
            TL[((int16_T)i + 3 * ((int16_T)f_i - 1)) - 1] = (b_Linv[TL_tmp + 1] *
              QQ[TL_tmp_p + 1] + b_Linv[TL_tmp] * QQ[TL_tmp_p]) + b_Linv[TL_tmp
              + 2] * QQ[TL_tmp_p + 2];
          }

          i++;
        } else {
          exitg2 = 1;
        }
      } while (exitg2 == 0);

      for (TL_tmp = 0; TL_tmp < 9; TL_tmp++) {
        RLinv[TL_tmp] = 0.0;
      }

      b_j = nA;
      while (b_j > 0) {
        TL_tmp = b_j - 1;
        TL_tmp_p = 3 * TL_tmp;
        f_i = (b_j + TL_tmp_p) - 1;
        RLinv[f_i] = 1.0;
        for (c_k = b_j; c_k <= nA; c_k++) {
          tmp_p = ((c_k - 1) * 3 + b_j) - 1;
          RLinv[tmp_p] /= RR[f_i];
        }

        if (b_j > 1) {
          for (i = 1; i - 1 <= b_j - 2; i++) {
            for (c_k = b_j; c_k <= nA; c_k++) {
              f_i = (c_k - 1) * 3;
              tmp_p = (f_i + (int16_T)i) - 1;
              RLinv[tmp_p] -= RR[(TL_tmp_p + (int16_T)i) - 1] * RLinv[(f_i + b_j)
                - 1];
            }
          }
        }

        b_j = (int16_T)TL_tmp;
      }

      for (i = 1; i - 1 <= tmp; i++) {
        for (b_j = (int16_T)i; b_j <= n; b_j++) {
          TL_tmp = ((int16_T)i + 3 * (b_j - 1)) - 1;
          b_H[TL_tmp] = 0.0;
          TL_tmp_p = nA + 1;
          if (TL_tmp_p > 32767) {
            TL_tmp_p = 32767;
          }

          for (c_k = (int16_T)TL_tmp_p; c_k <= n; c_k++) {
            TL_tmp_p = (c_k - 1) * 3;
            b_H[TL_tmp] -= TL[(TL_tmp_p + (int16_T)i) - 1] * TL[(TL_tmp_p + b_j)
              - 1];
          }

          b_H[(b_j + 3 * ((int16_T)i - 1)) - 1] = b_H[TL_tmp];
        }
      }

      for (i = 1; i - 1 <= i_p; i++) {
        for (f_i = 1; f_i - 1 <= tmp; f_i++) {
          TL_tmp = ((int16_T)f_i + 3 * ((int16_T)i - 1)) - 1;
          D[TL_tmp] = 0.0;
          for (b_j = (int16_T)i; b_j <= nA; b_j++) {
            TL_tmp_p = (b_j - 1) * 3;
            D[TL_tmp] += TL[(TL_tmp_p + (int16_T)f_i) - 1] * RLinv[(TL_tmp_p +
              (int16_T)i) - 1];
          }
        }
      }

      exitg1 = 1;
    }
  } while (exitg1 == 0);

  return Status;
}
