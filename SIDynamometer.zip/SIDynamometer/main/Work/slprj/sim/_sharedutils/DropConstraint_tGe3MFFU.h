#ifndef SHARE_DropConstraint_tGe3MFFU
#define SHARE_DropConstraint_tGe3MFFU
#include "rtwtypes.h"
#include "multiword_types.h"

extern void DropConstraint_tGe3MFFU(int16_T kDrop, int16_T iA[4], int16_T *nA,
  int16_T iC[4]);

#endif
