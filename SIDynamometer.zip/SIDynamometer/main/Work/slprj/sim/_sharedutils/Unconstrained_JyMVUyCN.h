#ifndef SHARE_Unconstrained_JyMVUyCN
#define SHARE_Unconstrained_JyMVUyCN
#include "rtwtypes.h"
#include "multiword_types.h"

extern void Unconstrained_JyMVUyCN(const real_T b_Hinv[9], const real_T f[3],
  real_T x[3], int16_T n);

#endif
