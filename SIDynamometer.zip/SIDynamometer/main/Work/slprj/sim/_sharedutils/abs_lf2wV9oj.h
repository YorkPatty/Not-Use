#ifndef SHARE_abs_lf2wV9oj
#define SHARE_abs_lf2wV9oj
#include "rtwtypes.h"
#include "multiword_types.h"

extern void abs_lf2wV9oj(const real_T x[4], real_T y[4]);

#endif
