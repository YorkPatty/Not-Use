#ifndef SHARE_KWIKfactor_K1eBpzjs
#define SHARE_KWIKfactor_K1eBpzjs
#include "rtwtypes.h"
#include "multiword_types.h"

extern real_T KWIKfactor_K1eBpzjs(const real_T b_Ac[12], const int16_T iC[4],
  int16_T nA, const real_T b_Linv[9], real_T RLinv[9], real_T D[9], real_T b_H[9],
  int16_T n);

#endif
