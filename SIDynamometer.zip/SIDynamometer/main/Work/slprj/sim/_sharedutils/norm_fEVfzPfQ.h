#ifndef SHARE_norm_fEVfzPfQ
#define SHARE_norm_fEVfzPfQ
#include "rtwtypes.h"
#include "multiword_types.h"

extern real_T norm_fEVfzPfQ(const real_T x[3]);

#endif
