#ifndef RTW_HEADER_SiEngineController_types_h_
#define RTW_HEADER_SiEngineController_types_h_
#include "rtwtypes.h"
#include "builtin_typeid_types.h"
#include "multiword_types.h"
#ifndef DEFINED_TYPEDEF_FOR_struct_qYRJtcce7MM7XuQ3AAWdMD_
#define DEFINED_TYPEDEF_FOR_struct_qYRJtcce7MM7XuQ3AAWdMD_
typedef struct { real_T MaxIterations ; real_T ConstraintTolerance ;
boolean_T UseWarmStart ; uint8_T sl_padding0 [ 7 ] ; }
struct_qYRJtcce7MM7XuQ3AAWdMD ;
#endif
#ifndef DEFINED_TYPEDEF_FOR_struct_SmvKLCDySlKdToNTroAGyF_
#define DEFINED_TYPEDEF_FOR_struct_SmvKLCDySlKdToNTroAGyF_
typedef struct { real_T MaxIterations ; real_T ConstraintTolerance ; real_T
OptimalityTolerance ; real_T ComplementarityTolerance ; real_T StepTolerance
; } struct_SmvKLCDySlKdToNTroAGyF ;
#endif
typedef struct naryjiu2ypt_ naryjiu2ypt ; typedef struct mvxg2sjgqu
fjokl4fytp ;
#endif
