#ifndef RTW_HEADER_SiEngineController_capi_h_
#define RTW_HEADER_SiEngineController_capi_h_
#include "SiEngineController.h"
extern void SiEngineController_InitializeDataMapInfo ( fjokl4fytp * const
hxsxflkffh , co1aiayk40 * localDW , void * sysRanPtr , int contextTid ) ;
#endif
