#ifndef RTW_HEADER_SiEngineCore_types_h_
#define RTW_HEADER_SiEngineCore_types_h_
#include "rtwtypes.h"
#include "model_reference_types.h"
#include "builtin_typeid_types.h"
#include "multiword_types.h"
#ifndef DEFINED_TYPEDEF_FOR_struct_yYS3FnWJrVqtPO3qgXk8tB_
#define DEFINED_TYPEDEF_FOR_struct_yYS3FnWJrVqtPO3qgXk8tB_
typedef struct { real_T AirO2MassFrac ; real_T AirN2MassFrac ; }
struct_yYS3FnWJrVqtPO3qgXk8tB ;
#endif
typedef struct nno4qjngixf_ nno4qjngixf ; typedef struct iwgh44im0y
cfm545pqpj ;
#endif
