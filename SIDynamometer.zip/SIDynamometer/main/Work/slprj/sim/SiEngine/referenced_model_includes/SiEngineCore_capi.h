#ifndef RTW_HEADER_SiEngineCore_capi_h_
#define RTW_HEADER_SiEngineCore_capi_h_
#include "SiEngineCore.h"
extern void SiEngineCore_InitializeDataMapInfo ( cfm545pqpj * const
nkgnf0b0jx , a44w4cdtf2 * localDW , fvgaykwdlx * localX , void * sysRanPtr ,
int contextTid ) ;
#endif
