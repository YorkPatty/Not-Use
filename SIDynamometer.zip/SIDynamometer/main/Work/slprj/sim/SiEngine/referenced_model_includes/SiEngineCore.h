#ifndef RTW_HEADER_SiEngineCore_h_
#define RTW_HEADER_SiEngineCore_h_
#include <string.h>
#include <stddef.h>
#include "rtw_modelmap.h"
#ifndef SiEngineCore_COMMON_INCLUDES_
#define SiEngineCore_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "slsv_diagnostic_codegen_c_api.h"
#include "sl_AsyncioQueue/AsyncioQueueCAPI.h"
#include "simstruc.h"
#include "fixedpoint.h"
#endif
#include "SiEngineCore_types.h"
#include "multiword_types.h"
#include "model_reference_types.h"
#include "rtGetInf.h"
#include "rt_nonfinite.h"
#include "rtGetNaN.h"
#include "mwmathutil.h"
typedef struct { real_T k3mmdwkkxi [ 6 ] ; } cwhkmchp43 ; typedef struct {
real_T iav4adummy [ 6 ] ; real_T loqc0log1m [ 6 ] ; real_T e01d53z0a1 [ 6 ] ;
real_T fjtllqdqvl ; real_T kv1p31kh4c ; real_T gfjjq4lao5 ; real_T hsttlqv3w1
[ 6 ] ; real_T gj5uedsw34 [ 6 ] ; real_T o5jfc2eefb [ 6 ] ; real_T anb3cfrkzf
; real_T ojsmjr3fm5 ; real_T hczb22xh1w ; real_T goa43ub0zk [ 2 ] ; real_T
fdp0wbompo [ 2 ] ; real_T hs5qj4tstq ; real_T ota2nyzo2i [ 6 ] ; real_T
eholka12vf ; real_T dqujkfj522 [ 6 ] ; real_T fxj3vgzmda [ 6 ] ; real_T
bu1qdcd1xc ; real_T otilkryryf ; real_T di3kkaocm3 [ 6 ] ; real_T desxddmxri
[ 6 ] ; real_T czgyljthtf [ 6 ] ; real_T dy3n3alxsr ; real_T duvlzyf4cw ;
real_T khtfbjy4db [ 6 ] ; real_T d3yqjcflrv [ 6 ] ; real_T iudei2l403 [ 6 ] ;
real_T oycam40la4 ; real_T c4ud4hu2vy ; real_T hmgt1wehi4 ; real_T dyliyzhfog
; real_T p4i3uavuuv ; real_T klbdj4gcmz ; real_T dwatdzvlom ; real_T
onqxquzsa1 ; real_T jbth1c525l ; real_T ah0jpx3faq ; real_T lrwvk24tnk ;
real_T chabzdwcii ; real_T ddbr0n50kf ; real_T oym4jmb1le ; real_T l3ackbvbkq
; real_T c2alrpd0o3 ; real_T fykhqgn5h2 ; real_T lkpfrp4vwx ; real_T
cgb3v1vkmn ; real_T ce1ss2lfbb ; real_T dysimbnwjq ; real_T l0eszwmtkx ;
real_T ew42bvi3vd ; real_T awkzn2kzyn ; real_T bajdm2ghuv ; real_T alhyu0temi
; real_T ixenqwog13 ; real_T icqrdjvzdz ; real_T im0atbwtss ; real_T
f30pt2hfrn ; real_T oy1mb1fry1 ; real_T cidz0fxuml ; real_T ai0mxdtnbv ;
real_T iq3swproof ; real_T ikzetzvbib ; real_T jk2cd2tf2r ; real_T jnacjhjx0v
; real_T buhfb3usn4 ; real_T nimrjx4auv ; real_T dxnzlpppr3 ; real_T
h5551xqxvz ; real_T dbmrgj45iy ; real_T ha3nmbpoqo ; real_T ddjc3owime ;
real_T lf0jz0siw3 ; real_T dbyf13dpvf ; real_T p4xq3ffiss ; real_T d2zfojmcwc
; real_T fi4tp2cbdf ; real_T bkggcrfvr4 ; real_T oyioglfjkr ; real_T
ezv3uruvdl ; real_T cpnsx5qcer ; real_T pw4p1jpm55 [ 6 ] ; real_T l5c303icqs
[ 6 ] ; real_T nahbdet0rx [ 6 ] ; real_T gw0pnw12wt [ 12 ] ; real_T
ny15bbjyga [ 6 ] ; real_T lfllotqmvj [ 6 ] ; real_T izoly0rgxz [ 6 ] ; real_T
l341p1rbwf [ 6 ] ; real_T bgvj3jsvsp [ 12 ] ; real_T ejy1ptrsdl [ 6 ] ;
boolean_T d4lhyomru1 ; cwhkmchp43 jp04lv053k [ 1 ] ; cwhkmchp43 jyttejnttq [
1 ] ; cwhkmchp43 fnkjttsg1c [ 1 ] ; cwhkmchp43 bpvyo0sarj [ 2 ] ; cwhkmchp43
ak5py42han [ 1 ] ; cwhkmchp43 mkw1ltakja [ 1 ] ; cwhkmchp43 ld5atexmef [ 1 ]
; cwhkmchp43 m0jvx5ur4i [ 1 ] ; cwhkmchp43 ooljnejnik [ 2 ] ; cwhkmchp43
iauuhwowqju [ 1 ] ; } avcictg5h3 ; typedef struct { int_T ltllj5zw54 ; int_T
pyrwkbozxu ; int_T lie1iibhjp ; int_T i1eqffiuff ; int_T ju3dflfpl1 ; int_T
pycjp4lzee ; int_T nfe3a5gkgn ; int_T g41l5vm55w ; int_T grnskn00r5 ; int8_T
n54u3kv3hb ; int8_T hkjyoa21vn ; int8_T pespwl2ydo ; int8_T dsdwfyury2 ;
int8_T mw0ebd4yho ; int8_T h10x411ozw ; int8_T hmrnupcdzx ; int8_T bvkyqv2ovg
; int8_T hyig443tb1 ; int8_T c1d4xotzzc ; int8_T c5w2gaqi1v ; int8_T
gfjlpsnugq ; int8_T co04x5efy3 ; int8_T a2tebcryl1 ; int8_T j0gx4doxnj ;
int8_T gn5hvyfbdf ; int8_T ebgswv2rp3 ; int8_T gwlzbf4hjm ; int8_T nr00hdz5ht
; boolean_T gxb0ek40t4 ; boolean_T ko411zozkk ; boolean_T be3ryvuaiq ; }
a44w4cdtf2 ; typedef struct { real_T l5l4j3zpbv ; real_T avdzeav3af ; real_T
hx4sgebyr2 [ 6 ] ; real_T bdd3ra5zox [ 6 ] ; real_T eamjnr0z3s ; real_T
mo2nwvmesw ; real_T m0ygypyt4l ; real_T egqothsxuk ; real_T e1vm4eatwr ;
real_T ip1u1basin ; real_T c2lcgqv0iu ; real_T eqsccsj2uk [ 6 ] ; real_T
cva0fgs4rq ; real_T hgi0nf3zhn [ 6 ] ; real_T kikzskuefz ; real_T pp3sbmt411
; real_T lgqkezkrvb [ 6 ] ; real_T pavjyll3pw ; real_T paegvaid45 ; }
fvgaykwdlx ; typedef int_T bhaskfihtq [ 1 ] ; typedef real_T fuwhh2ppqv [ 2 ]
; typedef struct { real_T l5l4j3zpbv ; real_T avdzeav3af ; real_T hx4sgebyr2
[ 6 ] ; real_T bdd3ra5zox [ 6 ] ; real_T eamjnr0z3s ; real_T mo2nwvmesw ;
real_T m0ygypyt4l ; real_T egqothsxuk ; real_T e1vm4eatwr ; real_T ip1u1basin
; real_T c2lcgqv0iu ; real_T eqsccsj2uk [ 6 ] ; real_T cva0fgs4rq ; real_T
hgi0nf3zhn [ 6 ] ; real_T kikzskuefz ; real_T pp3sbmt411 ; real_T lgqkezkrvb
[ 6 ] ; real_T pavjyll3pw ; real_T paegvaid45 ; } bf2imhxgmy ; typedef struct
{ boolean_T l5l4j3zpbv ; boolean_T avdzeav3af ; boolean_T hx4sgebyr2 [ 6 ] ;
boolean_T bdd3ra5zox [ 6 ] ; boolean_T eamjnr0z3s ; boolean_T mo2nwvmesw ;
boolean_T m0ygypyt4l ; boolean_T egqothsxuk ; boolean_T e1vm4eatwr ;
boolean_T ip1u1basin ; boolean_T c2lcgqv0iu ; boolean_T eqsccsj2uk [ 6 ] ;
boolean_T cva0fgs4rq ; boolean_T hgi0nf3zhn [ 6 ] ; boolean_T kikzskuefz ;
boolean_T pp3sbmt411 ; boolean_T lgqkezkrvb [ 6 ] ; boolean_T pavjyll3pw ;
boolean_T paegvaid45 ; } j5zsaueehq ; typedef struct { real_T l5l4j3zpbv ;
real_T avdzeav3af ; real_T hx4sgebyr2 [ 6 ] ; real_T bdd3ra5zox [ 6 ] ;
real_T eamjnr0z3s ; real_T mo2nwvmesw ; real_T m0ygypyt4l ; real_T egqothsxuk
; real_T e1vm4eatwr ; real_T ip1u1basin ; real_T c2lcgqv0iu ; real_T
eqsccsj2uk [ 6 ] ; real_T cva0fgs4rq ; real_T hgi0nf3zhn [ 6 ] ; real_T
kikzskuefz ; real_T pp3sbmt411 ; real_T lgqkezkrvb [ 6 ] ; real_T pavjyll3pw
; real_T paegvaid45 ; } psrtkcdttq ; typedef struct { real_T l5l4j3zpbv ;
real_T avdzeav3af ; real_T hx4sgebyr2 [ 6 ] ; real_T bdd3ra5zox [ 6 ] ;
real_T eamjnr0z3s ; real_T mo2nwvmesw ; real_T m0ygypyt4l ; real_T egqothsxuk
; real_T e1vm4eatwr ; real_T ip1u1basin ; real_T c2lcgqv0iu ; real_T
eqsccsj2uk [ 6 ] ; real_T cva0fgs4rq ; real_T hgi0nf3zhn [ 6 ] ; real_T
kikzskuefz ; real_T pp3sbmt411 ; real_T lgqkezkrvb [ 6 ] ; real_T pavjyll3pw
; real_T paegvaid45 ; } asrmxcx4uq ; typedef struct { real_T l5l4j3zpbv ;
real_T avdzeav3af ; real_T hx4sgebyr2 [ 6 ] ; real_T bdd3ra5zox [ 6 ] ;
real_T eamjnr0z3s ; real_T mo2nwvmesw ; real_T m0ygypyt4l ; real_T egqothsxuk
; real_T e1vm4eatwr ; real_T ip1u1basin ; real_T c2lcgqv0iu ; real_T
eqsccsj2uk [ 6 ] ; real_T cva0fgs4rq ; real_T hgi0nf3zhn [ 6 ] ; real_T
kikzskuefz ; real_T pp3sbmt411 ; real_T lgqkezkrvb [ 6 ] ; real_T pavjyll3pw
; real_T paegvaid45 ; } csyqa35n4k ; typedef struct { real_T ic1v0nxk5q ;
real_T dh3j4dz404 ; real_T a1avvwkx2q ; real_T dy3zf2lhuf ; real_T iovtpkapik
; real_T dfzbswgko1 ; real_T odzwo4sgcd ; real_T hzq0bi0n30 ; real_T
pq5ozadydt ; real_T jkf1ddwl2m ; real_T nqgoy0qpre ; real_T i02n0lcrqh ;
real_T epicnpg1xl ; real_T cvoadalg1w ; real_T ar34ucf5on ; real_T aqt4vcuvcm
; real_T jxlccmyx3u ; real_T jaclqdligv ; real_T nkfy2gt343 ; real_T
eriaof30zf ; } i1ouea5330 ; typedef struct { const real_T mqshkcmluo ; const
real_T meehey5jue ; const real_T gqd5t1lffg ; } g1vj0juqna ; struct
nno4qjngixf_ { real_T P_0 ; real_T P_1 ; real_T P_2 ; real_T P_3 ; real_T P_4
; real_T P_5 ; real_T P_6 ; real_T P_7 ; real_T P_8 ; real_T P_9 ; real_T
P_10 ; real_T P_11 ; real_T P_12 ; real_T P_13 ; real_T P_14 ; real_T P_15 ;
real_T P_16 ; real_T P_17 ; real_T P_18 ; real_T P_19 ; real_T P_20 ; real_T
P_21 ; real_T P_22 ; real_T P_23 ; real_T P_24 ; real_T P_25 ; real_T P_26 ;
real_T P_27 ; real_T P_28 ; real_T P_29 ; real_T P_30 ; real_T P_31 ; real_T
P_32 ; real_T P_33 ; real_T P_34 ; real_T P_35 [ 100 ] ; real_T P_36 [ 60 ] ;
real_T P_37 ; real_T P_38 ; real_T P_39 ; real_T P_40 ; real_T P_41 ; real_T
P_42 ; real_T P_43 ; real_T P_44 ; real_T P_45 ; real_T P_46 ; real_T P_47 ;
real_T P_48 ; real_T P_49 ; real_T P_50 ; real_T P_51 ; real_T P_52 ; real_T
P_53 [ 2 ] ; real_T P_54 [ 2 ] ; real_T P_55 ; real_T P_56 ; real_T P_57 ;
real_T P_58 ; real_T P_59 ; real_T P_60 ; real_T P_61 ; real_T P_62 ; real_T
P_63 ; real_T P_64 ; real_T P_65 ; real_T P_66 ; real_T P_67 ; real_T P_68 ;
real_T P_69 ; real_T P_70 ; real_T P_71 ; real_T P_72 ; real_T P_73 ; real_T
P_74 ; real_T P_75 ; real_T P_76 ; real_T P_77 ; real_T P_78 ; real_T P_79 ;
real_T P_80 ; real_T P_81 ; real_T P_82 [ 5000 ] ; real_T P_83 ; real_T P_84
[ 3600 ] ; real_T P_85 [ 4 ] ; real_T P_86 [ 4 ] ; real_T P_87 [ 240 ] ;
real_T P_88 [ 240 ] ; real_T P_89 [ 240 ] ; real_T P_90 [ 240 ] ; real_T P_91
[ 65 ] ; real_T P_92 [ 15 ] ; real_T P_93 [ 16 ] ; real_T P_94 [ 54 ] ;
real_T P_95 [ 54 ] ; real_T P_96 [ 11 ] ; real_T P_97 [ 11 ] ; real_T P_98 [
65 ] ; real_T P_99 [ 400 ] ; real_T P_100 [ 20 ] ; real_T P_101 [ 20 ] ;
real_T P_102 [ 400 ] ; real_T P_103 [ 20 ] ; real_T P_104 [ 20 ] ; real_T
P_105 [ 256 ] ; real_T P_106 [ 225 ] ; real_T P_107 [ 15 ] ; real_T P_108 [
15 ] ; real_T P_109 [ 400 ] ; real_T P_110 [ 20 ] ; real_T P_111 [ 20 ] ;
real_T P_112 [ 256 ] ; real_T P_113 [ 256 ] ; real_T P_114 [ 16 ] ; real_T
P_115 [ 16 ] ; real_T P_116 [ 256 ] ; real_T P_117 [ 20 ] ; real_T P_118 [ 20
] ; real_T P_119 ; real_T P_120 ; real_T P_121 ; real_T P_122 ; real_T P_123
; real_T P_124 ; real_T P_125 [ 4 ] ; real_T P_126 [ 4 ] ; real_T P_127 ;
real_T P_128 ; real_T P_129 ; real_T P_130 [ 5000 ] ; real_T P_131 [ 3600 ] ;
real_T P_132 ; real_T P_133 ; real_T P_134 ; real_T P_135 ; real_T P_136 ;
real_T P_137 ; real_T P_138 ; real_T P_139 ; real_T P_140 ; real_T P_141 ;
real_T P_142 ; real_T P_143 ; real_T P_144 ; real_T P_145 ; real_T P_146 ;
real_T P_147 ; real_T P_148 ; real_T P_149 ; real_T P_150 ; real_T P_151 ;
real_T P_152 ; real_T P_153 ; real_T P_154 ; real_T P_155 ; real_T P_156 ;
real_T P_157 [ 50 ] ; real_T P_158 [ 60 ] ; real_T P_159 ; real_T P_160 ;
real_T P_161 ; real_T P_162 ; real_T P_163 ; real_T P_164 ; real_T P_165 ;
real_T P_166 ; real_T P_167 ; real_T P_168 ; real_T P_169 ; real_T P_170 ;
real_T P_171 ; real_T P_172 ; real_T P_173 [ 6 ] ; real_T P_174 ; real_T
P_175 ; real_T P_176 ; real_T P_177 ; real_T P_178 ; real_T P_179 ; real_T
P_180 [ 2 ] ; real_T P_181 [ 2 ] ; real_T P_182 [ 6 ] ; real_T P_183 ; real_T
P_184 ; real_T P_185 ; real_T P_186 ; real_T P_187 ; real_T P_188 ; real_T
P_189 ; real_T P_190 ; real_T P_191 ; real_T P_192 ; real_T P_193 ; real_T
P_194 ; real_T P_195 [ 2 ] ; real_T P_196 [ 2 ] ; real_T P_197 ; real_T P_198
; real_T P_199 ; real_T P_200 ; real_T P_201 ; real_T P_202 ; real_T P_203 [
6 ] ; real_T P_204 ; real_T P_205 ; real_T P_206 [ 6 ] ; real_T P_207 ;
real_T P_208 ; real_T P_209 ; real_T P_210 ; real_T P_211 [ 2 ] ; real_T
P_212 [ 2 ] ; real_T P_213 ; real_T P_214 ; real_T P_215 ; real_T P_216 ;
real_T P_217 ; real_T P_218 ; real_T P_219 ; real_T P_220 ; real_T P_221 ;
real_T P_222 ; real_T P_223 ; real_T P_224 ; real_T P_225 ; real_T P_226 ;
real_T P_227 ; real_T P_228 ; real_T P_229 [ 2 ] ; real_T P_230 [ 2 ] ;
real_T P_231 ; real_T P_232 [ 3 ] ; real_T P_233 [ 3 ] ; real_T P_234 ;
real_T P_235 ; real_T P_236 ; real_T P_237 [ 3 ] ; real_T P_238 [ 3 ] ;
real_T P_239 [ 3 ] ; real_T P_240 [ 3 ] ; real_T P_241 ; real_T P_242 [ 3 ] ;
real_T P_243 [ 3 ] ; real_T P_244 ; real_T P_245 ; real_T P_246 ; real_T
P_247 ; real_T P_248 ; real_T P_249 ; real_T P_250 ; real_T P_251 ; real_T
P_252 ; real_T P_253 ; real_T P_254 ; real_T P_255 [ 2 ] ; real_T P_256 [ 2 ]
; real_T P_257 ; real_T P_258 ; real_T P_259 ; real_T P_260 ; real_T P_261 ;
real_T P_262 ; real_T P_263 ; real_T P_264 ; real_T P_265 ; real_T P_266 ;
real_T P_267 [ 2 ] ; real_T P_268 ; real_T P_269 ; real_T P_270 ; real_T
P_271 ; real_T P_272 ; real_T P_273 ; real_T P_274 ; real_T P_275 ; real_T
P_276 ; real_T P_277 ; real_T P_278 ; real_T P_279 ; real_T P_280 ; real_T
P_281 ; real_T P_282 [ 2 ] ; real_T P_283 [ 2 ] ; real_T P_284 [ 6 ] ; real_T
P_285 ; real_T P_286 ; real_T P_287 ; real_T P_288 ; real_T P_289 ; real_T
P_290 ; real_T P_291 ; real_T P_292 ; real_T P_293 ; real_T P_294 ; real_T
P_295 ; real_T P_296 ; real_T P_297 ; real_T P_298 ; real_T P_299 ; real_T
P_300 ; real_T P_301 ; real_T P_302 ; real_T P_303 ; real_T P_304 ; real_T
P_305 ; real_T P_306 ; real_T P_307 ; real_T P_308 ; real_T P_309 ; real_T
P_310 ; real_T P_311 ; real_T P_312 ; real_T P_313 ; real_T P_314 ; real_T
P_315 ; real_T P_316 ; real_T P_317 ; real_T P_318 ; real_T P_319 ; real_T
P_320 ; real_T P_321 ; real_T P_322 ; real_T P_323 ; real_T P_324 ; real_T
P_325 ; real_T P_326 ; real_T P_327 ; real_T P_328 ; real_T P_329 ; real_T
P_330 ; real_T P_331 ; real_T P_332 ; real_T P_333 ; real_T P_334 ; real_T
P_335 ; real_T P_336 ; real_T P_337 ; real_T P_338 ; real_T P_339 ; real_T
P_340 ; real_T P_341 ; real_T P_342 ; real_T P_343 ; real_T P_344 ; real_T
P_345 ; real_T P_346 ; real_T P_347 ; real_T P_348 ; real_T P_349 ; real_T
P_350 ; real_T P_351 ; real_T P_352 ; real_T P_353 ; real_T P_354 ; real_T
P_355 ; real_T P_356 ; real_T P_357 ; real_T P_358 ; real_T P_359 ; real_T
P_360 ; real_T P_361 ; real_T P_362 ; real_T P_363 ; real_T P_364 ; real_T
P_365 ; real_T P_366 ; real_T P_367 ; real_T P_368 ; real_T P_369 ; real_T
P_370 ; real_T P_371 ; real_T P_372 ; real_T P_373 ; real_T P_374 ; real_T
P_375 ; real_T P_376 ; real_T P_377 ; real_T P_378 ; real_T P_379 ; real_T
P_380 ; real_T P_381 ; real_T P_382 ; real_T P_383 ; real_T P_384 ; real_T
P_385 ; real_T P_386 ; real_T P_387 ; real_T P_388 ; real_T P_389 ; real_T
P_390 ; real_T P_391 ; real_T P_392 ; real_T P_393 ; real_T P_394 ; real_T
P_395 ; real_T P_396 ; real_T P_397 ; real_T P_398 ; real_T P_399 ; real_T
P_400 ; real_T P_401 ; real_T P_402 ; real_T P_403 ; real_T P_404 ; real_T
P_405 ; real_T P_406 ; real_T P_407 ; real_T P_408 ; real_T P_409 ; real_T
P_410 ; real_T P_411 ; real_T P_412 ; real_T P_413 ; real_T P_414 ; real_T
P_415 ; real_T P_416 ; real_T P_417 ; real_T P_418 ; real_T P_419 ; real_T
P_420 ; real_T P_421 ; real_T P_422 ; real_T P_423 ; real_T P_424 ; real_T
P_425 ; real_T P_426 ; real_T P_427 ; real_T P_428 ; real_T P_429 ; real_T
P_430 ; real_T P_431 ; real_T P_432 ; real_T P_433 ; real_T P_434 ; real_T
P_435 ; real_T P_436 ; real_T P_437 ; real_T P_438 ; real_T P_439 ; real_T
P_440 ; real_T P_441 ; real_T P_442 ; real_T P_443 ; real_T P_444 ; real_T
P_445 ; real_T P_446 ; real_T P_447 ; real_T P_448 ; real_T P_449 ; real_T
P_450 ; real_T P_451 ; real_T P_452 ; real_T P_453 ; real_T P_454 ; real_T
P_455 ; real_T P_456 ; real_T P_457 ; real_T P_458 ; real_T P_459 ; uint32_T
P_460 [ 2 ] ; uint32_T P_461 [ 2 ] ; uint32_T P_462 [ 2 ] ; uint32_T P_463 [
2 ] ; uint32_T P_464 [ 2 ] ; uint32_T P_465 [ 2 ] ; uint32_T P_466 [ 2 ] ;
uint32_T P_467 [ 2 ] ; uint32_T P_468 [ 2 ] ; uint32_T P_469 [ 2 ] ; uint32_T
P_470 [ 2 ] ; uint32_T P_471 [ 2 ] ; uint32_T P_472 [ 2 ] ; uint32_T P_473 [
2 ] ; uint32_T P_474 [ 2 ] ; uint32_T P_475 [ 2 ] ; } ; struct iwgh44im0y {
struct SimStruct_tag * _mdlRefSfcnS ; const rtTimingBridge * timingBridge ;
struct { rtwCAPI_ModelMappingInfo mmi ; rtwCAPI_ModelMapLoggingInstanceInfo
mmiLogInstanceInfo ; void * dataAddress [ 19 ] ; int32_T * vardimsAddress [
19 ] ; RTWLoggingFcnPtr loggingPtrs [ 19 ] ; sysRanDType * systemRan [ 35 ] ;
int_T systemTid [ 35 ] ; } DataMapInfo ; struct { int_T mdlref_GlobalTID [ 3
] ; } Timing ; } ; typedef struct { avcictg5h3 rtb ; a44w4cdtf2 rtdw ;
cfm545pqpj rtm ; } nusecvdwrfs ; extern void kkm3wcvp03 ( SimStruct *
_mdlRefSfcnS , int_T mdlref_TID0 , int_T mdlref_TID1 , int_T mdlref_TID2 ,
cfm545pqpj * const nkgnf0b0jx , avcictg5h3 * localB , a44w4cdtf2 * localDW ,
fvgaykwdlx * localX , void * sysRanPtr , int contextTid ,
rtwCAPI_ModelMappingInfo * rt_ParentMMI , const char_T * rt_ChildPath , int_T
rt_ChildMMIIdx , int_T rt_CSTATEIdx ) ; extern void
mr_SiEngineCore_MdlInfoRegFcn ( SimStruct * mdlRefSfcnS , char_T * modelName
, int_T * retVal ) ; extern mxArray * mr_SiEngineCore_GetDWork ( const
nusecvdwrfs * mdlrefDW ) ; extern void mr_SiEngineCore_SetDWork ( nusecvdwrfs
* mdlrefDW , const mxArray * ssDW ) ; extern void
mr_SiEngineCore_RegisterSimStateChecksum ( SimStruct * S ) ; extern mxArray *
mr_SiEngineCore_GetSimStateDisallowedBlocks ( ) ; extern const
rtwCAPI_ModelMappingStaticInfo * SiEngineCore_GetCAPIStaticMap ( void ) ;
extern void iauuhwowqj ( int32_T NumIters , const real_T ouotwajy4a [ 6 ] ,
const real_T * infogb3pgr , real_T kpuhvuuluw [ 6 ] , cwhkmchp43 localB [ 1 ]
) ; extern void mt4ilpnutb ( fvgaykwdlx * localX ) ; extern void mywoblxnq5 (
fvgaykwdlx * localX ) ; extern void ahma5ngmia ( a44w4cdtf2 * localDW ) ;
extern void ephdimea2c ( avcictg5h3 * localB , fvgaykwdlx * localX ,
j5zsaueehq * localXdis , bf2imhxgmy * localXdot ) ; extern void icfc3q2p1f (
const real_T * lpgs41hpbt , const real_T * nxkqokcrki , const real_T *
gd4dclwth5 , const real_T * i0uebulz0g , avcictg5h3 * localB , a44w4cdtf2 *
localDW , fvgaykwdlx * localX , i1ouea5330 * localZCSV ) ; extern void
lx4yje0jop ( a44w4cdtf2 * localDW ) ; extern void lti1x2mlsn ( cfm545pqpj *
const nkgnf0b0jx , avcictg5h3 * localB , a44w4cdtf2 * localDW , j5zsaueehq *
localXdis ) ; extern void lti1x2mlsnTID2 ( void ) ; extern void SiEngineCore
( cfm545pqpj * const nkgnf0b0jx , const real_T * gqxreqd4gq , const real_T *
lpgs41hpbt , const real_T * i2crisad4x , const real_T * mxpwpccrob , const
real_T * kv0b3gz3se , const real_T * ohzyncazr5 , const real_T * nxkqokcrki ,
const real_T * fxsb4avaqf , const real_T * k3rxhxirvl , const real_T *
gd4dclwth5 , const real_T * i0uebulz0g , const real_T * ep3arnqzsz , real_T *
addb1iinwn , real_T * e1h5aiwl5a , real_T * hv5m0fyzrq , real_T * h515ikztjt
, real_T * c3z450kaaq , real_T * dbpz014ysa , real_T * ca122tu2vz , real_T *
mfya53qrwm , real_T * nt5b5rd3pj , real_T * cmaqovy433 , real_T * lu2yavujua
, real_T * mry3jgfho2 , real_T * kl4y0hsyrc , real_T * h0f0oj3b1u , real_T *
hqdewytasq , real_T * k3j24jjvpi , real_T * n24qv2sk4b , real_T * nww1ykcsz4
, real_T * mb2lz3ul2d , real_T * ibh2100hpb , real_T * a2cndqwcmr , real_T *
itqc3lkont , real_T * kjei5mfab5 , real_T * gduvhlledc , real_T * a3k44cm32q
, real_T * m4p1go4wud , real_T * aikldeqf2u , avcictg5h3 * localB ,
a44w4cdtf2 * localDW , fvgaykwdlx * localX ) ; extern void SiEngineCoreTID2 (
cfm545pqpj * const nkgnf0b0jx , avcictg5h3 * localB , a44w4cdtf2 * localDW )
; extern void cz5fxcs3qc ( cfm545pqpj * const nkgnf0b0jx ) ;
#endif
