#ifndef RTW_HEADER_SiEngine_capi_h_
#define RTW_HEADER_SiEngine_capi_h_
#include "SiEngine.h"
extern void SiEngine_InitializeDataMapInfo ( bwlfiijd5x * const meoozayevp ,
d1lrwbszlu * localDW , avhdfnulpn * localX , void * sysRanPtr , int
contextTid ) ;
#endif
