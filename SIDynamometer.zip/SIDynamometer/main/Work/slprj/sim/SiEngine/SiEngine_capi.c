#include <stddef.h>
#include "rtw_capi.h"
#ifdef HOST_CAPI_BUILD
#include "SiEngine_capi_host.h"
#define sizeof(s) ((size_t)(0xFFFF))
#undef rt_offsetof
#define rt_offsetof(s,el) ((uint16_T)(0xFFFF))
#define TARGET_CONST
#define TARGET_STRING(s) (s)    
#else
#include "builtin_typeid_types.h"
#include "SiEngine.h"
#include "SiEngine_capi.h"
#include "SiEngine_private.h"
#ifdef LIGHT_WEIGHT_CAPI
#define TARGET_CONST                  
#define TARGET_STRING(s)               (NULL)                    
#else
#define TARGET_CONST                   const
#define TARGET_STRING(s)               (s)
#endif
#endif
static rtwCAPI_Signals rtBlockSignals [ ] = { { 0 , 0 , ( NULL ) , ( NULL ) ,
0 , 0 , 0 , 0 , 0 } } ; static rtwCAPI_States rtBlockStates [ ] = { { 0 , 4 ,
TARGET_STRING ( "SiEngine/Actuators/EGR Valve Dynamics" ) , TARGET_STRING (
"" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 , 1 , - 1 , 0 } , { 1 , 0 ,
TARGET_STRING ( "SiEngine/Actuators/Electronic Throttle Actuator Dynamics" )
, TARGET_STRING ( "" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 , 1 , - 1 ,
0 } , { 2 , 3 , TARGET_STRING (
"SiEngine/Actuators/Exhaust Cam Phaser\n Actuator Dynamics" ) , TARGET_STRING
( "" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 , 1 , - 1 , 0 } , { 3 , 2 ,
TARGET_STRING ( "SiEngine/Actuators/Intake Cam Phaser\n Actuator Dynamics" )
, TARGET_STRING ( "" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 , 1 , - 1 ,
0 } , { 4 , 53 , TARGET_STRING (
"SiEngine/Actuators/Swirl Valve Actuator Dynamics" ) , TARGET_STRING ( "" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 , 1 , - 1 , 0 } , { 5 , 49 ,
TARGET_STRING ( "SiEngine/Actuators/VGT Actuator Dynamics" ) , TARGET_STRING
( "" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 , 1 , - 1 , 0 } , { 6 , 50
, TARGET_STRING (
"SiEngine/Actuators/Variable Compression Ratio\nActuator Dynamics" ) ,
TARGET_STRING ( "" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 , 1 , - 1 , 0
} , { 7 , 52 , TARGET_STRING (
"SiEngine/Actuators/Variable Intake Runner Length\nActuator Dynamics" ) ,
TARGET_STRING ( "" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 , 1 , - 1 , 0
} , { 8 , 51 , TARGET_STRING (
"SiEngine/Actuators/Variable Intake Valve Lift\nActuator Dynamics" ) ,
TARGET_STRING ( "" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 , 1 , - 1 , 0
} , { 9 , 1 , TARGET_STRING (
"SiEngine/Actuators/Wastegate Actuator Dynamics" ) , TARGET_STRING ( "" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 , 1 , - 1 , 0 } , { 10 , 55 ,
TARGET_STRING (
"SiEngine/Three-Way Catalyst/Catalyst Mid-Brick\nTemperature Model\n" ) ,
TARGET_STRING ( "" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 , 1 , - 1 , 0
} , { 11 , 54 , TARGET_STRING ( "SiEngine/Three-Way Catalyst/O2 Storage" ) ,
TARGET_STRING ( "" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 , 1 , - 1 , 0
} , { 0 , - 1 , ( NULL ) , ( NULL ) , ( NULL ) , 0 , 0 , 0 , 0 , 0 , 0 , - 1
, 0 } } ;
#ifndef HOST_CAPI_BUILD
static void SiEngine_InitializeDataAddr ( void * dataAddr [ ] , d1lrwbszlu *
localDW , avhdfnulpn * localX ) { dataAddr [ 0 ] = ( void * ) ( & localX ->
jdpri2xyhy ) ; dataAddr [ 1 ] = ( void * ) ( & localX -> bwugeffscn ) ;
dataAddr [ 2 ] = ( void * ) ( & localX -> mvylur3avu ) ; dataAddr [ 3 ] = (
void * ) ( & localX -> iwfypymqjg ) ; dataAddr [ 4 ] = ( void * ) ( & localX
-> jtqd4zeqez ) ; dataAddr [ 5 ] = ( void * ) ( & localX -> cd5spz4yti ) ;
dataAddr [ 6 ] = ( void * ) ( & localX -> ketkc3kgyu ) ; dataAddr [ 7 ] = (
void * ) ( & localX -> ozfuihul04 ) ; dataAddr [ 8 ] = ( void * ) ( & localX
-> h4rakbatg5 ) ; dataAddr [ 9 ] = ( void * ) ( & localX -> aicfihznzn ) ;
dataAddr [ 10 ] = ( void * ) ( & localX -> fsytvblt0t ) ; dataAddr [ 11 ] = (
void * ) ( & localX -> fdwz5f1zsi ) ; }
#endif
#ifndef HOST_CAPI_BUILD
static void SiEngine_InitializeVarDimsAddr ( int32_T * vardimsAddr [ ] ) {
vardimsAddr [ 0 ] = ( NULL ) ; }
#endif
#ifndef HOST_CAPI_BUILD
static void SiEngine_InitializeLoggingFunctions ( RTWLoggingFcnPtr
loggingPtrs [ ] ) { loggingPtrs [ 0 ] = ( NULL ) ; loggingPtrs [ 1 ] = ( NULL
) ; loggingPtrs [ 2 ] = ( NULL ) ; loggingPtrs [ 3 ] = ( NULL ) ; loggingPtrs
[ 4 ] = ( NULL ) ; loggingPtrs [ 5 ] = ( NULL ) ; loggingPtrs [ 6 ] = ( NULL
) ; loggingPtrs [ 7 ] = ( NULL ) ; loggingPtrs [ 8 ] = ( NULL ) ; loggingPtrs
[ 9 ] = ( NULL ) ; loggingPtrs [ 10 ] = ( NULL ) ; loggingPtrs [ 11 ] = (
NULL ) ; }
#endif
static TARGET_CONST rtwCAPI_DataTypeMap rtDataTypeMap [ ] = { { "double" ,
"real_T" , 0 , 0 , sizeof ( real_T ) , SS_DOUBLE , 0 , 0 , 0 } } ;
#ifdef HOST_CAPI_BUILD
#undef sizeof
#endif
static TARGET_CONST rtwCAPI_ElementMap rtElementMap [ ] = { { ( NULL ) , 0 ,
0 , 0 , 0 } , } ; static rtwCAPI_DimensionMap rtDimensionMap [ ] = { {
rtwCAPI_SCALAR , 0 , 2 , 0 } } ; static uint_T rtDimensionArray [ ] = { 1 , 1
} ; static const real_T rtcapiStoredFloats [ ] = { 0.0 } ; static
rtwCAPI_FixPtMap rtFixPtMap [ ] = { { ( NULL ) , ( NULL ) ,
rtwCAPI_FIX_RESERVED , 0 , 0 , 0 } , } ; static rtwCAPI_SampleTimeMap
rtSampleTimeMap [ ] = { { ( const void * ) & rtcapiStoredFloats [ 0 ] , (
const void * ) & rtcapiStoredFloats [ 0 ] , 0 , 0 } } ; static int_T
rtContextSystems [ 5 ] ; static rtwCAPI_LoggingMetaInfo loggingMetaInfo [ ] =
{ { 0 , 0 , "" , 0 } } ; static rtwCAPI_ModelMapLoggingStaticInfo
mmiStaticInfoLogging = { 5 , rtContextSystems , loggingMetaInfo , 0 , NULL ,
{ 0 , NULL , NULL } , 0 , ( NULL ) } ; static rtwCAPI_ModelMappingStaticInfo
mmiStatic = { { rtBlockSignals , 0 , ( NULL ) , 0 , ( NULL ) , 0 } , { ( NULL
) , 0 , ( NULL ) , 0 } , { rtBlockStates , 12 } , { rtDataTypeMap ,
rtDimensionMap , rtFixPtMap , rtElementMap , rtSampleTimeMap ,
rtDimensionArray } , "float" , { 3528823774U , 3783731116U , 1699027203U ,
2603487797U } , & mmiStaticInfoLogging , 0 , 0 } ; const
rtwCAPI_ModelMappingStaticInfo * SiEngine_GetCAPIStaticMap ( void ) { return
& mmiStatic ; }
#ifndef HOST_CAPI_BUILD
static void SiEngine_InitializeSystemRan ( bwlfiijd5x * const meoozayevp ,
sysRanDType * systemRan [ ] , d1lrwbszlu * localDW , int_T systemTid [ ] ,
void * rootSysRanPtr , int rootTid ) { UNUSED_PARAMETER ( meoozayevp ) ;
UNUSED_PARAMETER ( localDW ) ; systemRan [ 0 ] = ( sysRanDType * )
rootSysRanPtr ; systemRan [ 1 ] = ( NULL ) ; systemRan [ 2 ] = ( sysRanDType
* ) & localDW -> leq3bzncpd ; systemRan [ 3 ] = ( sysRanDType * ) & localDW
-> ctcrxrlnoa ; systemRan [ 4 ] = ( NULL ) ; systemTid [ 1 ] = meoozayevp ->
Timing . mdlref_GlobalTID [ 0 ] ; systemTid [ 3 ] = meoozayevp -> Timing .
mdlref_GlobalTID [ 0 ] ; systemTid [ 2 ] = meoozayevp -> Timing .
mdlref_GlobalTID [ 0 ] ; systemTid [ 4 ] = meoozayevp -> Timing .
mdlref_GlobalTID [ 0 ] ; systemTid [ 0 ] = rootTid ; rtContextSystems [ 0 ] =
0 ; rtContextSystems [ 1 ] = 0 ; rtContextSystems [ 2 ] = 2 ;
rtContextSystems [ 3 ] = 3 ; rtContextSystems [ 4 ] = 0 ; }
#endif
#ifndef HOST_CAPI_BUILD
void SiEngine_InitializeDataMapInfo ( bwlfiijd5x * const meoozayevp ,
d1lrwbszlu * localDW , avhdfnulpn * localX , void * sysRanPtr , int
contextTid ) { rtwCAPI_SetVersion ( meoozayevp -> DataMapInfo . mmi , 1 ) ;
rtwCAPI_SetStaticMap ( meoozayevp -> DataMapInfo . mmi , & mmiStatic ) ;
rtwCAPI_SetLoggingStaticMap ( meoozayevp -> DataMapInfo . mmi , &
mmiStaticInfoLogging ) ; SiEngine_InitializeDataAddr ( meoozayevp ->
DataMapInfo . dataAddress , localDW , localX ) ; rtwCAPI_SetDataAddressMap (
meoozayevp -> DataMapInfo . mmi , meoozayevp -> DataMapInfo . dataAddress ) ;
SiEngine_InitializeVarDimsAddr ( meoozayevp -> DataMapInfo . vardimsAddress )
; rtwCAPI_SetVarDimsAddressMap ( meoozayevp -> DataMapInfo . mmi , meoozayevp
-> DataMapInfo . vardimsAddress ) ; rtwCAPI_SetPath ( meoozayevp ->
DataMapInfo . mmi , ( NULL ) ) ; rtwCAPI_SetFullPath ( meoozayevp ->
DataMapInfo . mmi , ( NULL ) ) ; SiEngine_InitializeLoggingFunctions (
meoozayevp -> DataMapInfo . loggingPtrs ) ; rtwCAPI_SetLoggingPtrs (
meoozayevp -> DataMapInfo . mmi , meoozayevp -> DataMapInfo . loggingPtrs ) ;
rtwCAPI_SetInstanceLoggingInfo ( meoozayevp -> DataMapInfo . mmi , &
meoozayevp -> DataMapInfo . mmiLogInstanceInfo ) ; rtwCAPI_SetChildMMIArray (
meoozayevp -> DataMapInfo . mmi , meoozayevp -> DataMapInfo . childMMI ) ;
rtwCAPI_SetChildMMIArrayLen ( meoozayevp -> DataMapInfo . mmi , 1 ) ;
SiEngine_InitializeSystemRan ( meoozayevp , meoozayevp -> DataMapInfo .
systemRan , localDW , meoozayevp -> DataMapInfo . systemTid , sysRanPtr ,
contextTid ) ; rtwCAPI_SetSystemRan ( meoozayevp -> DataMapInfo . mmi ,
meoozayevp -> DataMapInfo . systemRan ) ; rtwCAPI_SetSystemTid ( meoozayevp
-> DataMapInfo . mmi , meoozayevp -> DataMapInfo . systemTid ) ;
rtwCAPI_SetGlobalTIDMap ( meoozayevp -> DataMapInfo . mmi , & meoozayevp ->
Timing . mdlref_GlobalTID [ 0 ] ) ; }
#else
#ifdef __cplusplus
extern "C" {
#endif
void SiEngine_host_InitializeDataMapInfo ( SiEngine_host_DataMapInfo_T *
dataMap , const char * path ) { rtwCAPI_SetVersion ( dataMap -> mmi , 1 ) ;
rtwCAPI_SetStaticMap ( dataMap -> mmi , & mmiStatic ) ;
rtwCAPI_SetDataAddressMap ( dataMap -> mmi , NULL ) ;
rtwCAPI_SetVarDimsAddressMap ( dataMap -> mmi , NULL ) ; rtwCAPI_SetPath (
dataMap -> mmi , path ) ; rtwCAPI_SetFullPath ( dataMap -> mmi , NULL ) ;
dataMap -> childMMI [ 0 ] = & ( dataMap -> child0 . mmi ) ;
SiEngineCore_host_InitializeDataMapInfo ( & ( dataMap -> child0 ) ,
"SiEngine/Dynamic SI Engine with Turbo" ) ; rtwCAPI_SetChildMMIArray (
dataMap -> mmi , dataMap -> childMMI ) ; rtwCAPI_SetChildMMIArrayLen (
dataMap -> mmi , 1 ) ; }
#ifdef __cplusplus
}
#endif
#endif
