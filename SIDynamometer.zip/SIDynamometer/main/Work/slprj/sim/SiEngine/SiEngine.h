#ifndef RTW_HEADER_SiEngine_h_
#define RTW_HEADER_SiEngine_h_
#include <string.h>
#include <stddef.h>
#include "rtw_modelmap.h"
#ifndef SiEngine_COMMON_INCLUDES_
#define SiEngine_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "slsv_diagnostic_codegen_c_api.h"
#include "sl_AsyncioQueue/AsyncioQueueCAPI.h"
#include "simstruc.h"
#include "fixedpoint.h"
#endif
#include "SiEngine_types.h"
#include "multiword_types.h"
#include "model_reference_types.h"
#include "SiEngineCore.h"
#include "rtGetInf.h"
#include "rtGetNaN.h"
#include "mwmathutil.h"
#include "rt_nonfinite.h"
typedef struct { real_T he4x31s4eb ; real_T c4ci0hxjem ; real_T ga2ciuonaw ;
real_T pbpbrscrl4 ; real_T k32rccm1xy ; real_T blpqcjq3e5 ; real_T gol5zjq0it
; real_T dnq5qm1ysy ; } j1s1gxkfvu ; typedef struct { int_T i1laah4vh5 ;
int8_T ov1mlbve3n ; int8_T leq3bzncpd ; int8_T ctcrxrlnoa ; nusecvdwrfs
ld4bcbcem1 ; } d1lrwbszlu ; typedef struct { real_T bwugeffscn ; real_T
aicfihznzn ; real_T iwfypymqjg ; real_T mvylur3avu ; real_T jdpri2xyhy ;
fvgaykwdlx b4nii2a1sx ; real_T cd5spz4yti ; real_T ketkc3kgyu ; real_T
h4rakbatg5 ; real_T ozfuihul04 ; real_T jtqd4zeqez ; real_T fdwz5f1zsi ;
real_T fsytvblt0t ; } avhdfnulpn ; typedef int_T gpwn2cxbt5 [ 1 ] ; typedef
real_T nhv3dhjyes [ 2 ] ; typedef struct { real_T bwugeffscn ; real_T
aicfihznzn ; real_T iwfypymqjg ; real_T mvylur3avu ; real_T jdpri2xyhy ;
bf2imhxgmy b4nii2a1sx ; real_T cd5spz4yti ; real_T ketkc3kgyu ; real_T
h4rakbatg5 ; real_T ozfuihul04 ; real_T jtqd4zeqez ; real_T fdwz5f1zsi ;
real_T fsytvblt0t ; } doesh3j4ls ; typedef struct { boolean_T bwugeffscn ;
boolean_T aicfihznzn ; boolean_T iwfypymqjg ; boolean_T mvylur3avu ;
boolean_T jdpri2xyhy ; j5zsaueehq b4nii2a1sx ; boolean_T cd5spz4yti ;
boolean_T ketkc3kgyu ; boolean_T h4rakbatg5 ; boolean_T ozfuihul04 ;
boolean_T jtqd4zeqez ; boolean_T fdwz5f1zsi ; boolean_T fsytvblt0t ; }
ibzy5kfavx ; typedef struct { real_T bwugeffscn ; real_T aicfihznzn ; real_T
iwfypymqjg ; real_T mvylur3avu ; real_T jdpri2xyhy ; psrtkcdttq b4nii2a1sx ;
real_T cd5spz4yti ; real_T ketkc3kgyu ; real_T h4rakbatg5 ; real_T ozfuihul04
; real_T jtqd4zeqez ; real_T fdwz5f1zsi ; real_T fsytvblt0t ; } lowbiskj5g ;
typedef struct { real_T bwugeffscn ; real_T aicfihznzn ; real_T iwfypymqjg ;
real_T mvylur3avu ; real_T jdpri2xyhy ; asrmxcx4uq b4nii2a1sx ; real_T
cd5spz4yti ; real_T ketkc3kgyu ; real_T h4rakbatg5 ; real_T ozfuihul04 ;
real_T jtqd4zeqez ; real_T fdwz5f1zsi ; real_T fsytvblt0t ; } e0d0mrnvza ;
typedef struct { real_T bwugeffscn ; real_T aicfihznzn ; real_T iwfypymqjg ;
real_T mvylur3avu ; real_T jdpri2xyhy ; csyqa35n4k b4nii2a1sx ; real_T
cd5spz4yti ; real_T ketkc3kgyu ; real_T h4rakbatg5 ; real_T ozfuihul04 ;
real_T jtqd4zeqez ; real_T fdwz5f1zsi ; real_T fsytvblt0t ; } fgeg3btikx ;
typedef struct { real_T h2ly3yo0qo ; real_T c4uzcdega1 ; i1ouea5330
hn1fmr24ml ; real_T oauikjg3i3 ; } nemag1oqsq ; struct k5hdiwnneym_ { real_T
P_0 ; real_T P_1 ; real_T P_2 [ 7 ] ; real_T P_3 [ 7 ] ; real_T P_4 [ 7 ] ;
real_T P_5 [ 7 ] ; real_T P_6 [ 7 ] ; real_T P_7 [ 7 ] ; real_T P_8 ; real_T
P_9 ; real_T P_10 ; real_T P_11 [ 2 ] ; real_T P_12 [ 2 ] ; real_T P_13 ;
real_T P_14 ; real_T P_15 ; real_T P_16 ; real_T P_17 ; real_T P_18 ; real_T
P_19 ; real_T P_20 ; real_T P_21 ; real_T P_22 ; real_T P_23 ; real_T P_24 ;
real_T P_25 ; real_T P_26 ; real_T P_27 ; real_T P_28 ; real_T P_29 ; real_T
P_30 ; real_T P_31 ; real_T P_32 ; real_T P_33 ; real_T P_34 ; real_T P_35 ;
real_T P_36 ; real_T P_37 ; real_T P_38 ; real_T P_39 ; real_T P_40 ; real_T
P_41 [ 2 ] ; real_T P_42 [ 2 ] ; real_T P_43 [ 3 ] ; real_T P_44 [ 3 ] ;
real_T P_45 [ 4 ] ; real_T P_46 [ 4 ] ; real_T P_47 ; real_T P_48 ; real_T
P_49 ; real_T P_50 ; real_T P_51 ; real_T P_52 ; real_T P_53 ; real_T P_54 ;
real_T P_55 ; } ; struct a1aqzqkr0q { struct SimStruct_tag * _mdlRefSfcnS ;
const rtTimingBridge * timingBridge ; struct { rtwCAPI_ModelMappingInfo mmi ;
rtwCAPI_ModelMapLoggingInstanceInfo mmiLogInstanceInfo ; void * dataAddress [
12 ] ; int32_T * vardimsAddress [ 12 ] ; RTWLoggingFcnPtr loggingPtrs [ 12 ]
; rtwCAPI_ModelMappingInfo * childMMI [ 1 ] ; sysRanDType * systemRan [ 5 ] ;
int_T systemTid [ 5 ] ; } DataMapInfo ; struct { uint8_T rtmDbBufReadBuf2 ;
uint8_T rtmDbBufWriteBuf2 ; boolean_T rtmDbBufLastBufWr2 ; real_T
rtmDbBufContT2 [ 2 ] ; int_T mdlref_GlobalTID [ 3 ] ; } Timing ; } ; typedef
struct { j1s1gxkfvu rtb ; d1lrwbszlu rtdw ; bwlfiijd5x rtm ; } mi1gy4ncu4i ;
extern void ip52ymrooi ( SimStruct * _mdlRefSfcnS , int_T mdlref_TID0 , int_T
mdlref_TID1 , int_T mdlref_TID2 , bwlfiijd5x * const meoozayevp , j1s1gxkfvu
* localB , d1lrwbszlu * localDW , avhdfnulpn * localX , void * sysRanPtr ,
int contextTid , rtwCAPI_ModelMappingInfo * rt_ParentMMI , const char_T *
rt_ChildPath , int_T rt_ChildMMIIdx , int_T rt_CSTATEIdx ) ; extern void
mr_SiEngine_MdlInfoRegFcn ( SimStruct * mdlRefSfcnS , char_T * modelName ,
int_T * retVal ) ; extern mxArray * mr_SiEngine_GetDWork ( const mi1gy4ncu4i
* mdlrefDW ) ; extern void mr_SiEngine_SetDWork ( mi1gy4ncu4i * mdlrefDW ,
const mxArray * ssDW ) ; extern void mr_SiEngine_RegisterSimStateChecksum (
SimStruct * S ) ; extern mxArray * mr_SiEngine_GetSimStateDisallowedBlocks (
) ; extern const rtwCAPI_ModelMappingStaticInfo * SiEngine_GetCAPIStaticMap (
void ) ; extern void ktu41xxdct ( real_T * g4gczky1jn , real_T * mzjvwiqump ,
real_T * pn5a2jihsi , avhdfnulpn * localX ) ; extern void ezgckb5ooa (
avhdfnulpn * localX ) ; extern void ijuotnz2h5 ( bwlfiijd5x * const
meoozayevp , d1lrwbszlu * localDW ) ; extern void hq0hzutu22 ( const real_T *
d40ikbrf21 , const real_T * n4wrwi1sc2 , const real_T * bqidtewuhm , const
real_T * hul2kc4knj , const real_T * ntxe3k1eks , const real_T * jflx4qojvb ,
const real_T * akltywkcem , const real_T * jg0oimtowh , const real_T *
arvgrwlkkq , const real_T * hflfx2yn0f , real_T * i0jbrwa4gj , j1s1gxkfvu *
localB , d1lrwbszlu * localDW , avhdfnulpn * localX , doesh3j4ls * localXdot
, ibzy5kfavx * localXdis ) ; extern void hv1un0elor ( const real_T *
ccixnbvzpb , const real_T * pmsztc3fue , real_T * i1msc4j53q , real_T *
pn2uqvgcaq , real_T * d3jiogbqxz , j1s1gxkfvu * localB , d1lrwbszlu * localDW
, nemag1oqsq * localZCSV , avhdfnulpn * localX ) ; extern void e3l123hmfg (
bwlfiijd5x * const meoozayevp , d1lrwbszlu * localDW ) ; extern void
hlr42tlto2 ( bwlfiijd5x * const meoozayevp , d1lrwbszlu * localDW ,
ibzy5kfavx * localXdis ) ; extern void hlr42tlto2TID2 ( void ) ; extern void
SiEngine ( bwlfiijd5x * const meoozayevp , const real_T * ijdpyildse , const
real_T * h4pnq2vsit , const real_T * ccixnbvzpb , const real_T * pmsztc3fue ,
const real_T * pspuy53sz5 , const real_T * cnvyq3zfr4 , real_T * j1llvicacr ,
real_T * i1msc4j53q , real_T * lf2nyyq3x3 , real_T * omhdmvkigs , real_T *
g2tlhpbb10 , real_T * pn2uqvgcaq , real_T * o0olqrecft , real_T * fxpgh21f40
, real_T * nlaqfz3qqz , real_T * d3jiogbqxz , real_T * db4urap1dv , real_T *
kcu5yymwqs , real_T * d2egiyhvse , real_T * cxomk032dx , real_T * bvgur3oz2k
, real_T * nzac4hepl3 , real_T * hw0zdjkb1x , real_T * g2lrfcygvl , real_T *
o01t1fbcwf , real_T * bjb3yurojn , real_T * jygzascolb , real_T * foaeo1w3c3
, real_T * nkhcwqjta5 , real_T * i0jbrwa4gj , real_T * eg5rquaqn3 , real_T *
dp1vesnznw , real_T * oq5at2kdfc , real_T * nya3zen5al , real_T * h0hdncmsfi
, real_T * h5fklemcyh , real_T * g4gczky1jn , real_T * mzjvwiqump , real_T *
pn5a2jihsi , real_T * igba034jkj , real_T * cqanywx13d , real_T * f0zzqfppai
, real_T * kitwkjkbni , real_T * p4awxamzoc , j1s1gxkfvu * localB ,
d1lrwbszlu * localDW , avhdfnulpn * localX ) ; extern void SiEngineTID2 (
j1s1gxkfvu * localB , d1lrwbszlu * localDW ) ; extern void hvze5idtbj (
d1lrwbszlu * localDW , bwlfiijd5x * const meoozayevp ) ;
#endif
