#include "SiEngine_capi.h"
#include "SiEngine.h"
#include "SiEngine_private.h"
#include "look1_binlcpw.h"
static RegMdlInfo rtMdlInfo_SiEngine [ 46 ] = { { "mi1gy4ncu4i" ,
MDL_INFO_NAME_MDLREF_DWORK , 0 , - 1 , ( void * ) "SiEngine" } , {
"nemag1oqsq" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"SiEngine" } , { "fgeg3btikx" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 ,
( void * ) "SiEngine" } , { "e0d0mrnvza" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "SiEngine" } , { "lowbiskj5g" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "SiEngine" } , {
"ibzy5kfavx" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"SiEngine" } , { "doesh3j4ls" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 ,
( void * ) "SiEngine" } , { "avhdfnulpn" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "SiEngine" } , { "exzolwrjx2" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "SiEngine" } , {
"bb3tmozgxg" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"SiEngine" } , { "mewrirvbqp" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 ,
( void * ) "SiEngine" } , { "pljdbbyrs0" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "SiEngine" } , { "d1lrwbszlu" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "SiEngine" } , {
"j1s1gxkfvu" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"SiEngine" } , { "an4hpzvdyr" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 ,
( void * ) "SiEngine" } , { "hvze5idtbj" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "SiEngine" } , { "aebk5sajjn" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "SiEngine" } , {
"e3l123hmfg" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"SiEngine" } , { "ilnmera1gw" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 ,
( void * ) "SiEngine" } , { "hv1un0elor" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "SiEngine" } , { "hq0hzutu22" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "SiEngine" } , {
"hlr42tlto2" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"SiEngine" } , { "ezgckb5ooa" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 ,
( void * ) "SiEngine" } , { "ktu41xxdct" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "SiEngine" } , { "ip52ymrooi" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "SiEngine" } , {
"ijuotnz2h5" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"SiEngine" } , { "pynf0robzb" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 ,
( void * ) "SiEngine" } , { "SiEngine" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0
, 0 , ( NULL ) } , { "afztxmcbql" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , -
1 , ( void * ) "SiEngine" } , { "a1aqzqkr0q" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "SiEngine" } , {
"bwlfiijd5x" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"SiEngine" } , { "nusecvdwrfs" , MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL ) }
, { "mr_SiEngine_GetSimStateDisallowedBlocks" , MDL_INFO_ID_MODEL_FCN_NAME ,
0 , - 1 , ( void * ) "SiEngine" } , {
"mr_SiEngine_extractBitFieldFromCellArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "SiEngine" } , {
"mr_SiEngine_cacheBitFieldToCellArrayWithOffset" , MDL_INFO_ID_MODEL_FCN_NAME
, 0 , - 1 , ( void * ) "SiEngine" } , {
"mr_SiEngine_restoreDataFromMxArrayWithOffset" , MDL_INFO_ID_MODEL_FCN_NAME ,
0 , - 1 , ( void * ) "SiEngine" } , {
"mr_SiEngine_cacheDataToMxArrayWithOffset" , MDL_INFO_ID_MODEL_FCN_NAME , 0 ,
- 1 , ( void * ) "SiEngine" } , { "mr_SiEngine_extractBitFieldFromMxArray" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "SiEngine" } , {
"mr_SiEngine_cacheBitFieldToMxArray" , MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 ,
( void * ) "SiEngine" } , { "mr_SiEngine_restoreDataFromMxArray" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "SiEngine" } , {
"mr_SiEngine_cacheDataAsMxArray" , MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , (
void * ) "SiEngine" } , { "mr_SiEngine_RegisterSimStateChecksum" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "SiEngine" } , {
"mr_SiEngine_SetDWork" , MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * )
"SiEngine" } , { "mr_SiEngine_GetDWork" , MDL_INFO_ID_MODEL_FCN_NAME , 0 , -
1 , ( void * ) "SiEngine" } , { "SiEngine.h" , MDL_INFO_MODEL_FILENAME , 0 ,
- 1 , ( NULL ) } , { "SiEngine.c" , MDL_INFO_MODEL_FILENAME , 0 , - 1 , (
void * ) "SiEngine" } } ; k5hdiwnneym k5hdiwnney = { 1.0E-6 , 0.0 , { 0.98 ,
0.98 , 0.98 , 0.97 , 0.05 , 0.02 , 0.0 } , { 0.909090909 , 0.944055944 ,
0.979020979 , 1.0 , 1.013986014 , 1.048951049 , 1.083916084 } , { 0.17 , 0.25
, 0.45 , 0.99 , 0.99 , 0.99 , 0.99 } , { 0.909090909 , 0.944055944 ,
0.979020979 , 1.0 , 1.013986014 , 1.048951049 , 1.083916084 } , { 0.21 ,
0.375 , 0.75 , 0.98 , 0.98 , 0.98 , 0.98 } , { 0.909090909 , 0.944055944 ,
0.979020979 , 1.0 , 1.013986014 , 1.048951049 , 1.083916084 } , 1.0 , 1.0 ,
1.0 , { 0.0 , 1.5 } , { 300.0 , 750.0 } , 1000.0 , 0.0 , 300.0 ,
0.10471975511965977 , - 11.76470588235294 , 11.76470588235294 , -
6.666666666666667 , 6.666666666666667 , - 8.0 , 8.0 , - 8.0 , 8.0 , - 8.0 ,
8.0 , - 6.666666666666667 , 6.666666666666667 , - 8.0 , 8.0 , - 8.0 , 8.0 , -
8.0 , 8.0 , - 8.0 , 8.0 , 1000.0 , 3600.0 , 0.10471975511965977 , 0.001 , {
0.0 , 500.0 } , { 0.0 , 500.0 } , { 0.0 , 1.0273972602739727 , 1.0 } , { 0.0
, 15.0 , 100.0 } , { - 1.0 , 0.0 , 0.0 , 0.07 } , { 0.0 , 0.97 , 1.03 , 1.1 }
, - 10.0 , 10.0 , - 0.1 , 0.1 , 0.0 , 0.0 , 0.0 , 1.0 , 1.0 } ; void
ktu41xxdct ( real_T * g4gczky1jn , real_T * mzjvwiqump , real_T * pn5a2jihsi
, avhdfnulpn * localX ) { localX -> bwugeffscn = 0.0 ; localX -> aicfihznzn =
0.0 ; localX -> iwfypymqjg = 0.0 ; localX -> mvylur3avu = 0.0 ; localX ->
jdpri2xyhy = 0.0 ; localX -> cd5spz4yti = 0.0 ; localX -> ketkc3kgyu = 0.0 ;
localX -> h4rakbatg5 = 0.0 ; localX -> ozfuihul04 = 0.0 ; localX ->
jtqd4zeqez = 0.0 ; localX -> fdwz5f1zsi = 0.0 ; localX -> fsytvblt0t = 0.0 ;
mt4ilpnutb ( & ( localX -> b4nii2a1sx ) ) ; * g4gczky1jn = k5hdiwnney . P_51
; * mzjvwiqump = k5hdiwnney . P_52 ; * pn5a2jihsi = k5hdiwnney . P_53 ; }
void ezgckb5ooa ( avhdfnulpn * localX ) { localX -> bwugeffscn = 0.0 ; localX
-> aicfihznzn = 0.0 ; localX -> iwfypymqjg = 0.0 ; localX -> mvylur3avu = 0.0
; localX -> jdpri2xyhy = 0.0 ; localX -> cd5spz4yti = 0.0 ; localX ->
ketkc3kgyu = 0.0 ; localX -> h4rakbatg5 = 0.0 ; localX -> ozfuihul04 = 0.0 ;
localX -> jtqd4zeqez = 0.0 ; localX -> fdwz5f1zsi = 0.0 ; localX ->
fsytvblt0t = 0.0 ; mywoblxnq5 ( & ( localX -> b4nii2a1sx ) ) ; } void
e3l123hmfg ( bwlfiijd5x * const meoozayevp , d1lrwbszlu * localDW ) {
lx4yje0jop ( & ( localDW -> ld4bcbcem1 . rtdw ) ) ; switch ( localDW ->
ov1mlbve3n ) { case 0 : ssSetBlockStateForSolverChangedAtMajorStep (
meoozayevp -> _mdlRefSfcnS ) ; break ; case 1 :
ssSetBlockStateForSolverChangedAtMajorStep ( meoozayevp -> _mdlRefSfcnS ) ;
break ; } localDW -> ov1mlbve3n = - 1 ; } void ijuotnz2h5 ( bwlfiijd5x *
const meoozayevp , d1lrwbszlu * localDW ) { ahma5ngmia ( & ( localDW ->
ld4bcbcem1 . rtdw ) ) ; ssSetBlockStateForSolverChangedAtMajorStep (
meoozayevp -> _mdlRefSfcnS ) ; ssSetBlockStateForSolverChangedAtMajorStep (
meoozayevp -> _mdlRefSfcnS ) ; localDW -> ov1mlbve3n = - 1 ; } void SiEngine
( bwlfiijd5x * const meoozayevp , const real_T * ijdpyildse , const real_T *
h4pnq2vsit , const real_T * ccixnbvzpb , const real_T * pmsztc3fue , const
real_T * pspuy53sz5 , const real_T * cnvyq3zfr4 , real_T * j1llvicacr ,
real_T * i1msc4j53q , real_T * lf2nyyq3x3 , real_T * omhdmvkigs , real_T *
g2tlhpbb10 , real_T * pn2uqvgcaq , real_T * o0olqrecft , real_T * fxpgh21f40
, real_T * nlaqfz3qqz , real_T * d3jiogbqxz , real_T * db4urap1dv , real_T *
kcu5yymwqs , real_T * d2egiyhvse , real_T * cxomk032dx , real_T * bvgur3oz2k
, real_T * nzac4hepl3 , real_T * hw0zdjkb1x , real_T * g2lrfcygvl , real_T *
o01t1fbcwf , real_T * bjb3yurojn , real_T * jygzascolb , real_T * foaeo1w3c3
, real_T * nkhcwqjta5 , real_T * i0jbrwa4gj , real_T * eg5rquaqn3 , real_T *
dp1vesnznw , real_T * oq5at2kdfc , real_T * nya3zen5al , real_T * h0hdncmsfi
, real_T * h5fklemcyh , real_T * g4gczky1jn , real_T * mzjvwiqump , real_T *
pn5a2jihsi , real_T * igba034jkj , real_T * cqanywx13d , real_T * f0zzqfppai
, real_T * kitwkjkbni , real_T * p4awxamzoc , j1s1gxkfvu * localB ,
d1lrwbszlu * localDW , avhdfnulpn * localX ) { real_T bbogjtw3es_p ; real_T
mngdt5pr0p_p ; int8_T rtAction ; int8_T rtPrevAction ; * i1msc4j53q = *
pspuy53sz5 ; mngdt5pr0p_p = k5hdiwnney . P_13 * look1_binlcpw ( * i1msc4j53q
, k5hdiwnney . P_12 , k5hdiwnney . P_11 , 1U ) ; if ( rtmIsMajorTimeStep (
meoozayevp ) ) { localDW -> i1laah4vh5 = * i1msc4j53q >= k5hdiwnney . P_14 ?
1 : * i1msc4j53q > k5hdiwnney . P_15 ? 0 : - 1 ; } bbogjtw3es_p = ( localDW
-> i1laah4vh5 == 1 ? k5hdiwnney . P_14 : localDW -> i1laah4vh5 == - 1 ?
k5hdiwnney . P_15 : * i1msc4j53q ) * k5hdiwnney . P_16 ; * g2tlhpbb10 = 0.0 ;
* g2tlhpbb10 += k5hdiwnney . P_18 * localX -> bwugeffscn ; * pn2uqvgcaq = 0.0
; * pn2uqvgcaq += k5hdiwnney . P_20 * localX -> aicfihznzn ; * o0olqrecft =
0.0 ; * o0olqrecft += k5hdiwnney . P_22 * localX -> iwfypymqjg ; * fxpgh21f40
= 0.0 ; * fxpgh21f40 += k5hdiwnney . P_24 * localX -> mvylur3avu ; *
d3jiogbqxz = 0.0 ; * d3jiogbqxz += k5hdiwnney . P_26 * localX -> jdpri2xyhy ;
SiEngineCore ( & ( localDW -> ld4bcbcem1 . rtm ) , g2tlhpbb10 , pn2uqvgcaq ,
ijdpyildse , h4pnq2vsit , o0olqrecft , fxpgh21f40 , d3jiogbqxz , cnvyq3zfr4 ,
ccixnbvzpb , ccixnbvzpb , pmsztc3fue , i1msc4j53q , & localB -> he4x31s4eb ,
hw0zdjkb1x , g2lrfcygvl , lf2nyyq3x3 , omhdmvkigs , & localB -> c4ci0hxjem ,
o01t1fbcwf , bvgur3oz2k , nzac4hepl3 , bjb3yurojn , jygzascolb , foaeo1w3c3 ,
nkhcwqjta5 , i0jbrwa4gj , eg5rquaqn3 , h0hdncmsfi , dp1vesnznw , oq5at2kdfc ,
nya3zen5al , & localB -> ga2ciuonaw , & localB -> pbpbrscrl4 , & localB ->
k32rccm1xy , igba034jkj , cqanywx13d , f0zzqfppai , kitwkjkbni , p4awxamzoc ,
& ( localDW -> ld4bcbcem1 . rtb ) , & ( localDW -> ld4bcbcem1 . rtdw ) , & (
localX -> b4nii2a1sx ) ) ; * j1llvicacr = localB -> he4x31s4eb - mngdt5pr0p_p
/ bbogjtw3es_p ; * nlaqfz3qqz = 0.0 ; * nlaqfz3qqz += k5hdiwnney . P_28 *
localX -> cd5spz4yti ; * db4urap1dv = 0.0 ; * db4urap1dv += k5hdiwnney . P_30
* localX -> ketkc3kgyu ; * kcu5yymwqs = 0.0 ; * kcu5yymwqs += k5hdiwnney .
P_32 * localX -> h4rakbatg5 ; * d2egiyhvse = 0.0 ; * d2egiyhvse += k5hdiwnney
. P_34 * localX -> ozfuihul04 ; * cxomk032dx = 0.0 ; * cxomk032dx +=
k5hdiwnney . P_36 * localX -> jtqd4zeqez ; mngdt5pr0p_p = k5hdiwnney . P_39 *
* i1msc4j53q * localB -> he4x31s4eb * k5hdiwnney . P_40 ; if ( ( mngdt5pr0p_p
>= - k5hdiwnney . P_0 ) && ( mngdt5pr0p_p <= k5hdiwnney . P_0 ) ) { if (
mngdt5pr0p_p >= k5hdiwnney . P_1 ) { bbogjtw3es_p = k5hdiwnney . P_54 ; }
else { bbogjtw3es_p = localB -> dnq5qm1ysy ; } mngdt5pr0p_p = 2.0E-6 / ( 3.0
- muDoubleScalarPower ( mngdt5pr0p_p / 1.0e-6 , 2.0 ) ) * bbogjtw3es_p ; } *
h5fklemcyh = look1_binlcpw ( k5hdiwnney . P_37 * * bvgur3oz2k * k5hdiwnney .
P_38 / mngdt5pr0p_p , k5hdiwnney . P_42 , k5hdiwnney . P_41 , 1U ) ; localB
-> blpqcjq3e5 = look1_binlcpw ( look1_binlcpw ( * bjb3yurojn , k5hdiwnney .
P_44 , k5hdiwnney . P_43 , 2U ) , k5hdiwnney . P_46 , k5hdiwnney . P_45 , 3U
) ; mngdt5pr0p_p = k5hdiwnney . P_48 * localX -> fdwz5f1zsi + k5hdiwnney .
P_55 ; localB -> gol5zjq0it = 0.0 ; localB -> gol5zjq0it += k5hdiwnney . P_50
* localX -> fsytvblt0t ; rtPrevAction = localDW -> ov1mlbve3n ; if (
rtmIsMajorTimeStep ( meoozayevp ) ) { rtAction = ( int8_T ) ! ( localB ->
gol5zjq0it > 573.15 ) ; localDW -> ov1mlbve3n = rtAction ; } else { rtAction
= localDW -> ov1mlbve3n ; } if ( rtPrevAction != rtAction ) { switch (
rtPrevAction ) { case 0 : ssSetBlockStateForSolverChangedAtMajorStep (
meoozayevp -> _mdlRefSfcnS ) ; break ; case 1 :
ssSetBlockStateForSolverChangedAtMajorStep ( meoozayevp -> _mdlRefSfcnS ) ;
break ; } } switch ( rtAction ) { case 0 : if ( rtAction != rtPrevAction ) {
if ( rtmGetTaskTime ( meoozayevp , 0 ) != rtmGetTStart ( meoozayevp ) ) {
ssSetBlockStateForSolverChangedAtMajorStep ( meoozayevp -> _mdlRefSfcnS ) ; }
} * g4gczky1jn = ( k5hdiwnney . P_10 - look1_binlcpw ( mngdt5pr0p_p ,
k5hdiwnney . P_7 , k5hdiwnney . P_6 , 6U ) ) * localB -> ga2ciuonaw ; *
mzjvwiqump = ( k5hdiwnney . P_9 - look1_binlcpw ( mngdt5pr0p_p , k5hdiwnney .
P_5 , k5hdiwnney . P_4 , 6U ) ) * localB -> pbpbrscrl4 ; * pn5a2jihsi = (
k5hdiwnney . P_8 - look1_binlcpw ( mngdt5pr0p_p , k5hdiwnney . P_3 ,
k5hdiwnney . P_2 , 6U ) ) * localB -> k32rccm1xy ; if ( rtmIsMajorTimeStep (
meoozayevp ) ) { srUpdateBC ( localDW -> ctcrxrlnoa ) ; } break ; case 1 : if
( rtAction != rtPrevAction ) { if ( rtmGetTaskTime ( meoozayevp , 0 ) !=
rtmGetTStart ( meoozayevp ) ) { ssSetBlockStateForSolverChangedAtMajorStep (
meoozayevp -> _mdlRefSfcnS ) ; } } * g4gczky1jn = localB -> ga2ciuonaw ; *
mzjvwiqump = localB -> pbpbrscrl4 ; * pn5a2jihsi = localB -> k32rccm1xy ; if
( rtmIsMajorTimeStep ( meoozayevp ) ) { srUpdateBC ( localDW -> leq3bzncpd )
; } break ; } } void SiEngineTID2 ( j1s1gxkfvu * localB , d1lrwbszlu *
localDW ) { localB -> dnq5qm1ysy = - k5hdiwnney . P_54 ; SiEngineCoreTID2 ( &
( localDW -> ld4bcbcem1 . rtm ) , & ( localDW -> ld4bcbcem1 . rtb ) , & (
localDW -> ld4bcbcem1 . rtdw ) ) ; } void hlr42tlto2 ( bwlfiijd5x * const
meoozayevp , d1lrwbszlu * localDW , ibzy5kfavx * localXdis ) { lti1x2mlsn ( &
( localDW -> ld4bcbcem1 . rtm ) , & ( localDW -> ld4bcbcem1 . rtb ) , & (
localDW -> ld4bcbcem1 . rtdw ) , & ( localXdis -> b4nii2a1sx ) ) ; } void
hlr42tlto2TID2 ( void ) { } void hq0hzutu22 ( const real_T * d40ikbrf21 ,
const real_T * n4wrwi1sc2 , const real_T * bqidtewuhm , const real_T *
hul2kc4knj , const real_T * ntxe3k1eks , const real_T * jflx4qojvb , const
real_T * akltywkcem , const real_T * jg0oimtowh , const real_T * arvgrwlkkq ,
const real_T * hflfx2yn0f , real_T * i0jbrwa4gj , j1s1gxkfvu * localB ,
d1lrwbszlu * localDW , avhdfnulpn * localX , doesh3j4ls * localXdot ,
ibzy5kfavx * localXdis ) { localXdot -> bwugeffscn = 0.0 ; localXdot ->
bwugeffscn += k5hdiwnney . P_17 * localX -> bwugeffscn ; localXdot ->
bwugeffscn += * d40ikbrf21 ; localXdot -> aicfihznzn = 0.0 ; localXdot ->
aicfihznzn += k5hdiwnney . P_19 * localX -> aicfihznzn ; localXdot ->
aicfihznzn += * n4wrwi1sc2 ; localXdot -> iwfypymqjg = 0.0 ; localXdot ->
iwfypymqjg += k5hdiwnney . P_21 * localX -> iwfypymqjg ; localXdot ->
iwfypymqjg += * bqidtewuhm ; localXdot -> mvylur3avu = 0.0 ; localXdot ->
mvylur3avu += k5hdiwnney . P_23 * localX -> mvylur3avu ; localXdot ->
mvylur3avu += * hul2kc4knj ; localXdot -> jdpri2xyhy = 0.0 ; localXdot ->
jdpri2xyhy += k5hdiwnney . P_25 * localX -> jdpri2xyhy ; localXdot ->
jdpri2xyhy += * jflx4qojvb ; ephdimea2c ( & ( localDW -> ld4bcbcem1 . rtb ) ,
& ( localX -> b4nii2a1sx ) , & ( localXdis -> b4nii2a1sx ) , & ( localXdot ->
b4nii2a1sx ) ) ; localXdot -> cd5spz4yti = 0.0 ; localXdot -> cd5spz4yti +=
k5hdiwnney . P_27 * localX -> cd5spz4yti ; localXdot -> cd5spz4yti += *
ntxe3k1eks ; localXdot -> ketkc3kgyu = 0.0 ; localXdot -> ketkc3kgyu +=
k5hdiwnney . P_29 * localX -> ketkc3kgyu ; localXdot -> ketkc3kgyu += *
akltywkcem ; localXdot -> h4rakbatg5 = 0.0 ; localXdot -> h4rakbatg5 +=
k5hdiwnney . P_31 * localX -> h4rakbatg5 ; localXdot -> h4rakbatg5 += *
jg0oimtowh ; localXdot -> ozfuihul04 = 0.0 ; localXdot -> ozfuihul04 +=
k5hdiwnney . P_33 * localX -> ozfuihul04 ; localXdot -> ozfuihul04 += *
arvgrwlkkq ; localXdot -> jtqd4zeqez = 0.0 ; localXdot -> jtqd4zeqez +=
k5hdiwnney . P_35 * localX -> jtqd4zeqez ; localXdot -> jtqd4zeqez += *
hflfx2yn0f ; localXdot -> fdwz5f1zsi = 0.0 ; localXdot -> fdwz5f1zsi +=
k5hdiwnney . P_47 * localX -> fdwz5f1zsi ; localXdot -> fdwz5f1zsi += localB
-> blpqcjq3e5 ; localXdot -> fsytvblt0t = 0.0 ; localXdot -> fsytvblt0t +=
k5hdiwnney . P_49 * localX -> fsytvblt0t ; localXdot -> fsytvblt0t += *
i0jbrwa4gj ; } void hv1un0elor ( const real_T * ccixnbvzpb , const real_T *
pmsztc3fue , real_T * i1msc4j53q , real_T * pn2uqvgcaq , real_T * d3jiogbqxz
, j1s1gxkfvu * localB , d1lrwbszlu * localDW , nemag1oqsq * localZCSV ,
avhdfnulpn * localX ) { localZCSV -> h2ly3yo0qo = * i1msc4j53q - k5hdiwnney .
P_14 ; localZCSV -> c4uzcdega1 = * i1msc4j53q - k5hdiwnney . P_15 ;
icfc3q2p1f ( pn2uqvgcaq , d3jiogbqxz , ccixnbvzpb , pmsztc3fue , & ( localDW
-> ld4bcbcem1 . rtb ) , & ( localDW -> ld4bcbcem1 . rtdw ) , & ( localX ->
b4nii2a1sx ) , & ( localZCSV -> hn1fmr24ml ) ) ; localZCSV -> oauikjg3i3 =
0.0 ; if ( localB -> gol5zjq0it > 573.15 ) { localZCSV -> oauikjg3i3 = 1.0 ;
} } void hvze5idtbj ( d1lrwbszlu * localDW , bwlfiijd5x * const meoozayevp )
{ cz5fxcs3qc ( & ( localDW -> ld4bcbcem1 . rtm ) ) ; if ( !
slIsRapidAcceleratorSimulating ( ) ) { slmrRunPluginEvent ( meoozayevp ->
_mdlRefSfcnS , "SiEngine" , "SIMSTATUS_TERMINATING_MODELREF_ACCEL_EVENT" ) ;
} } void ip52ymrooi ( SimStruct * _mdlRefSfcnS , int_T mdlref_TID0 , int_T
mdlref_TID1 , int_T mdlref_TID2 , bwlfiijd5x * const meoozayevp , j1s1gxkfvu
* localB , d1lrwbszlu * localDW , avhdfnulpn * localX , void * sysRanPtr ,
int contextTid , rtwCAPI_ModelMappingInfo * rt_ParentMMI , const char_T *
rt_ChildPath , int_T rt_ChildMMIIdx , int_T rt_CSTATEIdx ) { rt_InitInfAndNaN
( sizeof ( real_T ) ) ; k5hdiwnney . P_14 = rtInf ; ( void ) memset ( ( void
* ) meoozayevp , 0 , sizeof ( bwlfiijd5x ) ) ; meoozayevp -> Timing .
mdlref_GlobalTID [ 0 ] = mdlref_TID0 ; meoozayevp -> Timing .
mdlref_GlobalTID [ 1 ] = mdlref_TID1 ; meoozayevp -> Timing .
mdlref_GlobalTID [ 2 ] = mdlref_TID2 ; meoozayevp -> _mdlRefSfcnS = (
_mdlRefSfcnS ) ; if ( ! slIsRapidAcceleratorSimulating ( ) ) {
slmrRunPluginEvent ( meoozayevp -> _mdlRefSfcnS , "SiEngine" ,
"START_OF_SIM_MODEL_MODELREF_ACCEL_EVENT" ) ; } { localB -> he4x31s4eb = 0.0
; localB -> c4ci0hxjem = 0.0 ; localB -> ga2ciuonaw = 0.0 ; localB ->
pbpbrscrl4 = 0.0 ; localB -> k32rccm1xy = 0.0 ; localB -> blpqcjq3e5 = 0.0 ;
localB -> gol5zjq0it = 0.0 ; localB -> dnq5qm1ysy = 0.0 ; } ( void ) memset (
( void * ) localDW , 0 , sizeof ( d1lrwbszlu ) ) ;
SiEngine_InitializeDataMapInfo ( meoozayevp , localDW , localX , sysRanPtr ,
contextTid ) ; kkm3wcvp03 ( _mdlRefSfcnS , mdlref_TID0 , mdlref_TID1 ,
mdlref_TID2 , & ( localDW -> ld4bcbcem1 . rtm ) , & ( localDW -> ld4bcbcem1 .
rtb ) , & ( localDW -> ld4bcbcem1 . rtdw ) , & ( localX -> b4nii2a1sx ) ,
meoozayevp -> DataMapInfo . systemRan [ 0 ] , meoozayevp -> DataMapInfo .
systemTid [ 0 ] , & ( meoozayevp -> DataMapInfo . mmi ) ,
"SiEngine/Dynamic SI Engine with Turbo" , 0 , 5 ) ; if ( ( rt_ParentMMI != (
NULL ) ) && ( rt_ChildPath != ( NULL ) ) ) { rtwCAPI_SetChildMMI ( *
rt_ParentMMI , rt_ChildMMIIdx , & ( meoozayevp -> DataMapInfo . mmi ) ) ;
rtwCAPI_SetPath ( meoozayevp -> DataMapInfo . mmi , rt_ChildPath ) ;
rtwCAPI_MMISetContStateStartIndex ( meoozayevp -> DataMapInfo . mmi ,
rt_CSTATEIdx ) ; } } void mr_SiEngine_MdlInfoRegFcn ( SimStruct * mdlRefSfcnS
, char_T * modelName , int_T * retVal ) { * retVal = 0 ; { boolean_T
regSubmodelsMdlinfo = false ; ssGetRegSubmodelsMdlinfo ( mdlRefSfcnS , &
regSubmodelsMdlinfo ) ; if ( regSubmodelsMdlinfo ) {
mr_SiEngineCore_MdlInfoRegFcn ( mdlRefSfcnS , "SiEngineCore" , retVal ) ; if
( * retVal == 0 ) return ; * retVal = 0 ; } } * retVal = 0 ;
ssRegModelRefMdlInfo ( mdlRefSfcnS , modelName , rtMdlInfo_SiEngine , 46 ) ;
* retVal = 1 ; } static void mr_SiEngine_cacheDataAsMxArray ( mxArray *
destArray , mwIndex i , int j , const void * srcData , size_t numBytes ) ;
static void mr_SiEngine_cacheDataAsMxArray ( mxArray * destArray , mwIndex i
, int j , const void * srcData , size_t numBytes ) { mxArray * newArray =
mxCreateUninitNumericMatrix ( ( size_t ) 1 , numBytes , mxUINT8_CLASS ,
mxREAL ) ; memcpy ( ( uint8_T * ) mxGetData ( newArray ) , ( const uint8_T *
) srcData , numBytes ) ; mxSetFieldByNumber ( destArray , i , j , newArray )
; } static void mr_SiEngine_restoreDataFromMxArray ( void * destData , const
mxArray * srcArray , mwIndex i , int j , size_t numBytes ) ; static void
mr_SiEngine_restoreDataFromMxArray ( void * destData , const mxArray *
srcArray , mwIndex i , int j , size_t numBytes ) { memcpy ( ( uint8_T * )
destData , ( const uint8_T * ) mxGetData ( mxGetFieldByNumber ( srcArray , i
, j ) ) , numBytes ) ; } static void mr_SiEngine_cacheBitFieldToMxArray (
mxArray * destArray , mwIndex i , int j , uint_T bitVal ) ; static void
mr_SiEngine_cacheBitFieldToMxArray ( mxArray * destArray , mwIndex i , int j
, uint_T bitVal ) { mxSetFieldByNumber ( destArray , i , j ,
mxCreateDoubleScalar ( ( double ) bitVal ) ) ; } static uint_T
mr_SiEngine_extractBitFieldFromMxArray ( const mxArray * srcArray , mwIndex i
, int j , uint_T numBits ) ; static uint_T
mr_SiEngine_extractBitFieldFromMxArray ( const mxArray * srcArray , mwIndex i
, int j , uint_T numBits ) { const uint_T varVal = ( uint_T ) mxGetScalar (
mxGetFieldByNumber ( srcArray , i , j ) ) ; return varVal & ( ( 1u << numBits
) - 1u ) ; } static void mr_SiEngine_cacheDataToMxArrayWithOffset ( mxArray *
destArray , mwIndex i , int j , mwIndex offset , const void * srcData ,
size_t numBytes ) ; static void mr_SiEngine_cacheDataToMxArrayWithOffset (
mxArray * destArray , mwIndex i , int j , mwIndex offset , const void *
srcData , size_t numBytes ) { uint8_T * varData = ( uint8_T * ) mxGetData (
mxGetFieldByNumber ( destArray , i , j ) ) ; memcpy ( ( uint8_T * ) & varData
[ offset * numBytes ] , ( const uint8_T * ) srcData , numBytes ) ; } static
void mr_SiEngine_restoreDataFromMxArrayWithOffset ( void * destData , const
mxArray * srcArray , mwIndex i , int j , mwIndex offset , size_t numBytes ) ;
static void mr_SiEngine_restoreDataFromMxArrayWithOffset ( void * destData ,
const mxArray * srcArray , mwIndex i , int j , mwIndex offset , size_t
numBytes ) { const uint8_T * varData = ( const uint8_T * ) mxGetData (
mxGetFieldByNumber ( srcArray , i , j ) ) ; memcpy ( ( uint8_T * ) destData ,
( const uint8_T * ) & varData [ offset * numBytes ] , numBytes ) ; } static
void mr_SiEngine_cacheBitFieldToCellArrayWithOffset ( mxArray * destArray ,
mwIndex i , int j , mwIndex offset , uint_T fieldVal ) ; static void
mr_SiEngine_cacheBitFieldToCellArrayWithOffset ( mxArray * destArray ,
mwIndex i , int j , mwIndex offset , uint_T fieldVal ) { mxSetCell (
mxGetFieldByNumber ( destArray , i , j ) , offset , mxCreateDoubleScalar ( (
double ) fieldVal ) ) ; } static uint_T
mr_SiEngine_extractBitFieldFromCellArrayWithOffset ( const mxArray * srcArray
, mwIndex i , int j , mwIndex offset , uint_T numBits ) ; static uint_T
mr_SiEngine_extractBitFieldFromCellArrayWithOffset ( const mxArray * srcArray
, mwIndex i , int j , mwIndex offset , uint_T numBits ) { const uint_T
fieldVal = ( uint_T ) mxGetScalar ( mxGetCell ( mxGetFieldByNumber ( srcArray
, i , j ) , offset ) ) ; return fieldVal & ( ( 1u << numBits ) - 1u ) ; }
mxArray * mr_SiEngine_GetDWork ( const mi1gy4ncu4i * mdlrefDW ) { static
const char * ssDWFieldNames [ 3 ] = { "rtb" , "rtdw" , "NULL->rtzce" , } ;
mxArray * ssDW = mxCreateStructMatrix ( 1 , 1 , 3 , ssDWFieldNames ) ;
mr_SiEngine_cacheDataAsMxArray ( ssDW , 0 , 0 , & ( mdlrefDW -> rtb ) ,
sizeof ( mdlrefDW -> rtb ) ) ; { static const char * rtdwDataFieldNames [ 5 ]
= { "mdlrefDW->rtdw.ld4bcbcem1" , "mdlrefDW->rtdw.i1laah4vh5" ,
"mdlrefDW->rtdw.ov1mlbve3n" , "mdlrefDW->rtdw.leq3bzncpd" ,
"mdlrefDW->rtdw.ctcrxrlnoa" , } ; mxArray * rtdwData = mxCreateStructMatrix (
1 , 1 , 5 , rtdwDataFieldNames ) ; { mxArray * varData =
mr_SiEngineCore_GetDWork ( & ( mdlrefDW -> rtdw . ld4bcbcem1 ) ) ;
mxSetFieldByNumber ( rtdwData , 0 , 0 , varData ) ; }
mr_SiEngine_cacheDataAsMxArray ( rtdwData , 0 , 1 , & ( mdlrefDW -> rtdw .
i1laah4vh5 ) , sizeof ( mdlrefDW -> rtdw . i1laah4vh5 ) ) ;
mr_SiEngine_cacheDataAsMxArray ( rtdwData , 0 , 2 , & ( mdlrefDW -> rtdw .
ov1mlbve3n ) , sizeof ( mdlrefDW -> rtdw . ov1mlbve3n ) ) ;
mr_SiEngine_cacheDataAsMxArray ( rtdwData , 0 , 3 , & ( mdlrefDW -> rtdw .
leq3bzncpd ) , sizeof ( mdlrefDW -> rtdw . leq3bzncpd ) ) ;
mr_SiEngine_cacheDataAsMxArray ( rtdwData , 0 , 4 , & ( mdlrefDW -> rtdw .
ctcrxrlnoa ) , sizeof ( mdlrefDW -> rtdw . ctcrxrlnoa ) ) ;
mxSetFieldByNumber ( ssDW , 0 , 1 , rtdwData ) ; } ( void ) mdlrefDW ; return
ssDW ; } void mr_SiEngine_SetDWork ( mi1gy4ncu4i * mdlrefDW , const mxArray *
ssDW ) { ( void ) ssDW ; ( void ) mdlrefDW ;
mr_SiEngine_restoreDataFromMxArray ( & ( mdlrefDW -> rtb ) , ssDW , 0 , 0 ,
sizeof ( mdlrefDW -> rtb ) ) ; { const mxArray * rtdwData =
mxGetFieldByNumber ( ssDW , 0 , 1 ) ; mr_SiEngineCore_SetDWork ( & ( mdlrefDW
-> rtdw . ld4bcbcem1 ) , mxGetFieldByNumber ( rtdwData , 0 , 0 ) ) ;
mr_SiEngine_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . i1laah4vh5 ) ,
rtdwData , 0 , 1 , sizeof ( mdlrefDW -> rtdw . i1laah4vh5 ) ) ;
mr_SiEngine_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . ov1mlbve3n ) ,
rtdwData , 0 , 2 , sizeof ( mdlrefDW -> rtdw . ov1mlbve3n ) ) ;
mr_SiEngine_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . leq3bzncpd ) ,
rtdwData , 0 , 3 , sizeof ( mdlrefDW -> rtdw . leq3bzncpd ) ) ;
mr_SiEngine_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . ctcrxrlnoa ) ,
rtdwData , 0 , 4 , sizeof ( mdlrefDW -> rtdw . ctcrxrlnoa ) ) ; } } void
mr_SiEngine_RegisterSimStateChecksum ( SimStruct * S ) { const uint32_T
chksum [ 4 ] = { 4038923271U , 3689800575U , 1898432518U , 574057773U , } ;
slmrModelRefRegisterSimStateChecksum ( S , "SiEngine" , & chksum [ 0 ] ) ;
mr_SiEngineCore_RegisterSimStateChecksum ( S ) ; } mxArray *
mr_SiEngine_GetSimStateDisallowedBlocks ( ) { return
mr_SiEngineCore_GetSimStateDisallowedBlocks ( ) ; }
